#include "Optimizer.h"
#ifndef _OPTIM_ADAM_H_
#define _OPTIM_ADAM_H_ 
namespace optim {
template <typename FLOAT>
class Adam : public optim::Optimizer<FLOAT>
{

	float lr;
	float betas[2];
	float eps;
	vector<Tensor<FLOAT>*> first_moment;
	vector<Tensor<FLOAT>*> second_moment;
public:
	//_betas[0] = 0.9,_betas[1] = 0.999
	Adam(
		std::vector<float>& _betas,
		float _lr  = 0.001,
		float _eps = 0.00000001
	) 
	{
		parameter = nn::Parameter;
		lr        = _lr;
		eps       = _eps;
		if (_betas.size() != 2)
		{
			std::cout << "optimizer-Adam : std::vector<float>_betas'size must be 2!\n"; exit(1);
		}
		betas[0] = _betas[0];
		betas[1] = _betas[1];
		nn::CheckInvalidValue(lr);
		nn::CheckInvalidValue(_eps);
		for (unsigned int i = 0; i < parameter.size(); i++)
		{
			Tensor<FLOAT>* a = (Tensor<FLOAT>*)(parameter[i]);
			first_moment.push_back(new Tensor<FLOAT>(a->shape, false));
			second_moment.push_back(new Tensor<FLOAT>(a->shape, false));
		}

	}
	void update(Tensor<FLOAT>* input, Tensor<FLOAT>* first_moment, Tensor<FLOAT>* second_moment) 
	{
		adam<FLOAT>(input, first_moment, second_moment,betas,eps,lr,epoch);
	}
	void step() override {
		for (unsigned int i = 0; i < parameter.size(); i++)
		{
			update((Tensor<FLOAT>*)parameter[i], first_moment[i], second_moment[i]);
		}
		epoch++;
	}
	~Adam() {
		for (unsigned int i = 0; i < first_moment.size(); i++)
		{
			delete(first_moment[i]);
			delete(second_moment[i]);
		}
		vector<Tensor<FLOAT>*>().swap(first_moment);
		vector<Tensor<FLOAT>*>().swap(second_moment);
	}


};


}


#endif // !_OPTIMIZER_H_