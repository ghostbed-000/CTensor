#include "DataLoader.h"
#ifndef _DATA_FUNC_H_
#define _DATA_FUNC_H_
namespace CTensor {namespace Data {

template <typename T>
Node<T>* CTensor::Data::DataLoader<T>::Data2Node(T* batch_data, vector<int64_t>& _shape)
{
	return Functional::Variable(new Tensor<T>(data2device(batch_data, _len_of_batch_data_), _shape,false,false));
}
template <typename T>
void CTensor::Data::DataLoader<T>::operator() (Node<T>*& input, Node<T>*& label) 
{
	int64_t offset = 0; 
	if (shuffle)
	{
		offset = std::rand() % (_len_of_label_ - batch_size);
	}
	vector<int64_t> label_shape = { batch_size };
	T* tmp = (T*)data;
	input = Data2Node(tmp + offset * (_len_of_batch_data_ / batch_size), shape);
	label = Data2Node(label_data + offset, label_shape);

}

}
}



#endif