#include "..\Module\Module.h"

#ifndef _DATA_LOADER_H
#define _DATA_LOADER_H
/// <summary>
/// DataLoader is a class contain a huge Tensor which conatin all the batches of dataset
/// it provides shuffle function to choose data to train the model in random
/// </summary>
namespace CTensor{namespace Data{
	template <typename T>
	class DataLoader
	{
	private:
		//status
		vector<int64_t> shape;
		const T* data;
		int64_t* label_data;
		bool shuffle;
		int  order_counter;
		int  total_batch;
		int  _len_of_batch_data_;
		int  _len_of_label_;
		int  batch_size;
		Node<T>* Data2Node(T* batch_data, vector<int64_t>& _shape);
	public:
		//method
		DataLoader(
			const T* host_data,
			int64_t* _label_data,
			vector<int64_t>& _shape,
			int _batch_size,
			int len_of_label,
			bool shuffle_mode = true) 
		{
			_len_of_batch_data_ = 1;
			_len_of_label_ = len_of_label;
			shape   = _shape;
			data    = host_data;
			label_data = _label_data;
			shuffle = shuffle_mode;
			batch_size = _batch_size;
			order_counter = 0;
			
			for (unsigned int i = 0; i < _shape.size(); i++)
			{
				_len_of_batch_data_ *= _shape[i];
			}
		}
		~DataLoader() {

		}
		void operator()(Node<T>*& input, Node<T>*& label);

	};


}
}

#endif // !_DATA_LOADER_H



