#include "ContainerUtils.h"
#ifndef _OPTIMIZER_H_
#define _OPTIMIZER_H_
namespace optim {
template <typename FLOAT>
class Optimizer {
public:
	float lr;
	int32_t epoch = 1;
	//param-void : Tensor<FLOAT>*
	vector<void*> parameter;
	virtual void step() {}
	virtual ~Optimizer() {}
	void zero_grad_(){
		for (unsigned int i = 0; i < parameter.size(); i++)
		{
			((Tensor<FLOAT>*)(parameter[i]))->zero_grad();
		}
	}
};


}




#endif // !_OPTIMIZER_H_

