
/*
	if you want to use the cpu operator please define IS_CPU_ON

*/
//#define IS_CPU_ON
#ifdef IS_CPU_ON
#include "AutoGrad/Graph.h"
namespace CTensor {
#define CTensorDevice "cpu"

}
#endif

