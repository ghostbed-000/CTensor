#include "Op.h"
#ifndef _MAT_MUL_H_
#define _MAT_MUL_H_


template <typename FLOAT>
class MatMulOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		input[0]->zero_();
		input[0]->mul(input[1], output);
		
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		input[0]->TransposeItself(); input[0]->mul(doutput, input[1]->gradient); input[0]->TransposeItself();
		input[1]->TransposeItself(); doutput->mul(input[1], input[0]->gradient); input[1]->TransposeItself();
	}
	~MatMulOp(){}
};

template <typename FLOAT>
Node<FLOAT>* MatMulNodeGenerator(Node<FLOAT>* left, Node<FLOAT>* right, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(left); input_nodes->push_back(right);
	vector<int64_t> shape = input[0]->shape;
	shape[shape.size() - 1] = right->shape[shape.size() - 1];
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "MatMul");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* mm(Node<FLOAT>* left, Node<FLOAT>* right) {
		MatMulOp<FLOAT>* op = new MatMulOp<FLOAT>();
		Node<FLOAT>* x = MatMulNodeGenerator(left, right, op);
		op->compute(x);
		return x;
	}

}
#endif