#include "Op.h"

#ifndef _ONE_HOT_
#define _ONE_HOT_
template <typename FLOAT>
__global__ void OneHotKernel(FLOAT* index, FLOAT* OneHot,int64_t vocab_len) {

	int64_t id = vocab_len * blockIdx.x + (int64_t)index[blockIdx.x];
	if ((int64_t)index[blockIdx.x] < vocab_len)
	{
		OneHot[id] = 1;
	}
	else {
		printf("index[blockIdx.x] shouldn't be bigger than vocab_len ! \n");
	}
}

template <typename FLOAT>
__global__ void OneHotKernel(int32_t* index, FLOAT* OneHot, int64_t vocab_len) {

	int64_t id = vocab_len * blockIdx.x + (int64_t)index[blockIdx.x];
	if ((int64_t)index[blockIdx.x] < vocab_len)
	{
		OneHot[id] = 1.0;
	}
	else {
		printf("index[blockIdx.x] shouldn't be bigger than vocab_len ! \n");
	}
}

template <typename FLOAT>
Tensor<FLOAT>* one_hot(Tensor<FLOAT>* index, int32_t vocab_len) {
	vector<int64_t> shape = { index->shape[0],vocab_len };
	Tensor<FLOAT>* OneHot = new Tensor<FLOAT>(shape);
	dim3 grid(index->shape[0], 1, 1);
	dim3 block(1);

	OneHotKernel << <grid, block >> > (index->array, OneHot->array, vocab_len);

	cudaDeviceSynchronize();

	return OneHot;
}

template <typename FLOAT>
Tensor<FLOAT>* one_hot(int32_t* host_index, int32_t index_len, int32_t vocab_len) {
	vector<int64_t> shape = { index_len,vocab_len };
	Tensor<FLOAT>* OneHot = new Tensor<FLOAT>(shape);
	int32_t* device_index = nullptr;
	cudaMalloc((void**)&device_index, index_len * sizeof(int32_t));
	cudaMemcpy(device_index, host_index, index_len * sizeof(int32_t), cudaMemcpyHostToDevice);
	dim3 grid(index_len, 1, 1);
	dim3 block(1);

	OneHotKernel << <grid, block >> > (device_index, OneHot->array, vocab_len);

	cudaDeviceSynchronize();
	cudaFree(device_index);
	return OneHot;
}

#endif

