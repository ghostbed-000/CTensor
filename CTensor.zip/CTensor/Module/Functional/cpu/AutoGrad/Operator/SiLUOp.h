#include "Op.h"

#ifndef _SILU_OP_H_
#define _SILU_OP_H_
template <typename FLOAT>
__global__ void SiLUKernel(FLOAT* d_in, FLOAT* d_out) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_out[id] = d_in[id] / (1 - expf(-d_in[id]));
}

template <typename FLOAT>
__global__ void SiLUGradientKernel(FLOAT* d_in, FLOAT* d_in_grad, FLOAT* d_out, FLOAT* d_out_grad) {
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_in_grad[id] += (d_out[id] + (1 - d_out[id]) * (d_out[id] / d_in[id])) * d_out_grad[id];
}

template <typename FLOAT>
class SiLUOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, SiLUKernel);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, SiLUGradientKernel);
	}
	~SiLUOp(){}
};

template <typename FLOAT>
Node<FLOAT>* SiLUNodeGenerator(Node<FLOAT>* input, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(input->value), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "SiLU");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* swish(Node<FLOAT>* input) {
		SiLUOp<FLOAT>* op = new SiLUOp<FLOAT>();
		Node<FLOAT>* x = SiLUNodeGenerator(input, op);
		op->compute(x);
		return x;
	}

}

#endif