#include "Op.h"
#ifndef _LAYER_NORM_OP_H_
#define _LAYER_NORM_OP_H_
template <typename FLOAT>
class LayerNorm2dOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> x = node->input2values();
		delete(x[1]); delete(x[2]);
		Tensor<FLOAT>* mean = x[1];
		Tensor<FLOAT>* var  = x[2];

		Tensor<FLOAT>* x_hat = node->value;
		vector<int64_t> dim = { 1,2 };
		if (x[0]->shape.size() == 4) {
			dim.push_back(3);
		}
		else {
			printf("you couldn't used batch_norm2d with a tensor's dimensions less than 3 dimension!\n");
			return;
		}
		mean = x[0]->mean(dim);
		x[0]->sub(x[1], var);
		var->dotmul(var, var);
		var = var->sum(dim);
		var->operator+(node->param[0]);
		var->pow((FLOAT)0.5);
		x_hat->sub(x[1], x_hat);
		x_hat->divided(x[2], x_hat);
		node->input[0][1]->value = mean;
		node->input[0][2]->value = var;
	}
	void gradient(Node<FLOAT>* node) {
		int64_t N = 1;
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		vector<int64_t> dim = { 1,2 }; N *= doutput->shape[0] * doutput->shape[2];
		if (x[0]->shape.size() == 4) {
			dim.push_back(3);
			N *= doutput->shape[3];
		}
		if ((FLOAT)N == nan) { printf("BatchNorm2d occur nan!\n"); return; }
		input[2]->operator*((FLOAT)N);
		input[2]->pow(-1.0);
		Tensor<FLOAT>* sum_1 = doutput->sum(dim);
		Tensor<FLOAT> copy(doutput, false, false, true);
		doutput->operator*((FLOAT)N);
		copy.dotmul(node->value, &copy);
		Tensor<FLOAT>* sum_2 = copy.sum(dim);
		node->value->dotmul(sum_2, node->value);
		doutput->sub(sum_1, doutput);
		doutput->sub(node->value, doutput);
		doutput->dotmul(input[2], doutput);
		input[0]->add(doutput, input[0]);
		delete(sum_1);
		delete(sum_2);
	}
};

template <typename FLOAT>
Node<FLOAT>* LayerNorm2dNodeGenerator(Node<FLOAT>* input, FLOAT eps = 0.00001, Op<FLOAT>* op = nullptr) {
	if (shape.size() < 3)
	{
		printf("the tensor which is LayerNorm2d should have at least three dimension!\n"); return;
	}
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	input_nodes->push_back(Functional::Variable(nullptr));//mean
	input_nodes->push_back(Functional::Variable(nullptr));//var
	vector<FLOAT> shape = input->shape;
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "LayerNorm2d");
	output_node->param.push_back(eps);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* layer_norm2d(Node<FLOAT>* input, FLOAT eps = 0.00001) {
		LayerNorm2dOp<FLOAT>* op = new LayerNorm2dOp<FLOAT>();
		Node<FLOAT>* x = LayerNorm2dNodeGenerator(input, eps, op);
		op->compute(x);
		return x;
	}

}
#endif