#include "Template.h"
#ifndef _TENSOR_ARRANGE_H_
#define _TENSOR_ARRANGE_H_


template <typename FLOAT>
void Tensor<FLOAT>::arange() {

	for(int64_t i=0;i<_len_;i++){
		array[i] = i;
	}

}



#endif // !_TENSOR_ARRANGE_H_

