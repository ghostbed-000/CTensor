#include "Template.h"
#ifndef _TENSOR_CONTIGUOUS_H_
#define _TENSOR_CONTIGUOUS_H_


template <typename FLOAT>
Tensor<FLOAT>* Tensor<FLOAT>::contiguous() {
	Tensor<FLOAT>* newTensor = new Tensor<FLOAT>(shape, _requires_grad_, _retain_grad_);
	vector<int64_t> BroadcastShape = shape_broadcast(shape);
	vector<int64_t> BroadcastStrideA = stride_broadcast(stride);
	vector<int64_t> BroadcastStrideB = stride_broadcast(newTensor->stride);
	
	for(int i=0;i<BroadcastShape[0];i++){
		for(int j=0;j<BroadcastShape[1];j++)
			for(int k=0;k<BroadcastShape[2];k++)
				for(int l=0;l<BroadcastShape[3];l++){
					newTensor->array[CpuId(BroadcastStrideA,i,j,k,l)] = array[CpuId(BroadcastStrideA,i,j,k,l)];
				}		
	}

	return newTensor;
}


#endif
