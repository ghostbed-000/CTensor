#include "Template.h"
#ifndef _TENSOR_ADD_H_
#define _TENSOR_ADD_H_

template <typename FLOAT>
void Tensor<FLOAT>::operator+=(FLOAT value) {

	for(int64_t i=0;i<_len_;i++){
		array[i] += value;
	}

}

template <typename FLOAT>  
Tensor<FLOAT>* Tensor<FLOAT>::add(Tensor<FLOAT>* right, Tensor<FLOAT>* out, bool keep_dim) {
	int dim = (int)shape.size();
	vector<int64_t> BroadcastShapeA = shape_broadcast(shape);
	vector<int64_t> BroadcastShapeB = shape_broadcast(right->shape);
	vector<int64_t> BroadcastShape = BroadcastRule<int64_t>(BroadcastShapeA, BroadcastShapeB);
	if (BroadcastShape.size() == 0) { return nullptr; }
	if (out == nullptr) {
		out = new Tensor<FLOAT>(BroadcastShape,false);
	}
	/*
		code....
	
	*/
	if (keep_dim)
	{
		Tensor<FLOAT>* tmp = nullptr;
		for (unsigned int i = 0; i < shape.size(); i++) {
			if (shape[shape.size() - 1 - i] == 1 && BroadcastShape[shape.size() - 1 - i] != 1)
			{
				tmp = out;
				out = out->sum(shape.size() - 1 - i);
				delete(tmp);
			}
		}
	}

	return out;
}

#endif
