#include "Template.h"
#ifndef _TENSOR_COPY_H_
#define _TENSOR_COPY_H_
template <typename FLOAT> 
__global__ void CopyKernel(FLOAT* left, FLOAT* right,int64_t* Lstride, int64_t* Rstride)
{
	int64_t left_id  = CudaId(Lstride);
	int64_t right_id = CudaId(Rstride);

	left[left_id] = right_id[right_id];
}


template <typename FLOAT> 
void Tensor<FLOAT>::operator= (Tensor<FLOAT>* input) {
	
	if (CheckShapeEqual(shape, input->shape) != true)
	{
		printf("two tensor's shape must be equal!\n");
		return;
	}
	vector<int64_t> BroadcastShape = shape_broadcast(input->shape);
	//ĳ�ֽ���ͬ��״shapeת����4ά����
	dim3 block(BroadcastShape[dim - 4], BroadcastShape[dim - 3]);//block(B,C)
	dim3 grid(BroadcastShape[dim - 2], BroadcastShape[dim - 1]);//grid(H,W)

	int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(stride));
	int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(input->stride));

	MulKernel << <grid, block >> > (array, input->array, d_s1, d_s2);

	cudaDeviceSynchronize();
	cudaFree(d_s1);
	cudaFree(d_s2);
	return out;
}



#endif