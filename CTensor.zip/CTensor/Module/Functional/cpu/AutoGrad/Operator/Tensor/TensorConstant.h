#include "Template.h"

template <typename FLOAT>
void Tensor<FLOAT>::constant_(FLOAT value) {

	for(int64_t i=0;i<_len_;i++){
		array[i] = value;
	}

}

