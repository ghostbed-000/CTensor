#include "BroadcastRule.h"
#ifndef _TEMPLATE_H_
#define _TEMPLATE_H_

inline int64_t CpuId(vector<int64_t>& stride,int64_t dim0,int64_t dim1,int64_t dim2,int64_t dim3){
	return dim0 * stride[0] + dim1 * stride[1] + dim2 * stride[2] + dim3 * stride[3];
}


#endif 
