#include <iostream>
#include <math.h>
#include <stdlib.h>
#include <vector>
#include <tuple>

using std::vector;
using std::tuple;

#ifndef _TENSOR_H_
#define _TENSOR_H_
int64_t _CPU_MEMORY_COST_ = 0;
int64_t _GPU_MEMORY_COST_ = 0;
vector<int64_t> shape_stride(vector<int64_t>& shape);
template <typename FLOAT>
void cpuMemcpy(FLOAT* dst,FLOAT* src,size_t size);
template <typename FLOAT>
class Tensor
{
public:
//statue
	//[B,C,H.W],[C,H.W],[H.W]
	vector<int64_t> shape;
	vector<int64_t> stride;
	//vector<int8_t>  sequence;
	int64_t _len_;
	bool  _requires_grad_; 
	bool  _retain_grad_;
	bool  _is_cuda_ = true;
	Tensor<FLOAT>* gradient;
	
	FLOAT* array;
	
//method
	//constructor body
private:
	void size() {
		_len_ = 1;
		for (unsigned int i = 0; i < shape.size(); i++)
		{
			_len_ *= shape[i];
		}
		stride = shape_stride(shape);
	}
	void MemCost(bool NeedyArray) {
		if (NeedyArray) {
			_CPU_MEMORY_COST_ += _len_ * sizeof(FLOAT);
		}
		_CPU_MEMORY_COST_ += sizeof(Tensor<FLOAT>);
	}
public:
	//show
	void print_arr();
	//init
	Tensor(FLOAT value){
		shape.push_back(1);
		size();
		_requires_grad_ = true;
		_retain_grad_   = false;
		array = calloc(1, sizeof(FLOAT)); 
		cpuMemcpy(array, &value, sizeof(FLOAT));
		gradient = nullptr;
		MemCost(0);
	}
	Tensor(FLOAT* device_data, vector<int64_t>& _shape,bool requires_grad = 1){
		shape = _shape;
		size();
		array = device_data;
		_retain_grad_ = false;
		_requires_grad_ = requires_grad;
		gradient = nullptr;
		MemCost(0);
	}
	Tensor(Tensor<FLOAT>* input,bool requires_grad = true,bool retain_grad = false, bool copy_array = false){
		shape			   = input->shape;
		stride			   = input->stride;
		_requires_grad_    = requires_grad;
		_retain_grad_      = retain_grad;
		_len_			   = input->_len_;
		array = calloc(_len_, sizeof(FLOAT));
		if (copy_array)
		{
			cpuMemcpy(array,input->array, _len_ * sizeof(FLOAT));
		}
		gradient = nullptr;
		MemCost(0);
	}
	Tensor(vector<int64_t>& _shape,bool requires_grad = true, bool retain_grad = false,bool iNeedArray = true) {
		shape = _shape;
		size();
		_requires_grad_ = requires_grad;
		_retain_grad_   = retain_grad;
		array = nullptr;
		if (iNeedArray)
		{
			array = calloc(_len_, sizeof(FLOAT));
		}
		gradient = nullptr;
		if (requires_grad && retain_grad)
		{
			gradient = new Tensor(shape, false, false, iNeedArray);
		}
		MemCost(iNeedArray);
	}
	~Tensor(){
		if(array != nullptr){
			cudaFree(array);
			_CPU_MEMORY_COST_ -= sizeof(Tensor<FLOAT>) + _len_;
			array = nullptr;
		}
		if (gradient != nullptr) {
			_CPU_MEMORY_COST_ -= sizeof(Tensor<FLOAT>) + _len_;
			delete(gradient);
			
		}
	}
	//assigned
	void gaussinit(FLOAT var = 1, FLOAT mean = 0);
	void uniform(FLOAT a = 0, FLOAT b = 1);
	void constant_(FLOAT value = 1);
	void arange();
	void zero_();
	void zero_grad();
	//func
	FLOAT*to_cpu() {FLOAT* tmp = (FLOAT*)calloc(_len_ , sizeof(FLOAT));cudaMemcpy(tmp, array, _len_ * sizeof(FLOAT)); return tmp;}; 
	Tensor<FLOAT>* sum(int32_t dim);
	Tensor<FLOAT>* mean(int32_t dim);
	Tensor<FLOAT>* mean(vector<int32_t> dim);
	Tensor<FLOAT>* diag(Tensor<FLOAT>* input);
	void TransposeItself();
	Tensor<FLOAT>* transpose(int32_t dim1, int32_t dim2);
	Tensor<FLOAT>* contiguous();
	tuple<FLOAT*, int64_t*> max(int32_t dim);
	void reshape(vector<int64_t>& _shape);
	void pow(FLOAT exponent);
	void exp();
	void log();
	void cat(vector<Tensor<FLOAT>*>& tensors,Tensor<FLOAT>* output,int32_t dim);
	void split(Tensor<FLOAT>* input, vector<Tensor<FLOAT>*>& tensors, int32_t dim);
	Tensor<FLOAT>* mul(Tensor<FLOAT>* right, Tensor<FLOAT>* out = nullptr);
	Tensor<FLOAT>* divided(Tensor<FLOAT>* dividend, Tensor<FLOAT>* out = nullptr, bool keep_dim = false);
	Tensor<FLOAT>* sub(Tensor<FLOAT>* right, Tensor<FLOAT>* out = nullptr, bool keep_dim = false);
	Tensor<FLOAT>* add(Tensor<FLOAT>* right, Tensor<FLOAT>* out = nullptr, bool keep_dim = false);
	Tensor<FLOAT>* dotmul(Tensor<FLOAT>* right, Tensor<FLOAT>* out = nullptr, bool keep_dim = false);
	int  operator==(Tensor<FLOAT>* tensor);
	void operator=(Tensor<FLOAT>* tensor);
	void operator*=(FLOAT right_value);
	void operator+=(FLOAT right_value);
	void operator-=(FLOAT value);
	void divided(FLOAT dividend);
};

bool CheckShapeEqual(vector<int64_t>& shape1, vector<int64_t>& shape2) {
	for (unsigned int i = 0; i < shape1.size(); i++)
	{
		if (shape1[i] != shape2[i])
		{
			printf("the shape isn't same!\n");
			return false;
		}
	}
	return true;
}

vector<int64_t> shape_stride(vector<int64_t>& shape) {

	vector<int64_t> stride = shape;
	for (unsigned int i = 1; i <= shape.size(); i++)
	{
		stride[i - 1] = 1;
		for (unsigned int j = 0; j < (shape.size() - i); j++)
		{
			stride[i - 1] *= shape[i + j];
		}
	}
	return stride;
}
template <typename FLOAT>
void cpuMemcpy(FLOAT* dst,FLOAT* src,size_t size){
	for(int i=0;i < size;i++){
		dst[i] = src[i];
	}
}
void _SHOW_CPU_MEMORY_COST_() {
	double value = _CPU_MEMORY_COST_ / (1024 * 1024);
	printf("CPU MEMORY COST = %d mb\n", (int32_t)value);
}
void _SHOW_GPU_MEMORY_COST_() {
	double value = _GPU_MEMORY_COST_ / (1024 * 1024);
	printf("GPU MEMORY COST = %d mb\n", (int32_t)value);
}

#endif // !_TENSOR_H_
