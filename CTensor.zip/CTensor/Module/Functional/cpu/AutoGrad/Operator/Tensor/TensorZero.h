#include "Template.h"

template <typename FLOAT>
void Tensor<FLOAT>::zero_grad() {

	delete(array);
	array = (FLOAT*)calloc(sizeof(FLOAT),_len_);
}
