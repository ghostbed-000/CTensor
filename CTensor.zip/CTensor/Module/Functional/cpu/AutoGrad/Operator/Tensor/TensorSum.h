#include "Template.h"

#ifndef _TENSOR_SUM_H_
#define _TENSOR_SUM_H_
template <typename FLOAT>
__global__ void SumKernel(FLOAT* d_array, int size_of_this_array, int64_t* stride, int dim)
{
	int64_t index[4];
	GridToArray(index);
	int64_t dim_id = index[dim] * stride[dim];
	int64_t id = CudaId(stride);
	d_array[id] += d_array[id + stride[dim] * (size_of_this_array - 1) - dim_id - dim_id];
	__syncthreads();
}

template <typename FLOAT>
Tensor<FLOAT>* Tensor<FLOAT>::sum(int32_t dim) {
	FLOAT* d_sum = nullptr;
	int64_t size_of_this_array = shape[dim];
	vector<int64_t> BroadcastShape = shape_broadcast(shape);	
	int64_t* d_stride = VectorToCuda<int64_t>(stride_broadcast(stride));
	dim += BroadcastShape.size() - shape.size();
	cudaMalloc((void**)&d_sum, _len_ * sizeof(FLOAT));
	cudaMemcpy(d_sum, array, _len_ * sizeof(FLOAT), cudaMemcpyDeviceToDevice);
	while (size_of_this_array > 1)
	{
		BroadcastShape[dim] = size_of_this_array / 2;
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W) 
		SumKernel << <grid, block >> > (d_sum, size_of_this_array, d_stride, dim);
		if (size_of_this_array % 2 == 0)
		{
			size_of_this_array = BroadcastShape[dim];
		}
		else {
			size_of_this_array = (size_of_this_array + 1) / 2;
		}

	}
	cudaDeviceSynchronize();
	Tensor<FLOAT>* out = new Tensor<FLOAT>(d_sum, shape);
	out->stride = stride;
	dim -= BroadcastShape.size() - shape.size();
	out->shape[dim] = 1;
	return out;
}


#endif
