#include "LocationMatrix.h"
#ifndef _TENSOR_CONVD2D_H_
#define _TENSOR_CONVD2D_H_
template <typename FLOAT>
__global__ void LinearKernel(FLOAT* d_input, FLOAT* d_liner, FLOAT* filter, int32_t* d_location, int64_t S_filter, int64_t S_input, int64_t S_linear)
{

	int64_t i = blockIdx.z * S_filter * gridDim.x + blockIdx.x * S_filter + threadIdx.x;
	int64_t linear_page = S_linear * blockIdx.x + S_linear * gridDim.x * blockIdx.z * threadIdx.y;
	int64_t input_page = S_input * blockIdx.x + threadIdx.y * S_input * gridDim.x;
	d_liner[i + linear_page] = d_input[d_location[i] + input_page] * filter[threadIdx.x + blockDim.x * blockIdx.x];
}

template <typename FLOAT>
__global__ void SumLinearKernel(FLOAT* d_liner, FLOAT* output, int32_t* d_location, int64_t in_channel, int64_t S_filter, int64_t S_linear)
{

	int64_t out_id = blockIdx.x + blockIdx.y * gridDim.x + blockIdx.z * gridDim.x * gridDim.y;
	for (int64_t i = 0; i < in_channel; i++)
	{
		for (int64_t j = 0; j < S_filter; j++)
		{
			output[out_id] += d_liner[S_linear * i + S_linear * in_channel * blockIdx.z + j];
			__syncthreads();
		}
	}
	
}
template <typename FLOAT>
Tensor<FLOAT>* Conv2d(Tensor<FLOAT>* input, Tensor<FLOAT>* filter,int32_t* location, int32_t stride, Tensor<FLOAT>* output = nullptr) {
	int64_t S_output;
	vector<int64_t> BroadcastsShape = shape_broadcast(input->shape);
	int64_t batch_size  = BroadcastsShape[0];
	int64_t in_channel  = BroadcastsShape[1];
	int64_t out_channel = filter->shape[0];
	int64_t S_filter    = filter->shape[filter->size() - 1] * filter->shape[filter->size() - 1];
	vector<int64_t> shape = { batch_size,out_channel * in_channel,S_output,S_filter };
	Tensor<FLOAT> linear = Tensor<FLOAT>(shape,false);
	
	if (output == nullptr)
	{		
		int64_t row = (BroadcastsShape[3] - filter->shape[filter->size() - 1]) / stride + 1;
		int64_t col = (BroadcastsShape[2] - filter->shape[filter->size() - 1]) / stride + 1;
		vector<int64_t> new_shape = { batch_size ,filter->shape[0],row, col };
		output = new Tensor<FLOAT>(BroadcastsShape);
	}
	S_output = output->shape[output->shape.size() - 1] * output->shape[output->shape.size() - 2];

	dim3 block(S_filter ,batch_size);
	dim3 grid(in_channel , S_output, out_channel);

	LinearKernel << <grid, block >> > (input->array, linear.array, filter->array, location, S_filter, S_output * S_filter);
	cudaDeviceSynchronize();

	dim3 block2(1);
	dim3 grid2(S_output, out_channel, batch_size);

	SumLinearKernel << <grid2, block2 >> > (linear.array, output->array, location, S_filter, S_output * S_filter);
	cudaDeviceSynchronize();

	return output;
}
#endif