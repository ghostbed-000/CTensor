#include "Template.h"
#ifndef _TENSOR_CAT_H_
#define _TENSOR_CAT_H_
template <typename FLOAT>
__global__ void CatKernel(FLOAT* left, FLOAT* right, int64_t* d_Lstride, int64_t* d_Rstride, int64_t offset) {
	left[CudaId(d_Lstride) + offset] = right[CudaId(d_Rstride)];
}

template <typename FLOAT>
void Tensor<FLOAT>::cat(vector<Tensor<FLOAT>*>& tensors, Tensor<FLOAT>* output, int32_t dim) {
	int64_t offset = 0;
	int64_t* d_Lstride = VectorToCuda<int64_t>(stride_broadcast(stride));
	int64_t* d_Rstride = nullptr;
	FLOAT* d_tmp = output->array;
	

	if (operator==(right) > 1) { printf("the shape isn't same!\n"); return; }
	if (operator==(out) > 1) { printf("the shape isn't same!\n"); return; }

	for (unsigned int i = 0; i < tensors.size(); i++)
	{
		vector<int64_t> BroadcastShape = shape_broadcast(tensors[i]->shape);
		dim3 block(BroadcastShape[dim - 4], BroadcastShape[dim - 3]);//block(B,C)
		dim3 grid(BroadcastShape[dim - 2], BroadcastShape[dim - 1]);//grid(H,W)
		d_Rstride = VectorToCuda<int64_t>(stride_broadcast(stride));
		CatKernel << <grid, block >> > (d_tmp, tensors[i]->array, d_Lstride, d_Rstride,offset);
		cudaDeviceSynchronize();
		cudaFree(d_Rstride);

		offset += tensors[i]->shape[dim] * tensors[i]->stride[dim];
	}

}


#endif