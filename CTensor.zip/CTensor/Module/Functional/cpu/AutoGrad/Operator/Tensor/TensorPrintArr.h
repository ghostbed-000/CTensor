#include "Template.h"
#ifndef _TENSOR_PRINT_ARR_H_
#define _TENSOR_PRINT_ARR_H_
void hanoita(static float* mat, int64_t* size,int32_t dim) {
	static int64_t times = 0;
	static int64_t row   = 0;
	if (dim > 1)
	{
		int64_t* new_size = size + 1;
		for (int64_t i = 0; i < size[0]; i++) {
			printf("[");
			hanoita(mat, new_size, dim - 1);
			printf("]");
			for (int64_t i = 0; i < static_cast<long long>(dim) - 1; i++)
				printf("\n");
		}

	}
	else {
		row = size[0];
		mat += times * row;
		for (int64_t i = 0; i < size[0]; i++)
		{
			printf("%f,", mat[i]);
		}
		times++;
	}
}

void print_matrix(float* mat, vector<int64_t>& shape)
{

	float* tmp_mat = mat;
	int64_t* shape_array = (int64_t*)calloc(shape.size(), sizeof(int64_t));
	if (shape_array == NULL) { return; }//check
	for (unsigned int i = 0; i < shape.size(); i++) 
	{
		shape_array[i] = shape[i];
	}
	hanoita(tmp_mat, shape_array, (int32_t)shape.size());

	

	free(shape_array);
}

template <typename FLOAT>
void Tensor<FLOAT>::print_arr() {
	FLOAT* host_array = to_cpu();
	FLOAT* host_grad  = nullptr;

	print_matrix(host_array, shape);
	if (gradient != nullptr) {
		host_grad = gradient->to_cpu();
		printf("gradient:");
		print_matrix(host_grad,shape);
	}

	free(host_array);
	free(host_grad);
}

#endif // !_TENSOR_PRINT_ARR_H_

