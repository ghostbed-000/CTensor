#include "Template.h"
#ifndef _TENSOR_EXP_H_
#define _TENSOR_EXP_H_

template <typename FLOAT>
void Tensor<FLOAT>::exp() { 

	for(int64_t i=0;i<_len_;i++){
		array[i] = exp(array[i]);
	}

}




#endif
