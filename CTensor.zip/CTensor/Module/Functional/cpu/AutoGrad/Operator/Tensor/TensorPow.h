#include "Template.h"
#ifndef _TENSOR_POW_H_
#define _TENSOR_POW_H_
template <typename FLOAT>
void Tensor<FLOAT>::pow(FLOAT value) { 

	for(int64_t i=0;i<_len_;i++){
		array[i] = pow(array[i],value);
	}

}




#endif
