#include "Template.h"
#ifndef _LOCATION_MATRIX_H_
#define _LOCATION_MATRIX_H_
template <typename FLOAT>
__global__ void LocationMatrix2dKernel(int32_t* location, int64_t input_col, int64_t stride, int64_t kernel_size, int64_t S_filter) {

	//threadIdx.x  threadIdx.y  blockIdx.x  blockIdx.y ;
	//kernel_size  kernel_size  output_row  output_col ;
	//
	location[threadIdx.x * kernel_size + threadIdx.y + blockIdx.y * S_filter + blockIdx.x * S_filter * gridDim.y] =
		threadIdx.x * input_col + threadIdx.y + blockIdx.y * stride + 
		blockIdx.x * output_row * stride;

}

template <typename FLOAT>
int32_t* device_location_matrix2d(Tensor<FLOAT>* input, int64_t kernel_size, int64_t stride) {
	if (input->shape.size() < 2)
	{
		printf("this tensor's dimensions is too small so that it can't generate a location matrix!\n");
		return nullptr;
	}
	int64_t input_row = input->shape[input->shape.size() - 2];
	int64_t input_col = input->shape[input->shape.size() - 1];
	int64_t output_row = (input_row - kernel_size) / stride + 1;
	int64_t output_col = (input_col - kernel_size) / stride + 1;
	int64_t S_output = output_row * output_col;
	int64_t S_filter = kernel_size * kernel_size;
	dim3 block(kernel_size, kernel_size);
	dim3 grid(output_row, output_col);
	int32_t* location = nullptr;
	cudaMalloc((void**)&location, S_output * S_filter * sizeof(int32_t));

	LocationMatrix2dKernel << <grid,block >> > (location, input_col,stride, S_filter);
	cudaDeviceSynchronize();

	return location;
}





#endif // !_LOCATION_MATRIX_H_
