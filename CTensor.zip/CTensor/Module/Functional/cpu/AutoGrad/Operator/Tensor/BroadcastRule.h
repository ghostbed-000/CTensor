#include "Tensor.h"
#ifndef _BROADCAST_RULE_H_
#define _BROADCAST_RULE_H_
template <typename INT>
vector<INT> BroadcastRule(vector<INT> a,vector<INT> b){
	//check
	vector<INT> c;
	for(unsigned int i = 0;i < a.size(); i++){
		if(a[i] == b[i]){
			c.push_back(a[i]);
		}
		else if (a[i] != b[i] && (a[i] == 1 || b[i] == 1)){
			//it can be broadcasted!
			if(a[i] > b[i]){
				c.push_back(a[i]);
			}else{
				c.push_back(b[i]);
			}
		}
		else{
			printf("it can't be broadcasted!\n");
			break;
		}
	}
	return c;
}
//A shape vector with dimension less than 4 is stuffed with 1
vector<int64_t> shape_broadcast(vector<int64_t>& vec) {
	if (vec.size() == 4)
	{
		return vec;
	}
	vector<int64_t> tmp = vec;
	for (int i = 0; i < 4 - vec.size(); i++)
	{
		tmp.insert(tmp.begin(), 1);
	}

	return tmp;
}
vector<int64_t> stride_broadcast(vector<int64_t>& vec) {
	const int max_dim = 4;
	if (vec.size() == max_dim)
	{
		return vec;
	}
	vector<int64_t> tmp = vec;
	for (int i = 0; i < max_dim - vec.size(); i++)
	{
		tmp.insert(tmp.begin(), 0);
	}

	return tmp;
}
#endif // !_BROADCAST_RULE_H_


