#include "Template.h"
/*
* if an array's shape equal to [B,C,H,W]
	0  1  2  3
   [1][2][3][4] = 1 * B + 2 * C + 3 * H + 4 * W
  tensor.trnaspose(0,1);
	1  0  2  3
   [1][2][3][4] = 2 * B + 1 * C + 3 * H + 4 * W
*/

template <typename FLOAT> 
Tensor<FLOAT>*  Tensor<FLOAT>::transpose(int dim1,int dim2) {
	if (array == nullptr)
	{
		printf("Empty Tensor can't be transpose!\n");
		return nullptr;
	}
	if (dim1 > shape.size() || dim2 > shape.size() || dim1 < 0 || dim2 < 0)
	{
		printf("dim1 and dim2 should be at [0,%u]!\n", (unsigned int)shape.size());
		return nullptr;
	}
	
	Tensor<FLOAT>* NewTensor = new Tensor(array,shape,_requires_grad_);

	int64_t a = NewTensor->shape[dim1];
	int64_t b = NewTensor->shape[dim2];
	int64_t a1 = NewTensor->stride[dim1];
	int64_t b1 = NewTensor->stride[dim2];
	NewTensor->shape[dim1] = b;
	NewTensor->shape[dim2] = a;
	NewTensor->stride[dim1] = b1;
	NewTensor->stride[dim2] = a1;

	return NewTensor;
}

template <typename FLOAT>
void Tensor<FLOAT>::TransposeItself() {
	if (shape.size() < 2)
	{
		printf("Tensor should have more than 2 dimensions!\n");
		return;
	}
	if (array == nullptr)
	{
		printf("Empty Tensor can't be transpose!\n");
		return;
	}
	int dim1 = shape.size() - 1;
	int dim2 = shape.size() - 2;
	int64_t a = shape[dim1];
	int64_t b = shape[dim2];
	int64_t a1 = stride[dim1];
	int64_t b1 = stride[dim2];
	shape[dim1] = b;
	shape[dim2] = a;
	stride[dim1] = b1;
	stride[dim2] = a1;
}

