#include "Template.h"
#ifndef _TENSOR_GAUSSININT_H_
#define _TENSOR_GAUSSININT_H_



template <typename FLOAT>
__global__ void GaussinitKernel(FLOAT* d_array,FLOAT var,FLOAT mean, curandState* states) {
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_array[id] = curand_normal(&states[id]) * var + mean;
}

template <typename FLOAT>
void Tensor<FLOAT>::gaussinit(FLOAT var, FLOAT mean) {
	curandState* states;
	cudaMalloc(&states,_len_ * sizeof(curandState));
	srand((unsigned int)time(0));
	dim3 block(1);
	SetupCurandStates << <AutoAllocateGrid(shape), block >> > (states, time(0));
	cudaDeviceSynchronize();
	GaussinitKernel << <AutoAllocateGrid(shape), block >> > (array,var ,mean, states);
	cudaDeviceSynchronize();	

	cudaFree(states);


}

#endif