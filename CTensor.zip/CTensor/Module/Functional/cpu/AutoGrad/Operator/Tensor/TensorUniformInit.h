#include "Template.h"
#ifndef _TENSOR_UNIFORM_H_
#define _TENSOR_UNIFORM_H_
template <typename FLOAT>
__global__ void UniformKernel(FLOAT* d_array, FLOAT a, FLOAT b, curandState* states) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_array[id] = curand_uniform(&states[id]);
}

template <typename FLOAT>
void Tensor<FLOAT>::uniform(FLOAT a, FLOAT b) {
	curandState* states;
	cudaMalloc(&states, _len_ * sizeof(curandState));
	srand((unsigned int)time(0));
	dim3 block(1);
	SetupCurandStates << <AutoAllocateGrid(shape), block >> > (states, time(0));
	cudaDeviceSynchronize();
	UniformKernel << <AutoAllocateGrid(shape), block >> > (array, a, b, states);
	cudaDeviceSynchronize();

	cudaFree(states);

}

#endif