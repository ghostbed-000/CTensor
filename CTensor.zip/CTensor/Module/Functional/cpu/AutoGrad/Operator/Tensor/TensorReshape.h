#include "Template.h"
#ifndef _TENSOR_RESHAPE_H_
#define _TENSOR_RESHAPE_H_
template <typename FLOAT>
void Tensor<FLOAT>::reshape(vector<int64_t>& _shape) {
	int64_t len = 1;
	for (unsigned int i = 0; i < _shape.size(); i++)
	{
		len *= _shape[i];
	}
	if (len != _len_) {
		printf("the new size doesn't adapt to the before one!\n");
		return;
	}

	shape = _shape;
	size();

}
#endif