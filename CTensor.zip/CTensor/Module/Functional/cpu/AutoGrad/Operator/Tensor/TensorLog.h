#include "Template.h"
#ifndef _TENSOR_LOG_H_
#define _TENSOR_LOG_H_
template <typename FLOAT>
void Tensor<FLOAT>::log() { 

	for(int64_t i=0;i<_len_;i++){
		array[i] = log(array[i]);
	}

}




#endif
