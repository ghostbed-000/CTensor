#include "Template.h"

template <typename FLOAT>
int Tensor<FLOAT>::operator==(Tensor<FLOAT>* tensor) {
	int times = 0;

	if (tensor->shape.size() != shape.size())
	{
		printf("left's shape len isn't the same as right's shape\n");
		return -1;
	}
	for (unsigned int i = 0; i < shape.size(); i++)
	{
		if (tensor->shape[i] != shape[i])
		{
			times++;
		}
	}
	return times;
}