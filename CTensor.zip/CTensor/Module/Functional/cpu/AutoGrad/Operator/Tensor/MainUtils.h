#ifndef _MAIN_UTILS_H_
#define _MAIN_UTILS_H_

#include "TensorCheckShape.h"
#include "TensorArrange.h"
#include "TensorConstant.h"
#include "TensorDivided.h"
#include "TensorGaussInit.h"
#include "TensorUniformInit.h"
#include "TensorTranspose.h"
#include "TensorZero.h"
#include "TensorPrintArr.h"
#include "TensorReshape.h"
#include "TensorAdd.h"//warning
#include "TensorSub.h"
#include "TensorDotmul.h"
#include "TensorContiguous.h"
#include "TensorMean.h"
#include "TensorSum.h" 
#include "TensorPow.h"
#include "TensorExp.h"
#include "TensorLog.h"
//needy test
#include "TensorMul.h"
#include "TensorCopy.h" 
#include "TensorCat.h"
#include "TensorSplit.h"
#include "TensorMax.h"
#include "TensorConvd2d.h"
#include "TensorConvd2dGradient.h" 

















#endif
