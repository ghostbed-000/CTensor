#include "Template.h"
#ifndef _TENSOR_MEAN_H_
#define _TENSOR_MEAN_H_

template <typename FLOAT>
Tensor<FLOAT>* Tensor<FLOAT>::mean(int32_t dim) {
	Tensor<FLOAT>* out = sum(dim);
	out->divided((FLOAT)(shape[dim]));
	out->shape[dim] = 1;

	return out;
}

template <typename FLOAT>
Tensor<FLOAT>* Tensor<FLOAT>::mean(vector<int32_t> dim) {
	if (dim.size() < 2 || shape.size() < 2) {
		printf("Tensor's dimension should be more than 1 !\n");
		return nullptr;
	}
	int64_t N = shape[dim[0]];
	Tensor<FLOAT>* tmp = nullptr;
	Tensor<FLOAT>* out = sum(dim[0]);
	for (unsigned int i = 1; i < dim.size(); i++)
	{
		tmp = out;
		out = out->sum(dim[i]);
		delete(tmp);
		N *= shape[dim[i]];
		out->shape[dim[i]] = 1;
		out->_len_ /= shape[dim[i]];
	}
	out->divided((FLOAT)(N));
	return out;
}
#endif