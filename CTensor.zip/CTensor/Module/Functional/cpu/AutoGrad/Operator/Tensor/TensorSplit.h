#include "Template.h"
#ifndef _TENSOR_SPLIT_H_
#define _TENSOR_SPLIT_H_


template <typename FLOAT>
void Tensor<FLOAT>::split(Tensor<FLOAT>* input,vector<Tensor<FLOAT>*>& output, int32_t dim) {
	int64_t offset = 0;
	FLOAT* device = input->array;
	for (unsigned int i = 0; i < output.size(); i++)
	{
		output[i]->array = device + offset;
		output[i]->stride[dim] += offset;
		offset += output[i]->shape[dim] * output[i]->stride[dim];
	}

}


#endif