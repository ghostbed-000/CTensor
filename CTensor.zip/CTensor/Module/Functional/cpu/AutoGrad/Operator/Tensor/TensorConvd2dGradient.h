#include "LocationMatrix.h"
#ifndef _TENSOR_UNCONVD2D_H_
#define _TENSOR_UNCONVD2D_H_
/*
template <typename FLOAT>
__global__ void SumLinearGradientKernel(FLOAT* dliner, FLOAT* doutput)
{
	int64_t batch_page = threadIdx.y * blockDim.x * gridDim.x * gridDim.y * gridDim.z;
	int64_t out_channel_page = blockIdx.y * blockDim.x * gridDim.x * gridDim.z;
	int64_t in_channel_page = blockIdx.z * blockDim.x * gridDim.x;
	int64_t S_output_page = blockIdx.x * blockDim.x;

	dliner[threadIdx.x + S_output_page + in_channel_page + out_channel_page + batch_page] = 
		doutput[blockIdx.x + blockIdx.y * gridDim.x + threadIdx.y * gridDim.x * gridDim.y];
}
*/

template <typename FLOAT>
__global__ void LinearGradientKernel_1(FLOAT* dinput, FLOAT* doutput, FLOAT* filter, 
	int32_t* location,int64_t S_output, int64_t out_channel, int64_t S_input)
{

	for (int64_t j = 0; j < out_channel; j++)
	{
		for (int64_t i = 0; i < S_output; i++)
		{
			dinput[location[i * blockDim.x + threadIdx.x] + blockIdx.x * S_input + threadIdx.y * S_input * gridDim.x] += 
				filter[threadIdx.x + blockIdx.x * blockDim.x + j * blockDim.x * gridDim.x]
				* 
				doutput[i + j * S_output + threadIdx.y * S_output * out_channel];
			__syncthreads();
		}
	}
}
template <typename FLOAT>
__global__ void LinearGradientKernel_2(FLOAT* dfilter, FLOAT* doutput, FLOAT* input,
	int32_t* location, int64_t batch_size, int64_t S_input)
{
	int64_t V_kernel = blockDim.x * gridDim.x;
	for (int64_t j = 0; j < batch_size; j++)
	{
		for (int64_t i = 0; i < S_output; i++)
		{
			dfilter[threadIdx.x + blockIdx.x * blockDim.x + blockIdx.y * V_kernel] += 
				input[location[threadIdx.x + i * blockDim.x] + S_input * blockIdx.x + j * S_input * gridDim.x]
				* 
				doutput[i + blockIdx.y * S_output + j * S_output * gridDim.y];
			__syncthreads();
		}
	}
	
}

template <typename FLOAT>
Tensor<FLOAT>* Conv2dGradient(Tensor<FLOAT>* input, Tensor<FLOAT>* filter,int32_t* location, int32_t stride, Tensor<FLOAT>* doutput) {
	int64_t S_output;
	vector<int64_t> BroadcastsShape = shape_broadcast(input->shape);
	int64_t batch_size  = BroadcastsShape[0];
	int64_t in_channel  = BroadcastsShape[1];
	int64_t S_input     = BroadcastsShape[2] * BroadcastsShape[2];
	int64_t out_channel = filter->shape[0];
	int64_t S_filter    = filter->shape[filter->size() - 1] * filter->shape[filter->size() - 1];
	vector<int64_t> shape = { batch_size,out_channel * in_channel,S_output,S_filter };
	
	S_output = output->shape[output->shape.size() - 1] * output->shape[output->shape.size() - 2];

	dim3 block(S_filter,batch_size);
	//dim3 grid(S_output, out_channel, in_channel);
	dim3 grid(in_channel);

	LinearGradientKernel_1 << <grid, block >> > (input->gradient->array, doutput->array, filter->array,
		location, S_output, out_channel,S_input);
	dim3 block2(S_filter);
	dim3 grid2(in_channel, out_channel);
	LinearGradientKernel_2 << <grid2, block2 >> > (filter->gradient->array, doutput->array, input->array,
		location, batch_size, S_input);
	cudaDeviceSynchronize();

	return output;
}
#endif