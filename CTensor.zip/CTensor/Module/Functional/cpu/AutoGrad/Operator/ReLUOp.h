#include "Op.h"

#ifndef _RELU_OP_H_
#define _RELU_OP_H_
template <typename FLOAT>
__global__ void ReLUKernel(FLOAT* d_in, FLOAT* d_out) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	if (d_in[id] >= 0)
	{
		d_out[id] = d_in[id];
	}
	else
	{
		d_out[id] = 0;
	}
}

template <typename FLOAT>
__global__ void ReLUGradientKernel(FLOAT* d_in, FLOAT* d_in_grad, FLOAT* d_out, FLOAT* d_out_grad) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	if (d_in[id] >= 0)
	{
		d_in_grad[id] += d_out_grad[id];
	}
	else
	{
		d_in_grad[id] += 0;
	}
}

template <typename FLOAT>
class ReLUOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, ReLUKernel);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, ReLUGradientKernel);
	}
	~ReLUOp(){}
};

template <typename FLOAT>
Node<FLOAT>* ReLUNodeGenerator(Node<FLOAT>* input, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(input->value), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "ReLU");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* relu(Node<FLOAT>* input) {
		ReLUOp<FLOAT>* op = new ReLUOp<FLOAT>();
		Node<FLOAT>* x = ReLUNodeGenerator(input, op);
		op->compute(x);
		return x;
	}

}
#endif