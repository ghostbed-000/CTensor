#include "Op.h"
#ifndef _BATCH_NORM_AFFINE_OP_H_
#define _BATCH_NORM_AFFINE_OP_H_
template <typename FLOAT>
class BatchNormAffine2dOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> x = node->input2values();
		Tensor<FLOAT>* output = node->value;
		x[0]->dotmul(x[1], output);
		output->dotmul(x[2], output);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		vector<int64_t> dim = { 0,2 };
		if (x[0]->shape.size() == 4) {
			dim.push_back(3);
		}
		// dL / dbeta   = sum(dL / dy)
		Tensor<FLOAT>* sum_1 = doutput->sum(dim);
		input[2]->gradient->add(sum_1, input[2]->gradient);
		// dL / dx		= dL / dy * gammar
		doutput->dotmul(input[1], input[0]->gradient);
		// dL / dgammar = sum(dL / dy * x)
		doutput->dotmul(input[0], doutput);
		Tensor<FLOAT>* sum_2 = doutput->sum(dim);
		input[1]->gradient->add(sum_2, input[1]->gradient);
		delete(sum_1);
		delete(sum_2);
	}
	~BatchNormAffine2dOp(){}
};
template <typename FLOAT>
Node<FLOAT>* BatchNorm2dAffineNodeGenerator(Node<FLOAT>* input, Node<FLOAT>* gammar, Node<FLOAT>* beta, Op<FLOAT>* op = nullptr) {
	if (shape.size() < 3)
	{
		printf("the tensor which is BatchNorm2d should have at least three dimension!\n"); return;
	}
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	input_nodes->push_back(gammar);
	input_nodes->push_back(beta);
	vector<FLOAT> shape = input->shape;
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "BatchNorm2dAffine");
	return output_node;
}

namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* batch_norm2d_affine(Node<FLOAT>* input, Node<FLOAT>* gammar, Node<FLOAT>* beta) {
		BatchNorm2dAffineOp<FLOAT>* op = new BatchNorm2dAffineOp<FLOAT>();
		Node<FLOAT>* x = BatchNorm2dAffineNodeGenerator(input, gammar, beta, op);
		op->compute(x);
		return x;
	}

}


#endif