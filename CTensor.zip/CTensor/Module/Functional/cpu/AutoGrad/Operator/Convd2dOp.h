#include "Op.h"
#ifndef _CONVD_2D_OP_H
#define _CONVD_2D_OP_H

template <typename FLOAT>
class Convd2dOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		output->zero_();
		int32_t* location = device_location_matrix2d(input[0], input[1]->shape[input[1]->shape.size() - 1],node->param[0]);
		Conv2d(input[0], input[1], location,node->param[0], output);
	}

	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		Tensor<FLOAT>* location = device_location_matrix2d(input[0], input[1]->shape[input[1]->shape.size() - 1], node->param[0]);

		Conv2dGradient(input[0], input[1], location, node->param[0], doutput);
	}
	~Convd2dOp(){}
};

template <typename FLOAT>
Node<FLOAT>* Convd2dNodeGenerator(Node<FLOAT>* input, Node<FLOAT>* filter, int32_t stride, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	input_nodes->push_back(filter);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(input->value), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Convd2d");
	output_node->param(stride);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* conv2d(Node<FLOAT>* input, Node<FLOAT>* filter, int32_t stride) {
		Convd2dOp<FLOAT>* op = new Convd2dOp<FLOAT>();
		Node<FLOAT>* x = Convd2dNodeGenerator(input, filter, stride, op);
		op->compute(x);
		return x;
	}

}
#endif // !_CONVD_2D_OP_H
