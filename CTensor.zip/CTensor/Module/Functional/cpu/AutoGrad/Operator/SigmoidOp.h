#include "Op.h"

#ifndef _SIGMOID_OP_H_
#define _SIGMOID_OP_H_
template <typename FLOAT>
__global__ void SigmoidKernel(FLOAT* d_in, FLOAT* d_out) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_out[id] = powf(1 + fexp(-d_in[id]), -1);
}

template <typename FLOAT>
__global__ void SigmoidGradientKernel(FLOAT* d_in, FLOAT* d_in_grad, FLOAT* d_out, FLOAT* d_out_grad) {
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_in_grad[id] += d_out[id] * (1 - d_out[id]) * d_out_grad[id];
}

template <typename FLOAT>
class SigmoidOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, SigmoidKernel);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, SigmoidGradientKernel);
	}
	~SigmoidOp(){}
};

template <typename FLOAT>
Node<FLOAT>* SigmoidNodeGenerator(Node<FLOAT>* input, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(input->value), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Sigmoid");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* sigmoid(Node<FLOAT>* input) {
		SigmoidOp<FLOAT>* op = new SigmoidOp<FLOAT>();
		Node<FLOAT>* x = SigmoidNodeGenerator(input, op);
		op->compute(x);
		return x;
	}

}
#endif // !_SIN_OP_