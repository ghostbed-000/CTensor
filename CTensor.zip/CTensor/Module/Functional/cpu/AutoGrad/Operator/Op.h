#include "Tensor/MainUtils.h"
#include "Node/Node.h"
/*

	1.Remember that each operator generation requires writing its own generating function 
	after writing its forward and backward propogation function
	
	2.Remember the backpropagation gradient is cumulative and the chain derivative rule

	3.The forward and backward propagation of the operator is written according to the content
	of the node generator

*/
#ifndef _OP_H_ 
#define _OP_H_

#define UNUSED(x) (void)x

//start to write forward and backward propogation function
template<typename FLOAT>
class Op {
public:
	//forward compute
	virtual void compute(Node<FLOAT>* node) { UNUSED(node);}
	virtual void compute(Node<FLOAT>* node, Tensor<FLOAT>* one_hot_target) { UNUSED(node); UNUSED(one_hot_target);}
	virtual void compute() {};
	//backward compute
	virtual void gradient(Node<FLOAT>* node) { UNUSED(node);}
	virtual void gradient() {};
	//experimental compute
	//virtual void inverse_func(vector<Tensor<FLOAT>*> input,Tensor<FLOAT>* output);
	virtual Op() {};
};

//writing its own generating function at this
template<typename FLOAT>
void Node<FLOAT>::evaluate() {
	OPERATOR->compute(this);
}
template<typename FLOAT>
void Node<FLOAT>::gradient() {
	OPERATOR->gradient(this);
}
template<typename FLOAT>
int32_t Node<FLOAT>::dim() {
	if (value != nullptr)
	{
		return value->shape.size();
	}
	printf("Node %d value is none!\n",this->_node_id);
	return 0;
}

template<typename FLOAT>
Node<FLOAT>::~Node() {
	delete(OPERATOR);
	delete(value);
	delete(input);
	input = nullptr;
	value = nullptr;
	OPERATOR = nullptr;
}
namespace Functional {}

#endif // !

//OP EXAMPLE
#ifndef _IDENTITY_OP_
#define _IDENTITY_OP_

template <typename FLOAT>
class IdentityOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) { return; UNUSED(node); }
	void gradient(Node<FLOAT>* node) { return; UNUSED(node); }
};

template <typename FLOAT>
Node<FLOAT>* IdentityNodeGenerator(Tensor<FLOAT>* input, Op<FLOAT>* op) {
	Node<FLOAT>* output_node = new Node<FLOAT>(op, nullptr, new Tensor<FLOAT>(input->value), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Variable");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* Variable(Tensor<FLOAT>* input) {
		IdentityOp<FLOAT>* op = new IdentityOp<FLOAT>();
		Node<FLOAT>* x = SinNodeGenerator(input, op);
		return x;
	}
}

#endif