#include "Op.h"

#ifndef _SOFTMAX_OP_H_
#define _SOFTMAX_OP_H_
template <typename FLOAT>
__global__ void SoftmaxGradientKernel(FLOAT* d_tmp, FLOAT* d_out, FLOAT* d_out_grad,int64_t stride) {
	/*
		INPUT: [x_1,x_2.....,x_k]
		OUTPUT: sum(diag(INPUT) sub INPUT_TRANSPOSE matmul INPUT,  dimension)
	*/
	int64_t i = blockIdx.x * stride;
	int64_t j = blockIdx.y * stride;
	int64_t id += blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;

	d_tmp[id] += -1 * d_out[i] * d_out[j];
	if (i == j)
	{
		d_tmp[id] += d_out[i];
	}
	d_tmp[id] *= d_out_grad[j];

}
template <typename FLOAT>
__global__ void SoftmaxGradientKernel_2(FLOAT* d_input_grad, FLOAT* d_sum, int64_t input_stride, int64_t sum_stride) {

	d_input_grad[blockIdx.x * input_stride] += d_sum[blockIdx.x * sum_stride];

}

template <typename FLOAT>
class SoftmaxOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		cudaMemcpy(output->array, input[0]->array, input[0]->_len_ * sizeof(FLOAT), cudaMemcpyHostToHost);
		output->exp();
		Tensor<FLOAT>* sum_1 = output->sum(node->param[0]);
		output->divided(sum_1, output);
		delete(sum_1);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		int dim = node->param[0];
		FLOAT* tmp_output_array = output->array;
		FLOAT* tmp_input_grad = input[0]->array->gradient;
		FLOAT* tmp_output_grad = output->array->gradient;
		int tmp_len = output->shape[dim];
		for (int i = 0; i < (output->_len_ / output->shape[dim]); i++) {
			Tensor<FLOAT> tmp({ tmp_len,tmp_len }, false);
			Tensor<FLOAT>* sum_1 = nullptr;
			dim3 grid(tmp_len, tmp_len); dim3 block(1);
			SoftmaxGradientKernel << <grid, block >> > (tmp.array, tmp_output_array, tmp_output_grad, output->stride[dim]);
			cudaDeviceSynchronize();
			sum_1 = tmp.sum(dim);
			SoftmaxGradientKernel << <tmp_len, block >> > (tmp_input_grad, sum_1, input[0]->gradient->stride[dim], tmp_len);
			cudaDeviceSynchronize();
			delete(tmp);
			tmp_input_grad += input[0]->gradient->stride[dim];
			tmp_output_array += output->stride[dim];
		}

	}
};

template <typename FLOAT>
Node<FLOAT>* SoftmaxNodeGenerator(Node<FLOAT>* input,int32_t dim, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(input->value), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Softmax");
	output_node->param(dim);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* softmax(Node<FLOAT>* input, int32_t dim) {
		SoftmaxOp<FLOAT>* op = new SoftmaxOp<FLOAT>();
		Node<FLOAT>* x = SoftmaxNodeGenerator(input, dim, op);
		op->compute(x);
		return x;
	}

}

#endif