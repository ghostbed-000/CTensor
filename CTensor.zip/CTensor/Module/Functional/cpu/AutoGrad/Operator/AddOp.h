#include "Op.h"
#ifndef _ADD_OP_H_
#define _ADD_OP_H_

template <typename FLOAT>
class AddOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		input[0]->add(input[1], output);

	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		Tensor<FLOAT>* tmp_0 = input[0]->gradient->add(doutput, nullptr, true);
		input[0]->gradient->add(tmp_0, input[0]->gradient);
		Tensor<FLOAT>* tmp_1 = input[1]->gradient->add(doutput, nullptr, true);
		input[1]->gradient->add(tmp_1, input[1]->gradient);

		delete(tmp_0);
		delete(tmp_1);
	}
	~AddOp(){}
};

template <typename FLOAT>
Node<FLOAT>* AddNodeGenerator(Node<FLOAT>* left, Node<FLOAT>* right, Op<FLOAT>* op) {
	CheckShapeEqual(left->shape, right->shape);
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(left); input_nodes->push_back(right);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(left->shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Add");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* add(Node<FLOAT>* left, Node<FLOAT>* right) {
		AddOp<FLOAT>* op = new AddOp<FLOAT>();
		Node<FLOAT>* x = AddNodeGenerator(left, right, op);
		op->compute(x);
		return x;
	}

}

#endif // !_ADD_OP_H_
