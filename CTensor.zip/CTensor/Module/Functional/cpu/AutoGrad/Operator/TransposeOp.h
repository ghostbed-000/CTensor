#include "Op.h"
#ifndef _TRANSPOSE_OP_H_
#define _TRANSPOSE_OP_H_

template <typename FLOAT>
//warning: it haven't been tested!//be careful ,it has many traps!!!
//permute <=> Transpose
class TranposeOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		return;
		UNUSED(node);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		cudaMemcpy(input[0]->value->gradient->array, output->gradient->array,
			output->_len_ * sizeof(FLOAT), cudaMemcpyDeviceToDevice);
	}
	~TranposeOp(){}
};

template <typename FLOAT>
Node<FLOAT>* TranposeNodeGenerator(Node<FLOAT>* input, int32_t dim1, int32_t dim2, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Tensor<FLOAT>* value = input->transpose(dim1, dim2);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, value, _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Tranpose");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* tranpose(Node<FLOAT>* input, int32_t dim1, int32_t dim2) {
		TranposeOp<FLOAT>* op = new TranposeOp<FLOAT>();
		Node<FLOAT>* x = TranposeNodeGenerator(input,dim1,dim2, op);
		op->compute(x);
		return x;
	}

}


#endif // !_TRANSPOSE_OP_H_