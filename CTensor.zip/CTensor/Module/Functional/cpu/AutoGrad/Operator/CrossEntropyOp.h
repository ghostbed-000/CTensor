#include "Op.h"

#ifndef _CROSS_ENTROPY_OP_H_
#define _CROSS_ENTROPY_OP_H_
template <typename FLOAT>
__global__ void CrossEntropyGradientKernel(FLOAT* d_in, FLOAT* d_target, FLOAT* d_in_grad) {
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_in_grad[id] += ((1 - d_target[id]) / (1 - d_in[id])) - (d_target[id] / d_in[id])
}

template <typename FLOAT>
class CrossEntropyLossOp : public Op<FLOAT> {
	Tensor<FLOAT>* target = nullptr;
public:
	void compute(Node<FLOAT>* input) { UNUSED(input); }
	FLOAT compute(Node<FLOAT>* input, Tensor<FLOAT>* one_hot_target) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		if (input->shape.size() != one_hot_target->shape.size()) {
			printf("the target tensor's shape size isn't same as input's size!\n");
		}
		for (unsigned int i = 0; i < input->shape.size();i++) {
			if (input->shape[i] != one_hot_target[i]) {
				printf("the target tensor's shape isn't same as input's shape!\n");
			}
		}
		target = one_hot_target;
		Tensor<FLOAT> tmp(input[0],false,false,true);
		tmp->log();
		tmp->dotmul(one_hot_target,tmp);
		vector<int64_t> dim;
		for (unsigned int i = 0; i < input->shape.size(); i++) {
			dim.push_back(i);
		}
		Loss = tmp->sum(dim);
		FLOAT loss[1];
		cudaMemcpy(loss, Loss->array, sizeof(FLOAT), cudaMemcpyDeviceToHost);
		cudaFree(Loss);
		cudaMemcpy(input->value->array, loss, sizeof(FLOAT), cudaMemcpyHostToDevice);
		return ((- 1.0) * loss[0]) / input[0]->_len_;
	}

	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		dim3 block(1);
		CrossEntropyGradientKernel << <AutoAllocateGrid(input->shape), block >> > (input[0]->array, target->array,input[0]->gradient->array);
		cudaDeviceSynchronize();
	}
	~CrossEntropyLossOp(){}
};

template <typename FLOAT>
Node<FLOAT>* CrossEntropyNodeGenerator(Node<FLOAT>* input, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(0.0), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "CrossEntropy");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	FLOAT cross_entropy_loss(Node<FLOAT>* input,Tensor<FLOAT>* one_hot_target) {
		CrossEntropyOp<FLOAT>* op = new CrossEntropyOp<FLOAT>();
		Node<FLOAT>* x = CrossEntropyNodeGenerator(input, op);
		return op->compute(x, one_hot_target);
	}

}

#endif