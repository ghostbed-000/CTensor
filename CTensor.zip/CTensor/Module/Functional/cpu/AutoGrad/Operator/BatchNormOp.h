#include "Op.h"
#ifndef _BATCH_NORM_OP_H_
#define _BATCH_NORM_OP_H_
template <typename FLOAT>
class BatchNorm2dOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> x = node->input2values();
		delete(x[1]);delete(x[2]);
		Tensor<FLOAT>* x_hat = node->value;
		vector<int64_t> dim = { 0,2 };
		if (x[0]->shape.size() == 4) {
			dim.push_back(3);
		}
		else {
			printf("you couldn't used batch_norm2d with a tensor's dimensions less than 3 dimension!\n");
			return;
		}
		x[1] = x[0]->mean(dim);
		x[0]->sub(x[1], x[2]);
		x[2]->dotmul(x[2], x[2]);
		x[2] = x[2]->sum(dim);
		x[2]->operator+(node->param[0]);
		x[2]->pow((FLOAT)0.5);
		x_hat->sub(x[1], x_hat);
		x_hat->divided(x[2], x_hat);
		node->input[0][1]->value = x[1];
		node->input[0][2]->value = x[2];
	}
	void gradient(Node<FLOAT>* node) {
		int64_t N = 1;
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		vector<int64_t> dim = { 0,2 }; N *= doutput->shape[0] * doutput->shape[2];
		if (x[0]->shape.size() == 4) {
			dim.push_back(3);
			N *= doutput->shape[3];
		}
		if ((FLOAT)N == nan) { printf("BatchNorm2d occur nan!\n"); return; }
		input[2]->operator*((FLOAT)N);
		input[2]->pow(-1.0);
		Tensor<FLOAT>* sum_1 = doutput->sum(dim);
		Tensor<FLOAT> copy(doutput,false, false,true);
		doutput->operator*((FLOAT)N);
		copy.dotmul(node->value, &copy);
		Tensor<FLOAT>* sum_2 = copy.sum(dim);
		node->value->dotmul(sum_2, node->value);
		doutput->sub(sum_1, doutput);
		doutput->sub(node->value, doutput);
		doutput->dotmul(input[2], doutput);
		input[0]->add(doutput, input[0]);
		delete(sum_1);
		delete(sum_2);
	}
};

template <typename FLOAT>
Node<FLOAT>* BatchNorm2dNodeGenerator(Node<FLOAT>* input, Node<FLOAT>* mean, Node<FLOAT>* var, int32_t eps = 0.00001, Op<FLOAT>* op = nullptr) {
	if (shape.size() < 3)
	{
		printf("the tensor which is BatchNorm2d should have at least three dimension!\n"); return;
	}
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	input_nodes->push_back(mean);
	input_nodes->push_back(var);
	vector<FLOAT> shape = input->shape;
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "BatchNorm2d");
	output_node->param.push_back(eps);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* batch_norm2d(Node<FLOAT>* input, Node<FLOAT>* mean, Node<FLOAT>* var, int32_t eps = 0.00001) {
		BatchNorm2dOp<FLOAT>* op = new BatchNorm2dOp<FLOAT>();
		Node<FLOAT>* x = BatchNorm2dNodeGenerator(input, mean, var, eps, op);
		op->compute(x);
		return x;
	}

}
#endif