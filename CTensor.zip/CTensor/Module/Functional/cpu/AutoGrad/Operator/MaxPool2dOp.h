#include "Op.h"
#ifndef _MAX_POOL_2D_OP_H_
#define _MAX_POOL_2D_OP_H_ 

template <typename FLOAT> 
__global__ void MaxPoolKernel(FLOAT* d_input,FLOAT* d_out,int64_t* d_input_stride, int64_t* d_out_stride,
	int64_t kernel_size, int64_t stride) {
	int64_t in_id  = threadIdx.x * d_input_stride[0]
		+ threadIdx.y * d_input_stride[1]
		+ blockIdx.x * d_input_stride[2] * stride
		+ blockIdx.y * d_input_stride[3] * stride;
	int64_t out_id = CudaId(d_out_stride);
	FLOAT max = d_input[in_id];
	int64_t max_id = in_id;
	int64_t tmp_id;
	for (int64_t i = 0; i < kernel_size; i++) {
		for (int64_t j = 0; j < kernel_size; j++) {
			tmp_id = in_id + j + i * d_input_stride[2];
			if (max <= d_input[tmp_id]) {
				max_id = tmp_id;
				max = d_input[max_id];
			}
			else {
				d_input[tmp_id] = 0;
			}
		}
	}
	d_out[out_id] = max;
}
template <typename FLOAT>
__global__ void MaxPoolGradientKernel(FLOAT* d_input, FLOAT* d_input_grad, FLOAT* d_out_grad,
	int64_t* d_input_stride, int64_t* d_out_stride, int64_t kernel_size, int64_t stride) {
	int64_t in_id = threadIdx.x * d_input_stride[0]
		+ threadIdx.y * d_input_stride[1]
		+ blockIdx.x * d_input_stride[2] * stride
		+ blockIdx.y * d_input_stride[3] * stride;
	int64_t out_id = CudaId(d_out_stride);
	int64_t tmp_id;
	for (int64_t i = 0; i < kernel_size; i++) {
		for (int64_t j = 0; j < kernel_size; j++) {
			tmp_id = in_id + j + i * d_input_stride[2];
			if (d_input[tmp_id] != 0) {
				d_input_grad[tmp_id] += d_out_grad[out_id];
				break;
			}
		}
	}
}

template <typename FLOAT>
class MaxPool2dOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		int dim = (int)output->shape.size();
		vector<int64_t> BroadcastShape = shape_broadcast(output->shape);
		dim3 block(BroadcastShape[dim - 4], BroadcastShape[dim - 3]);//block(B,C)
		dim3 grid(BroadcastShape[dim - 2], BroadcastShape[dim - 1]);//grid(H,W)
		int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(input[0]->stride));
		int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(doutput->stride));
		MaxPoolKernel << <grid, block >> > (input[0]->array, output->array, d_s1, d_s2,node->param[0], node->param[1]);
		cudaDeviceSynchronize();
		cudaFree(d_s1);
		cudaFree(d_s2);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		int dim = (int)doutput->shape.size();
		vector<int64_t> BroadcastShape = shape_broadcast(output->shape);
		dim3 block(BroadcastShape[dim - 4], BroadcastShape[dim - 3]);//block(B,C)
		dim3 grid(BroadcastShape[dim - 2], BroadcastShape[dim - 1]);//grid(H,W)
		int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(input[0]->stride));
		int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(doutput->stride));
		MaxPoolGradientKernel << <grid, block >> > (input[0]->array, input[0]->gradient->array, doutput->array, 
			d_s1, d_s2, node->param[0], node->param[1]);
		cudaDeviceSynchronize();
		cudaFree(d_s1);
		cudaFree(d_s2);
	}
	~MaxPool2dOp(){}
};

template <typename FLOAT>
Node<FLOAT>* MaxPool2dNodeGenerator(Node<FLOAT>* input, int32_t kernel_size,int32_t stride, Op<FLOAT>* op) {
	if (shape[shape.size() - 1] < 2)
	{
		printf("the tensor which is maxpool should have at least two dimension!\n"); return;
	}
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	vector<FLOAT> shape = input->shape;
	shape[shape.size() - 1] = (shape[shape.size() - 1] - kernel_size) / stride + 1;
	shape[shape.size() - 2] = (shape[shape.size() - 2] - kernel_size) / stride + 1;
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "MaxPool2d");
	output_node->param.push_back(kernel_size);
	output_node->param.push_back(stride);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* max_pool2d(Node<FLOAT>* input, int32_t kernel_size, int32_t stride) {
		MaxPool2dOp<FLOAT>* op = new MaxPool2dOp<FLOAT>();
		Node<FLOAT>* x = MaxPool2dNodeGenerator(input, kernel_size, stride, op);
		op->compute(x);
		return x;
	}

}

#endif // !_MAX_POOL_2D_OP_H_
