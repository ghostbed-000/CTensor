#include "Op.h"
#ifndef _PAD_OP_H_
#define _PAD_OP_H_
template <typename FLOAT>
__global__ void PadKernel(FLOAT* d_in, FLOAT* d_out,int32_t pad) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_out[id] = d_in[id + pad + pad * gridDim.y];
}

template <typename FLOAT>
__global__ void PadGradientKernel(FLOAT* d_in_grad, FLOAT* d_out_grad, int32_t pad) {
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_in_grad[id] += d_out_grad[id + pad + pad * gridDim.y];
}


template <typename FLOAT>
class PadOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		dim3 block(1);
		PadKernel << <AutoAllocateGrid(input->shape), block >> > (input[0]->array, output->array, node->param[0]);
		cudaDeviceSynchronize();
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		dim3 block(1);
		PadGradientKernel << <AutoAllocateGrid(input->shape), block >> > (input[0]->gradient->array, doutput->array, node->param[0]);
		cudaDeviceSynchronize();
	}
	~PadOp(){}
};

template <typename FLOAT>
Node<FLOAT>* PadNodeGenerator(Node<FLOAT>* input, int32_t pad, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input); input_nodes->push_back(learning_parameter);
	vector<int64_t> shape = input[0]->shape;
	shape[shape.size() - 1] += 2;
	shape[shape.size() - 2] += 2];
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Pad");
	output_node->param.push_back(pad);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* pad(Node<FLOAT>* input,int32_t pad) {
		PadOp<FLOAT>* op = new PadOp<FLOAT>();
		Node<FLOAT>* x = PadNodeGenerator(input, pad, op);
		op->compute(x);
		return x;
	}

}
#endif // !1
