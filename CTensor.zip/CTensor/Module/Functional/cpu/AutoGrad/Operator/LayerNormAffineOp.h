#include "Op.h"
#ifndef _LAYER_NORM_AFFINE_OP_H_
#define _LAYER_NORM_AFFINE_OP_H_
template <typename FLOAT>
class LayerNormAffine2dOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> x = node->input2values();
		Tensor<FLOAT>* output = node->value;
		x[0]->dotmul(x[1], output);
		output->dotmul(x[2], output);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		vector<int64_t> dim = { 1,2 };
		if (x[0]->shape.size() == 4) {
			dim.push_back(3);
		}
		// dL / dbeta   = sum(dL / dy)
		Tensor<FLOAT>* sum_1 = doutput->sum(dim);
		input[2]->gradient->add(sum_1, input[2]->gradient);
		// dL / dx		= dL / dy * gammar
		doutput->dotmul(input[1], input[0]->gradient);
		// dL / dgammar = sum(dL / dy * x)
		doutput->dotmul(input[0], doutput);
		Tensor<FLOAT>* sum_2 = doutput->sum(dim);
		input[1]->gradient->add(sum_2, input[1]->gradient);
		delete(sum_1);
		delete(sum_2);
	}
	~LayerNormAffine2dOp(){}
};
template <typename FLOAT>
Node<FLOAT>* LayerNorm2dAffineNodeGenerator(Node<FLOAT>* input, Node<FLOAT>* gammar, Node<FLOAT>* beta, Op<FLOAT>* op = nullptr) {
	if (shape.size() < 3)
	{
		printf("the tensor which is LayerNorm2dAffine should have at least three dimension!\n"); return;
	}
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	input_nodes->push_back(gammar);
	input_nodes->push_back(beta);
	vector<FLOAT> shape = input->shape;
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "LayerNorm2dAffine");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* layer_norm2d_affine(Node<FLOAT>* input, Node<FLOAT>* gammar, Node<FLOAT>* beta) {
		LayerNorm2dOp<FLOAT>* op = new LayerNorm2dOp<FLOAT>();
		Node<FLOAT>* x = LayerNorm2dAffineNodeGenerator(input, gammar, beta, op);
		op->compute(x);
		return x;
	}

}



#endif