
//single in , single out
#include "Operator/Dropout.h"
#include "Operator/OneHot.h"
#include "Operator/SinOp.h"
#include "Operator/CosOp.h"
#include "Operator/ExpOp.h"
#include "Operator/LnOp.h"
#include "Operator/LeakyReLUOp.h"
#include "Operator/ReLUOp.h"
#include "Operator/TanhOp.h"
#include "Operator/SigmoidOp.h"
#include "Operator/SiLUOp.h"
#include "Operator/TransposeOp.h"  
#include "Operator/PadOp.h"
#include "Operator/MaxPool2dOp.h"//needy test
#include "Operator/UpsampleNearest2d.h"//needy test
#include "Operator/SoftmaxOp.h"//needy test

//multiple in, single out
#include "Operator/MatMulOp.h"
#include "Operator/Convd2dOp.h"
#include "Operator/AddOp.h"
#include "Operator/BatchNormOp.h"
#include "Operator/BatchNormAffineOp.h"
#include "Operator/LayerNormOp.h"
#include "Operator/LayerNormAffineOp.h"

//multiple in with param, single out
#include "Operator/Concat.h"

//others
#include "Operator/CrossEntropyOp.h"

