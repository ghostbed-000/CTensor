#include "OperatorUtils.h" 
#include <queue>

#ifndef _GRAPH_H_
#define _GRAPH_H_

using std::queue;
/*
	Graph is used to execute the neural network forward-propagating and backward-propagating
*/
template <typename FLOAT>
class Graph{
private:
	queue<Node<FLOAT>*> topo_list;

public:
	Graph(Node<FLOAT>* output,bool retain_grad);
	void _BFS_(Node<FLOAT>* node,bool retain_grad);
	void Gradient(Node<FLOAT>* node);
	//if it is a static calculate graph
	void static_forward();

};
//Node
template <typename FLOAT>
Node<FLOAT>::backward(Tensor<FLOAT>* output_grad,bool retain_grad){
	if(output_grad != nullptr){
		if(output_grad->_len_ == value->_len_){
			value->gradient = output_grad;
		}else{
			printf("these tensors don't match!");
		}	
	}
	else {
		value->gradient = new Tensor<FLOAT>(value->shape,false);
		value->gradient->constant_(1.0);
	}
	Graph<FLOAT> gp(this,retain_grad);
	for (unsigned int i = 0; i < _NODE_STACK_.size(); i++)
	{
		if ((Node<FLOAT>*)_NODE_STACK_[i]->value->_retain_grad_ == false)
		{
			delete((Node<FLOAT>*)_NODE_STACK_[i]);
		}
	}
	_NODE_STACK_.empty();
}

//Graph
template <typename FLOAT>
Graph<FLOAT>::Graph(Node<FLOAT>* output,bool retain_grad){
	_BFS_(Node<FLOAT>* output,retain_grad);
}

template <typename FLOAT>
Graph<FLOAT>::Gradient(Node<FLOAT>* node){
	//value initial
	if(node->value != nullptr){
		if(node->value->gradient == nullptr && node->value->_requires_grad_){
			node->value->gradient = new Tensor<FLOAT>(node->value->shape,false);
		}
	}
	if(input != nullptr){
		vector<Node<FLOAT>*>* input = node->input;
		for(unsigned int i = 0 ; i < (*input)[i] ; i++){
			Node<FLOAT>* tmp_node = (*input)[i];
			if(tmp_node->value != nullptr){
				if(tmp_node->value->gradient == nullptr && node->value->_requires_grad_){
					tmp_node->value->gradient = new Tensor<FLOAT>(tmp_node->value->shape,false);
				}
			}		
		}
	}
	node->gradient();
}

template <typename FLOAT>
void Graph<FLOAT>::_BFS_(Node<FLOAT>* node,bool retain_grad){
	if(topo_list.empty() == 0){
		topo_list.pop();
	}	
	node->leave();
	Gradient();
	vector<Node<FLOAT>*>* input = node->input;
	for(unsigned int i = 0;i < input->size();i++)
	{
		if((*input)[i]->is_visited){
			topo_list.push((*input)[i]);
			(*input)[i]->visit();
		}
	}
	if(!retain_grad && !node->value->_retain_grad_){	
		delete(node->value->gradient);
		node->value->gradient = nullptr;
	}
	if (topo_list.size() != 0)
	{
		_BFS_(topo_list[0]);
	}
	
}
template <typename FLOAT>
void Graph<FLOAT>::static_forward() {}

#endif
