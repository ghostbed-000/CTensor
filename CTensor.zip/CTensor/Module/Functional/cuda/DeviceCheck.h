
/*
	if you want to use the cuda operator please #define IS_CUDA_ON
	and comment out other IS_XXX_ON in other DeviceCheck file

*/
#define IS_CUDA_ON
#ifdef IS_CUDA_ON
#include "AutoGrad/Graph.h"
namespace CTensor {
#define CTensorDevice "cuda"

}
#endif
