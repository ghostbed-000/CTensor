#include "Op.h"
#ifndef _EMBEDDING_H_
#define _EMBEDDING_H_
template <typename FLOAT>
__global__ void EmbeddingKernel(int64_t* input,FLOAT* weight, FLOAT* out,int64_t batch_stride, int64_t input_words_num_stride) {

	//batch_size   input_words_num  vocab_dim
	//blockIdx.x   blockIdx.y       blockIdx.z
	int64_t in_id  = blockIdx.x * gridDim.y + blockIdx.y;
	int64_t out_id = blockIdx.x * batch_stride + blockIdx.y * input_words_num_stride + blockIdx.z;
	out[out_id] = weight[input[in_id] * gridDim.z + blockIdx.z];
}
template <typename FLOAT>
__global__ void EmbeddingGradientKernel(int64_t* input, FLOAT* dweight, FLOAT* dout, int64_t batch_size, int64_t input_words_num) {

	//vocab_dim
	//blockIdx.x
	int64_t id = blockIdx.x;

	for (int64_t i = 0; i < batch_size; i++)
	{
		for (int64_t j = 0; j < input_words_num; j++)
		{
			dweight[id + input[j + i * input_words_num] * gridDim.x] += dout[id + j * gridDim.x + i * gridDim.x * input_words_num];
		}
	}
	
}

template <typename FLOAT>
class EmbeddingOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;

		dim3 grid(input[0]->shape[0], input[0]->shape[1], output->shape[2]);//(batch_size,input_words_num,vocab_dim)
		dim3 block(1);
		EmbeddingKernel << <grid, block >> > ((int64_t*)input[0]->array, input[1]->array, output->array,
			output->stride[0], output->stride[1]);

		cudaDeviceSynchronize();

	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		dim3 grid(input[1]->shape[1]);//(vocab_dim)
		dim3 block(1);
		EmbeddingGradientKernel << <grid, block >> > ((int64_t*)(input[0]->array), input[1]->gradient->array, doutput->array, 
			input[0]->shape[0], doutput->shape[1]);

		cudaDeviceSynchronize();

	}
};

template <typename FLOAT>
Node<FLOAT>* EmbeddingNodeGenerator(Node<int64_t>* input, Node<FLOAT>* weight, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	if (input->value->shape.size() != 2 && weight->value->shape.size() != 2)
	{
		std::cout << "every embedding's input tensor must be 2D!\n";
		exit(1);
	}
	input_nodes->push_back((Node<FLOAT>*)input); 
	input_nodes->push_back(weight);
	vector<int64_t> shape = input->value->shape;
	shape.push_back(weight->value->shape[1]);//insert vocab_dim to out_shape
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Embedding");
	vector<int64_t>().swap(shape);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* embedding(Node<int64_t>* input, Node<FLOAT>* weight) {
		input->value->_retain_grad_ == false;
		EmbeddingOp<FLOAT>* op = new EmbeddingOp<FLOAT>();
		Node<FLOAT>* x = EmbeddingNodeGenerator<FLOAT>(input, weight, op);
		op->compute(x);
		return x;
	}

}









#endif