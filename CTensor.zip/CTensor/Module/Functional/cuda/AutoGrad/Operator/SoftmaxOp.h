#include "Op.h"

#ifndef _SOFTMAX_OP_H_
#define _SOFTMAX_OP_H_
template <typename FLOAT>
__global__ void SoftmaxGradientKernel(FLOAT* d_in_grad, FLOAT* d_out, FLOAT* d_out_grad,
	int64_t* stride, int64_t dim_len,int32_t dim, int64_t* diff,int64_t* out_stride) {
	/*
		softmax(Z): [a_1,a_2.....,a_k]
		dsoftmax(softmax(Z)) = diag(softmax(Z)) - softmax(Z)_TRANSPOSE * softmax(Z)
		dZ = dsoftmax(softmax(Z)) * dOUTPUT
	*/
	int64_t in_id = CudaId(stride);
	int64_t tmp   = CudaId(diff) * out_stride[dim];
	int64_t out_id = CudaId(out_stride) - tmp;
	//printf("%d", out_id);

	for (int64_t i = 0; i < dim_len; i++)
	{
		int64_t index = out_id + i * out_stride[dim];
		if (i == CudaId(diff))
		{
			d_in_grad[in_id] += d_out_grad[index] * d_out[index] * (1 - d_out[index]);
		}
		else {
			d_in_grad[in_id] += d_out_grad[index] * (- 1.0) * (d_out[out_id + tmp] * d_out[index]);
		}
	}
}

template <typename FLOAT>
class SoftmaxOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		cudaMemcpy(output->array, input[0]->array, input[0]->_len_ * sizeof(FLOAT), cudaMemcpyHostToHost);
		output->exp();
		Tensor<FLOAT>* sum = output->sum(node->param[0]);
		output->divide(sum, output);

		vector<Tensor<FLOAT>*>().swap(input);
		delete(sum);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		vector<int64_t>& BroadcastShape = shape_broadcast(input[0]->shape);

		int32_t dim = node->param[0] + BroadcastShape.size() - input[0]->shape.size();
		int32_t dim_len = BroadcastShape[dim];
		//[0,0,1,0]
		int64_t diff[4] = { 0 }; diff[dim] = input[0]->stride[node->param[0]];
		int64_t* d_diff = nullptr;
		cudaMalloc((void**)&d_diff, 4 * sizeof(int64_t));
		cudaMemcpy(d_diff, diff, 4 * sizeof(int64_t), cudaMemcpyHostToDevice);
		

		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)
		int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(input[0]->stride));
		int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(output->stride));
		SoftmaxGradientKernel << <grid, block >> >
			(input[0]->gradient->array, output->array, output->gradient->array, d_s1, dim_len,dim, d_diff, d_s2);
		cudaDeviceSynchronize();
		vector<Tensor<FLOAT>*>  ().swap(input);
		vector<int64_t>().swap(BroadcastShape);
		cudaFree(d_s1);
		cudaFree(d_s2);
		cudaFree(d_diff);
	}
};

template <typename FLOAT>
Node<FLOAT>* SoftmaxNodeGenerator(Node<FLOAT>* input,int32_t dim, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	if (dim < 0)
	{
		dim = input->value->shape.size() + dim;
	}
	input_nodes->push_back(input);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(input->value), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Softmax");
	output_node->param.push_back(dim);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* softmax(Node<FLOAT>* input, int32_t dim) {
		SoftmaxOp<FLOAT>* op = new SoftmaxOp<FLOAT>();
		Node<FLOAT>* x = SoftmaxNodeGenerator(input, dim, op);
		op->compute(x);
		return x;
	}

}

#endif