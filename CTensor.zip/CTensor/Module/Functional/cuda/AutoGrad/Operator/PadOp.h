#include "Op.h"
#ifndef _PAD_OP_H_
#define _PAD_OP_H_
template <typename FLOAT>
__global__ void PadKernel(FLOAT* d_in, FLOAT* d_out,int32_t pad, int64_t* d_input_stride, int64_t* d_out_stride) {

	int64_t in_id = CudaId(d_input_stride);
	int64_t out_id = CudaId(d_out_stride) + pad + pad * d_out_stride[2];
	d_out[out_id] = d_in[in_id];
}

template <typename FLOAT>
__global__ void PadGradientKernel(FLOAT* d_in_grad, FLOAT* d_out_grad, int32_t pad, int64_t* d_input_stride, int64_t* d_out_stride) {
	int64_t in_id = CudaId(d_input_stride);
	int64_t out_id = CudaId(d_out_stride) + pad + pad * d_out_stride[2];
	d_out_grad[out_id] += d_in_grad[in_id];
}


template <typename FLOAT>
class PadOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		vector<int64_t> BroadcastShape = shape_broadcast(input[0]->shape);
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)
		int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(input[0]->stride));
		int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(output->stride));
		PadKernel << <grid, block >> > (input[0]->array, output->array, node->param[0], d_s1, d_s2);
		cudaDeviceSynchronize();
		vector<Tensor<FLOAT>*>().swap(input);
		cudaFree(d_s1);
		cudaFree(d_s2);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*>& input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		vector<int64_t> BroadcastShape = shape_broadcast(input[0]->shape);
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)
		int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(input[0]->stride));
		int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(doutput->stride));
		PadGradientKernel << <grid, block >> > (input[0]->gradient->array, doutput->array, node->param[0], d_s1, d_s2);
		cudaDeviceSynchronize();
		vector<Tensor<FLOAT>*>().swap(input);
		cudaFree(d_s1);
		cudaFree(d_s2);
	}
	~PadOp(){}
};

template <typename FLOAT>
Node<FLOAT>* PadNodeGenerator(Node<FLOAT>* input, int32_t pad, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	vector<int64_t> out_shape = input->value->shape;
	out_shape[out_shape.size() - 1] += 2 * pad;
	out_shape[out_shape.size() - 2] += 2 * pad;
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(out_shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Pad");
	output_node->param.push_back(pad);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* pad(Node<FLOAT>* input,int32_t pad) {
		PadOp<FLOAT>* op = new PadOp<FLOAT>();
		Node<FLOAT>* x = PadNodeGenerator(input, pad, op);
		op->compute(x);
		return x;
	}

}
#endif // !1
