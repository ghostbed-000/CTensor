#include "Op.h"
#ifndef _ADD_OP_H_
#define _ADD_OP_H_

template <typename FLOAT>
class AddOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		Tensor<FLOAT>* left  = node->input[0][0]->value;
		Tensor<FLOAT>* right = node->input[0][1]->value;
		Tensor<FLOAT>* output = node->value;
		left->add(right, output);
	}
	void gradient(Node<FLOAT>* node) {
		Tensor<FLOAT>* left = node->input[0][0]->value;
		Tensor<FLOAT>* right = node->input[0][1]->value;
		Tensor<FLOAT>* doutput = node->value->gradient;
		//this can prevent dead lock!
		Tensor<FLOAT>* tmp_0 = left->gradient->add(doutput, nullptr, true);
		*(left->gradient)  = tmp_0;
		Tensor<FLOAT>* tmp_1 = right->gradient->add(doutput, nullptr, true);
		*(right->gradient) = tmp_1;

		delete(tmp_0);
		delete(tmp_1);
	}
};

template <typename FLOAT>
Node<FLOAT>* AddNodeGenerator(Node<FLOAT>* left, Node<FLOAT>* right, Op<FLOAT>* op) {
	CheckShapeEqual(left->value->shape, right->value->shape);
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(left); input_nodes->push_back(right);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(left->value->shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Add");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* add(Node<FLOAT>* left, Node<FLOAT>* right) {
		AddOp<FLOAT>* op = new AddOp<FLOAT>();
		Node<FLOAT>* x = AddNodeGenerator(left, right, op);
		op->compute(x);
		return x;
	}

}

#endif // !_ADD_OP_H_
