#include <iostream>
#include <vector>
#include <stack>
using std::vector;
using std::deque;
#ifndef _NODE_H_
#define _NODE_H_
//int32_t node_sum = 0; //from 0 to start
int32_t _NODE_SUM_ = 0; // node's label
deque<void*> _NODE_DEQUE_;

template <typename FLOAT>
class Tensor;

template <typename FLOAT>
class Op;

template <typename FLOAT>
class Node
{
public:
	bool is_visited;
	char name[30] = R"(NU)";
	int32_t _node_id;
	Op<FLOAT>* OPERATOR;
	vector<int32_t> param;//Op_func_parameter
	vector<Node<FLOAT>*>*  input;
	Tensor<FLOAT>* value = nullptr;//this node output
	
//method 
public:
	Node(Op<FLOAT>* op, vector<Node<FLOAT>*>* inputs,Tensor<FLOAT>* _value,int32_t global_node_sum = 0){
		is_visited = false;
		OPERATOR = op;
		input = inputs;
		value = _value;
		_node_id = global_node_sum;
		_NODE_DEQUE_.push_back((void*)this);
	}
	~Node();//see OP.h
	//method
	vector<Tensor<FLOAT>*> input2values(){
		static vector<Tensor<FLOAT>*> value_inputs(6);
		value_inputs.clear();
		if(input == nullptr){
			return value_inputs;
		}
		for(unsigned int  i=0;i<input->size();i++){
			value_inputs.push_back((Tensor<FLOAT>*)((*input)[i]->value));
		}
		return value_inputs;
	}
	
	void evaluate();//see OP.h
	void gradient();//see OP.h

	int show_inputs_num(){
		if(input == nullptr){return 0;}
		return (*input).size();
	}
	void visit(){is_visited = true;}
	void leave(){is_visited = false;}
	void backward(Tensor<FLOAT>* output_grad = nullptr,bool retain_grad = false);//see Graph.h
	int32_t dim();
};

void alter(char* name, const char* OpName) {
	int i = 0;
	while (OpName[i]) {
		name[i] = OpName[i];
		i++;
	}
	name[i] = 0;
}
//help node Generator to record node sum and node's name
template<typename FLOAT>
void NodeGeneratorDecorator(Node<FLOAT>* THIS, const char* OpName) {
	_NODE_SUM_++;
	alter(THIS->name, OpName);
}

#endif // !_NODE_H_

