#include "Op.h"
#ifndef _UPSAMPLE_NEAREST_2D_OP_H_
#define _UPSAMPLE_NEAREST_2D_OP_H_ 

template <typename FLOAT>
__global__ void UpsampleNearest2dKernel(FLOAT* d_input, FLOAT* d_out, int64_t* d_input_stride, int64_t* d_out_stride,
	int32_t scale_factor) {
	int64_t out_id = threadIdx.x * d_out_stride[0]
		+ threadIdx.y * d_out_stride[1]
		+ blockIdx.x * d_out_stride[2] * scale_factor
		+ blockIdx.y * d_out_stride[3] * scale_factor;
	int64_t in_id = CudaId(d_input_stride);
	FLOAT max = d_input[in_id];
	int64_t max_id = in_id;
	int64_t tmp_id;
	for (int32_t i = 0; i < scale_factor; i++) {
		for (int32_t j = 0; j < scale_factor; j++) {
			tmp_id = out_id + j + i * d_out_stride[2];
			d_out[tmp_id] = d_input[in_id];
		}
	}
}
template <typename FLOAT>
__global__ void UpsampleNearest2dGradientKernel(FLOAT* d_input_grad, FLOAT* d_out_grad,
	int64_t* d_input_stride, int64_t* d_out_stride, int64_t scale_factor) {
	int64_t out_id = threadIdx.x * d_out_stride[0]
		+ threadIdx.y * d_out_stride[1]
		+ blockIdx.x * d_out_stride[2] * scale_factor
		+ blockIdx.y * d_out_stride[3] * scale_factor;
	int64_t in_id = CudaId(d_input_stride);
	int64_t tmp_id;
	for (int64_t i = 0; i < scale_factor; i++) {
		for (int64_t j = 0; j < scale_factor; j++) {
			tmp_id = out_id + j + i * d_out_stride[2];
			d_input_grad[in_id] += d_out_grad[tmp_id];
		}
	}
}

template <typename FLOAT>
class UpsampleNearest2dOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		int dim = (int)output->shape.size();
		vector<int64_t> BroadcastShape = shape_broadcast(input[0]->shape);
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)
		int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(input[0]->stride));
		int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(output->stride));
		UpsampleNearest2dKernel << <grid, block >> > (input[0]->array, output->array, d_s1, d_s2, node->param[0]);
		cudaDeviceSynchronize();
		cudaFree(d_s1);
		cudaFree(d_s2);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		int dim = (int)doutput->shape.size();
		vector<int64_t> BroadcastShape = shape_broadcast(input[0]->shape);
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)
		int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(input[0]->stride));
		int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(doutput->stride));
		UpsampleNearest2dGradientKernel << <grid, block >> > (input[0]->gradient->array, doutput->array, d_s1, d_s2, node->param[0]);
		cudaDeviceSynchronize();
		vector<Tensor<FLOAT>*>().swap(input);
		cudaFree(d_s1);
		cudaFree(d_s2);
	}
	~UpsampleNearest2dOp(){}
};

template <typename FLOAT>
Node<FLOAT>* UpsampleNearest2dNodeGenerator(Node<FLOAT>* input, int32_t scale_factor, Op<FLOAT>* op) {
	vector<int64_t> shape = input->value->shape;
	if (shape.size() < 2)
	{
		printf("the tensor which is maxpool should have at least two dimension!\n"); exit(true);
	}
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	shape[shape.size() - 1] = (shape[shape.size() - 1] - 1) * scale_factor + scale_factor;
	shape[shape.size() - 2] = (shape[shape.size() - 2] - 1) * scale_factor + scale_factor;
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "UpsampleNearest2d");
	output_node->param.push_back(scale_factor);
	vector<int64_t>().swap(shape);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* upsample_nearest2d(Node<FLOAT>* input, int32_t scale_factor) {
		UpsampleNearest2dOp<FLOAT>* op = new UpsampleNearest2dOp<FLOAT>();
		Node<FLOAT>* x = UpsampleNearest2dNodeGenerator(input, scale_factor, op);
		op->compute(x);
		return x;
	}

}

#endif // !_UPSAMPLE_NEAREST_2D_OP_H_