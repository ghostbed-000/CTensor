#include "Op.h"
#ifndef _CONCAT_H_
#define _CONCAT_H_
template <typename FLOAT>
class ConcatOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		output->cat(input, output, node->param[0]);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		for (unsigned int i = 0; i < input.size(); i++) {
			input[i]->_retain_grad_ = true;
			input[i] = input[i]->gradient;
		}
		Tensor<FLOAT>* output = node->value;
		output->split(output->gradient, input, node->param[0]);
	}
};

template <typename FLOAT>
Node<FLOAT>* ConcatNodeGenerator(vector<Node<FLOAT>*> input,int32_t dim, Op<FLOAT>* op) {
	int64_t dim_size = 0;
	for (unsigned int i = 0; i < input.size(); i++)
	{
		dim_size += input[i]->value->shape[dim];
	}
	vector<int64_t> value_shape = input[0]->shape;
	value_shape[dim] = dim_size;
	Tensor<FLOAT>* value     = new Tensor<FLOAT>(value_shape,true,true);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, &input, value, _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Concat");
	output_node->param->push_back(dim);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* cat(vector<Node<FLOAT>*> input, int32_t dim) {
		ConcatOp<FLOAT>* op = new ConcatOp<FLOAT>();
		Node<FLOAT>* x = ConcatNodeGenerator(input, dim, op);
		op->compute(x);
		return x;
	}

}

#endif // !_CONCAT_H_



