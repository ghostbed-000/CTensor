#include "Op.h"
#ifndef _LN_OP_H_
#define _LN_OP_H_
template <typename FLOAT>
__global__ void LnKernel(FLOAT* d_in, FLOAT* d_out) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_out[id] = logf(d_in[id]);
}

template <typename FLOAT>
__global__ void LnGradientKernel(FLOAT* d_in, FLOAT* d_out, FLOAT* d_in_grad, FLOAT* d_out_grad) {
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_in_grad[id] += (1.0 / d_in[id]) * d_out_grad[id];
}

template <typename FLOAT>
class LnOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, LnKernel);
		vector<Tensor<FLOAT>*>().swap(input);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, LnGradientKernel);
		vector<Tensor<FLOAT>*>().swap(input);
	}
};

template <typename FLOAT>
Node<FLOAT>* LnNodeGenerator(Node<FLOAT>* input, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(input->value), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Ln");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* ln(Node<FLOAT>* input) {
		LnOp<FLOAT>* op = new LnOp<FLOAT>();
		Node<FLOAT>* x = LnNodeGenerator(input, op);
		op->compute(x);
		return x;
	}

}

#endif