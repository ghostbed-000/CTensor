#include "Template.h"
#ifndef _TENSOR_LOG_H_
#define _TENSOR_LOG_H_
template <typename FLOAT>
__global__ void LogKernel(FLOAT* d_left) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_left[id] = logf(d_left[id]);
}

template <typename FLOAT>
void Tensor<FLOAT>::log() { 

	dim3 block(1);
	LogKernel << <AutoAllocateGrid(shape), block >> > (array);
	cudaDeviceSynchronize();

}




#endif