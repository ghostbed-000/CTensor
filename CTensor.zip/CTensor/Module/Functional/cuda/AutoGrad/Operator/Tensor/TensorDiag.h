#include "Template.h"

template <typename FLOAT>
__global__ void DiagKernel(FLOAT* d_in, FLOAT* d_out,int64_t* in_stride, int64_t* d_diff, int64_t dim_len,int32_t dim) {
	int64_t id = CudaId(in_stride);
	int64_t out_id_1 = CudaId(d_diff);
	int64_t out_id_2 = threadIdx.x + threadIdx.y + blockIdx.x + blockIdx.y - out_id_1;

	d_out[out_id_1 + out_id_1 * dim_len + out_id_2 * dim_len * dim_len] = d_in[id];

}
template <typename FLOAT> 
Tensor<FLOAT>* Tensor<FLOAT>::diag(int32_t dim) {
	int64_t diff[4] = { 0 }; diff[dim] = 1;
	int64_t* d_diff = nullptr;
	cudaMalloc((void**)&d_diff, 4 * sizeof(int64_t));
	cudaMemcpy(d_diff, diff, 4 * sizeof(int64_t), cudaMemcpyHostToDevice);
	int64_t dim_len = shape[dim];
	int64_t dim_stride = stride[dim];
	int64_t new_channels = _len_ / dim_len;
	vector<int64_t> new_shape = { new_channels ,dim_len ,dim_len };
	Tensor<FLOAT>* out = new Tensor<FLOAT>(new_shape , false);
	vector<int64_t>& BroadcastShape = shape_broadcast(shape);
	dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
	dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)
	int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(stride));

	DiagKernel << <grid, block >> > (array,out->array , d_s1, dim_len,dim, d_diff);

	vector<int64_t>().swap(new_shape);
	vector<int64_t>().swap(BroadcastShape);
	cudaFree(d_s1);
	cudaFree(d_diff);
	return out;
}
