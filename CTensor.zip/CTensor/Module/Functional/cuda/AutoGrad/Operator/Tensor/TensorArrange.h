#include "Template.h"
#ifndef _TENSOR_ARRANGE_H_
#define _TENSOR_ARRANGE_H_
template <typename FLOAT>
__global__ void ArrangeKernel(FLOAT* d_left) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_left[id] = (FLOAT)id;
}


template <typename FLOAT>
void Tensor<FLOAT>::arange() {

	dim3 block(1);
	ArrangeKernel << <AutoAllocateGrid(shape), block >> > (array);
	cudaDeviceSynchronize();
	CHECK_ERROR(cudaGetLastError());
}



#endif // !_TENSOR_ARRANGE_H_


