#include "Template.h"

template <typename FLOAT>
__global__ void ConstantKernel(FLOAT* d_in, float value) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_in[id] = (FLOAT)value;
}
template <typename FLOAT>
void Tensor<FLOAT>::constant_(float value) {

	dim3 block(1);
	ConstantKernel << <AutoAllocateGrid(shape), block >> > (array, value);
	cudaDeviceSynchronize();

}


