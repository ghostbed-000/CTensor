#include "Template.h"

#ifndef _OPTIMIZER_ADAM_H_
#define _OPTIMIZER_ADAM_H_
template <typename FLOAT>
__global__ void AdamKernel(
	FLOAT* p,
	FLOAT* gt, 
	FLOAT* mt, 
	FLOAT* vt,
	float beta1,
	float beta2,
	float eps,
	float lr,
	int32_t epoch
	)
{
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;

	mt[id] = beta1 * mt[id] + (1.0 - beta1) * gt[id];
	vt[id] = beta2 * vt[id] + (1.0 - beta2) * gt[id] * gt[id];
	//lr = (lr * sqrtf((1 - powf(beta2, epoch)))) / (1.0 - powf(beta1, epoch));
	FLOAT mt_hat = mt[id] / (1.0 - powf(beta1, epoch));
	FLOAT vt_hat = vt[id] / (1.0 - powf(beta2, epoch));
	p[id] -= (lr * mt_hat) / (sqrtf(vt_hat) + eps);
}

template <typename FLOAT>
void adam(Tensor<FLOAT>* input, Tensor<FLOAT>* first_moment, Tensor<FLOAT>* second_moment,float* betas,float eps,float lr, int32_t epoch) {
	dim3 block(1);
	AdamKernel << <AutoAllocateGrid(input->shape), block >> > 
		(
		input->array,
		input->gradient->array,
		first_moment->array, 
		second_moment->array,
		betas[0],
		betas[1],
		eps,
		lr,
		epoch
		);
	cudaDeviceSynchronize();
}



#endif