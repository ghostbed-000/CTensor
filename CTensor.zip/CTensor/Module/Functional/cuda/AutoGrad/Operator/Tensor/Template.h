#include "BroadcastRule.h"
#ifndef _TEMPLATE_H_
#define _TEMPLATE_H_
__global__ void SetupCurandStates(curandState* state, unsigned long seed)
{
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	curand_init(seed, id, 0, &state[id]);// initialize the state
}

__device__ inline int64_t CudaId(int64_t* stride) 
{
	return threadIdx.x * stride[0] + threadIdx.y * stride[1] + blockIdx.x * stride[2] + blockIdx.y * stride[3];
}

__device__ inline void GridToArray(int64_t* array) {
	array[0] = threadIdx.x;
	array[1] = threadIdx.y;
	array[2] = blockIdx.x;
	array[3] = blockIdx.y;
}

template <typename T>
T* VectorToCuda(vector<T>& vec) {
	T* device = nullptr;
	unsigned int len = sizeof(T) * vec.size();
	cudaMalloc((void**)&device, len); 
	cudaMemcpy(device, &vec[0], len, cudaMemcpyHostToDevice);
	vector<T>().swap(vec);
	return device;
}

template <typename FLOAT>
void _ASSIGNED_FUNCTION_(Tensor<FLOAT>* input, Tensor<FLOAT>* output,void (*KERNEL)(FLOAT* in,FLOAT* out)) {
	dim3 block(1);
	KERNEL << <AutoAllocateGrid(input->shape), block >> > (input->array, output->array);
	cudaDeviceSynchronize();
}

template <typename FLOAT>
void _ASSIGNED_FUNCTION_(Tensor<FLOAT>* input, Tensor<FLOAT>* output, void (*KERNEL)(FLOAT* in, FLOAT* out, FLOAT* din, FLOAT* dout)) {
	dim3 block(1);
	KERNEL << <AutoAllocateGrid(input->shape), block >> > (input->array, output->array, input->gradient->array,output->gradient->array);
	cudaDeviceSynchronize();
}

#define CHECK_ERROR(call)\
do{\
	int _error = (call);\
	if(_error)\
	{\
		printf("*** Error *** at [%s:%d] error=%d \n", __FILE__, __LINE__, _error);\
	}\
}while(0)

#define CUDA_CHECK_ERROR(call)\
do{\
	cudaError_t _error = (cudaError_t)(call);\
	if(_error != cudaSuccess)\
	{\
		printf("*** CUDA Error *** at [%s:%d] error=%d, reason:%s \n",\
			__FILE__, __LINE__, _error, cudaGetErrorString(_error));\
	}\
}while(0)

#endif 


