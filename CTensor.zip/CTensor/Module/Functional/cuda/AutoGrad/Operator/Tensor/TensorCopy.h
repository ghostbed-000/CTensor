#include "Template.h"
#ifndef _TENSOR_COPY_H_
#define _TENSOR_COPY_H_
template <typename FLOAT> 
__global__ void CopyKernel(FLOAT* left, FLOAT* right,int64_t* Lstride, int64_t* Rstride)
{
	int64_t left_id  = CudaId(Lstride);
	int64_t right_id = CudaId(Rstride);

	left[left_id] = right[right_id];
}


template <typename FLOAT> 
void Tensor<FLOAT>::operator=(Tensor<FLOAT>* input) {
	
	if (!CheckShapeEqual(shape, input->shape))
	{
		int64_t new_len = 1;
		for (unsigned int i = 0; i < shape.size(); i++)
		{
			new_len *= shape[i];
		}
		if (new_len != _len_)
		{
			std::cout << "the shapes aren't same!\n";
			exit(1);
		}
	}
	vector<int64_t>& BroadcastShape = shape_broadcast(input->shape);
	//ĳ�ֽ���ͬ��״shapeת����4ά����
	dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
	dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)

	int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(stride));
	int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(input->stride));

	CopyKernel << <grid, block >> > (array, input->array, d_s1, d_s2);

	cudaDeviceSynchronize();
	vector<int64_t>().swap(BroadcastShape);
	cudaFree(d_s1);
	cudaFree(d_s2);
}



#endif