#include "Template.h"
#ifndef _TENSOR_CONTIGUOUS_H_
#define _TENSOR_CONTIGUOUS_H_

template <typename FLOAT>
__global__ void ContiguousKernel(FLOAT* d_left, FLOAT* d_right,int64_t* d_left_stride, int64_t* d_right_stride)
{
	int64_t left_id = CudaId(d_left_stride);
	int64_t right_id = CudaId(d_right_stride);

	d_left[left_id] = d_right[right_id];
}

template <typename FLOAT>
Tensor<FLOAT>* Tensor<FLOAT>::contiguous() {
	int dim = (int)shape.size();
	vector<int64_t>& BroadcastShape = shape_broadcast(shape);
	//ĳ�ֽ���ͬ��״shapeת����4ά����
	dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
	dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)
	Tensor<FLOAT>* newTensor = new Tensor<FLOAT>(shape, _requires_grad_, _retain_grad_);

	int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(stride));
	int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(newTensor->stride));

	ContiguousKernel << <grid, block >> > (newTensor->array,array, d_s1, d_s2);

	cudaDeviceSynchronize();
	vector<int64_t>().swap(BroadcastShape);
	cudaFree(d_s1);
	cudaFree(d_s2);

	return newTensor;
}


#endif
