#include "Template.h"
#ifndef _LOCATION_MATRIX_H_
#define _LOCATION_MATRIX_H_
template <typename FLOAT>
__global__ void Im2colKernel(FLOAT* transform, FLOAT* input, int64_t stride,
	int64_t V_trans,int64_t V_input, 
	int64_t S_input, int64_t in_col,
	int64_t kernel_H, int64_t kernel_W,
	int64_t S_trans, int64_t S_output)
{

	//threadIdx.x  threadIdx.y  blockIdx.x  blockIdx.y ;
	//batch_size   in_channels  output_row  output_col ;
	int64_t id_input = threadIdx.x * V_input + threadIdx.y * S_input + (blockIdx.x * in_col + blockIdx.y) * stride;
	int64_t id_trans = threadIdx.x * V_trans + threadIdx.y * S_trans + (blockIdx.x * gridDim.y+ blockIdx.y);

	for (int64_t i = 0; i < kernel_H; i++)
	{
		for (int64_t j = 0; j < kernel_W; j++)
		{
			transform[(j + i * kernel_W) * S_output + id_trans] = input[(j + i * in_col) + id_input];
		}
	}

}
template <typename FLOAT>
__global__ void Col2imgKernel(FLOAT* transform, FLOAT* input, int64_t stride,
	int64_t V_trans, int64_t V_input,
	int64_t S_input, int64_t in_col,
	int64_t kernel_H, int64_t kernel_W,
	int64_t S_trans, int64_t out_row, int64_t out_col, int64_t i, int64_t j)
{

	//threadIdx.x  threadIdx.y  blockIdx.x  blockIdx.y ;
	//batch_size   in_channels  kernel_H    kernel_W ;
	int64_t id_input = threadIdx.x * V_input + threadIdx.y * S_input + blockIdx.x * in_col + blockIdx.y;
	int64_t id_trans = threadIdx.x * V_trans + threadIdx.y * S_trans + (blockIdx.x * kernel_W + blockIdx.y) * out_row * out_col;

	input[(i * in_col + j) * stride + id_input] += transform[(i * out_col + j) + id_trans];
	__syncthreads();

}

template <typename FLOAT>
Tensor<FLOAT>* im2col(Tensor<FLOAT>* input, int64_t kernel_H, int64_t kernel_W, int64_t stride,
	Tensor<FLOAT>* transform = nullptr) {
	if (input->shape.size() < 2)
	{
		std::cout<<"this tensor's dimensions is too small so that it can't im2col!"<<std::endl
;
		exit(1);
	}
	vector<int64_t>& BroadcastShape = shape_broadcast(input->shape);
	vector<int64_t> new_shape = {1,1,1};
	bool reverse = transform;
	int64_t out_row = (input->shape[input->shape.size() - 2] - kernel_H) / stride + 1;
	int64_t out_col = (input->shape[input->shape.size() - 1] - kernel_W) / stride + 1;
	new_shape[0] = BroadcastShape[0];
	new_shape[2] = out_row * out_col;
	new_shape[1] = kernel_H * kernel_W * BroadcastShape[1];
	int64_t in_col = input->shape[input->shape.size() - 1];
	int64_t S_transform = new_shape[2] * new_shape[1];
	int64_t S_input = input->shape[input->shape.size() - 2] * input->shape[input->shape.size() - 1];
	int64_t V_transform = S_transform;
	int64_t V_input = BroadcastShape[1] * BroadcastShape[2] * BroadcastShape[3];

	if (transform == nullptr)
	{
		transform = new Tensor<FLOAT>(new_shape,false);
	}

	if (!reverse)
	{
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(out_row, out_col);//grid(H,W)
		Im2colKernel << <grid, block >> > (transform->array,input->array,stride,
			V_transform, V_input, S_input, in_col, kernel_H, kernel_W, S_transform / BroadcastShape[1],
			out_row * out_col);
	}
	else {
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(kernel_H, kernel_W);//grid(H,W)

		for (int64_t i = 0; i < out_row; i++)
		{
			for (int64_t j = 0; j < out_row; j++) {
				Col2imgKernel << <grid, block >> > (transform->array, input->array, stride,
					V_transform, V_input, S_input, in_col, kernel_H, kernel_W, S_transform / BroadcastShape[1], out_row, out_col,i,j);
			}
		}

	}
	cudaDeviceSynchronize();
	vector<int64_t>().swap(new_shape);
	vector<int64_t>().swap(BroadcastShape);
	return transform;

}


#endif // !_LOCATION_MATRIX_H_