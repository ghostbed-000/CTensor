#include "Template.h"

template <typename FLOAT>
__global__ void ZeroKernel(FLOAT* d_left) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_left[id] = 0;
}


template <typename FLOAT>
void Tensor<FLOAT>::zero_() {

	dim3 block(1);
	ZeroKernel << <AutoAllocateGrid(shape), block >> > (array);
	cudaDeviceSynchronize();

}
template <typename FLOAT>
void Tensor<FLOAT>::zero_grad() {

	if (gradient != nullptr)
	{
		dim3 block(1);
		ZeroKernel << <AutoAllocateGrid(shape), block >> > (gradient->array);
		cudaDeviceSynchronize();
	}
}