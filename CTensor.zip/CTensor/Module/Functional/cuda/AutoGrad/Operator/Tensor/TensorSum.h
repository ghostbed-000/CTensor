#include "Template.h"

#ifndef _TENSOR_SUM_H_
#define _TENSOR_SUM_H_
template <typename FLOAT>
__global__ void SumKernel(FLOAT* d_array, int size_of_this_array, int64_t* stride, int dim)
{
	int64_t index[4];
	GridToArray(index);
	int64_t id = CudaId(stride);
	int64_t dim_id = index[dim] * stride[dim];
	d_array[id] += d_array[id + stride[dim] * (size_of_this_array - 1) - dim_id - dim_id];
	__syncthreads();
}

template <typename FLOAT>
Tensor<FLOAT>* Tensor<FLOAT>::sum(int32_t dim, Tensor<FLOAT>* out) {
	vector<int64_t>& BroadcastShape = shape_broadcast(shape);
	int32_t BroadcastDim           = dim + BroadcastShape.size() - shape.size();
	int64_t size_of_this_array     = shape[dim];
	int64_t*d_stride               = VectorToCuda<int64_t>(stride_broadcast(stride));

	FLOAT* d_sum = nullptr;
	if (!out)
	{
		cudaMalloc((void**)&d_sum, _len_ * sizeof(FLOAT));
		cudaMemcpy(d_sum, array, _len_ * sizeof(FLOAT), cudaMemcpyDeviceToDevice);
	}
	else {
		d_sum = out->array;
	}
	
	while (size_of_this_array > 1)
	{
		BroadcastShape[BroadcastDim] = size_of_this_array / 2;
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W) 
		SumKernel << <grid, block >> > (d_sum, size_of_this_array, d_stride, BroadcastDim);
		if (size_of_this_array % 2 == 0)
		{
			size_of_this_array = BroadcastShape[BroadcastDim];
		}
		else {
			size_of_this_array = (size_of_this_array + 1) / 2;
		}

	}
	cudaDeviceSynchronize();
	vector<int64_t>().swap(BroadcastShape);
	cudaFree(d_stride);
	if (!out)
	{
		out = new Tensor<FLOAT>(d_sum, shape);
	}
	out->stride        = stride;
	out->shape[dim]    = 1;
	out->stride[dim]   = 0;
	
	return out;
}
template <typename FLOAT> 
Tensor<FLOAT>* Tensor<FLOAT>::sum(vector<int32_t>& dim) {

	for (unsigned int i = 0; i < dim.size(); i++)
	{
		sum(dim[i],this);
	}

	return keep_len();
}

#endif
