#include <iostream>
#include <vector>
#include <tuple>
#include "cuda_runtime.h"
#include "device_launch_parameters.h"
#include "curand_kernel.h"
using std::vector;
using std::tuple;
/*
	warning:
	don't use delete() to delete gradient tensor!!!
	you should delete original tensor to delete the gradient tensor!!!

*/
#ifndef _TENSOR_H_
#define _TENSOR_H_
int64_t _CPU_MEMORY_COST_ = 0;
int64_t _GPU_MEMORY_COST_ = 0;

template <typename FLOAT>
class Tensor
{
public:
//statue
	//[B,C,H.W],[C,H.W],[H.W]
	vector<int64_t> shape;
	vector<int64_t> stride;
	int64_t _len_;
	bool  _requires_grad_; 
	bool  _retain_grad_;
	bool  _is_reference_ = false;
	bool  _is_cuda_      = true;
	Tensor<FLOAT>* gradient;

	FLOAT* array;
	
//method
	//constructor body
private:
	void size() {
		_len_ = 1;
		for (unsigned int i = 0; i < shape.size(); i++)
		{
			_len_ *= shape[i];
		}
		vector<int64_t>& quote = shape_stride(shape);
		stride = quote;
		vector<int64_t>().swap(quote);
	}
	void MemCost(bool NeedyArray) {
		if (NeedyArray) {
			_GPU_MEMORY_COST_ += _len_ * sizeof(FLOAT);
		}
		_CPU_MEMORY_COST_ += sizeof(Tensor<FLOAT>);
	}
public:
	//show
	void print_arr();
	//init
	Tensor(FLOAT value,bool retain_grad = false){
		shape.push_back(1);
		size();
		_requires_grad_ = true;
		_retain_grad_   = retain_grad;
		cudaMalloc((void**)&array, sizeof(FLOAT));
		cudaMemcpy(array, &value, sizeof(FLOAT),cudaMemcpyHostToDevice);
		gradient = nullptr;
		MemCost(0);
	}
	Tensor(FLOAT* device_data, vector<int64_t>& _shape,bool requires_grad = true, bool is_reference_ = true){
		shape = _shape;
		size();
		array = device_data;
		_retain_grad_   = false;
		_is_reference_  = is_reference_;
		_requires_grad_ = requires_grad;
		gradient = nullptr;
		MemCost(0);
	}
	Tensor(Tensor<FLOAT>* input,bool requires_grad = true,bool retain_grad = false, bool copy_array = false){
		shape			   = input->shape;
		stride			   = input->stride;
		_requires_grad_    = requires_grad;
		_retain_grad_      = retain_grad;
		_len_			   = input->_len_;
		cudaMalloc((void**)&array, _len_ * sizeof(FLOAT));
		if (copy_array)
		{
			cudaMemcpy(array,input->array, _len_ * sizeof(FLOAT),cudaMemcpyDeviceToDevice);
		}
		else {
			this->zero_();
		}
		gradient = nullptr;
		MemCost(0);
	}
	Tensor(vector<int64_t>& _shape,bool requires_grad = true, bool retain_grad = false,bool iNeedArray = true) {
		shape = _shape;
		size();
		_requires_grad_ = requires_grad;
		_retain_grad_   = retain_grad;
		array = nullptr;
		if (iNeedArray)
		{
			cudaMalloc((void**)&array, _len_ * sizeof(FLOAT));
			this->zero_();
		}
		gradient = nullptr;
		if (requires_grad && retain_grad)
		{
			gradient = new Tensor(shape, false, false, iNeedArray);
		}
		MemCost(iNeedArray);
	}
	~Tensor(){
		_CPU_MEMORY_COST_ -= sizeof(Tensor<FLOAT>);
		if(array != nullptr && !_is_reference_){
			cudaFree(array);
			_GPU_MEMORY_COST_ -= _len_;
			array = nullptr;
		}
		if (gradient != nullptr) {
			_CPU_MEMORY_COST_ -= sizeof(Tensor<FLOAT>);
			_GPU_MEMORY_COST_ -= _len_;
			delete(gradient);
			gradient = nullptr;
		}
		vector<int64_t>().swap(shape);
		vector<int64_t>().swap(stride);
	}
	//assigned
	void gaussinit(float var = 1.0, float mean = 0.0);
	void uniform(float a = 0.0, float b = 1.0);
	void constant_(float value = 1.0);
	void arange();
	void zero_();
	void zero_grad();
	//func
	FLOAT*to_cpu() {
		FLOAT* tmp = (FLOAT*)calloc(_len_ , sizeof(FLOAT));
		if (array == nullptr) { std::cout << "array is nullptr!you can't turn a nullptr to cpu!"<< std::endl; exit(1); }
		cudaMemcpy(tmp, array, _len_ * sizeof(FLOAT), cudaMemcpyDeviceToHost);
		return tmp;
	};
	Tensor<FLOAT>* sum(int32_t dim, Tensor<FLOAT>* out = nullptr);
	Tensor<FLOAT>* sum(vector<int32_t>& dim);
	Tensor<FLOAT>* mean(int32_t dim);
	Tensor<FLOAT>* mean(vector<int32_t>& dim, Tensor<FLOAT>* output = nullptr);
	Tensor<FLOAT>* diag(int32_t dim = 0);//
	Tensor<FLOAT>* outer(int32_t dim = 0);//
	void TransposeItself();
	Tensor<FLOAT>* transpose(int32_t dim1, int32_t dim2);
	Tensor<FLOAT>* contiguous();
	Tensor<FLOAT>* keep_len(FLOAT* _array = nullptr);
	tuple<FLOAT*, int64_t*> max(int32_t dim);//
	void reshape(vector<int64_t>& _shape);
	Tensor<FLOAT>* reshape(int64_t* _shape,int32_t dim_size);
	void unsqueeze(int32_t dim);
	void pow(FLOAT exponent);
	void exp();
	void log();
	void sqrt();
	vector<Tensor<FLOAT>*> split(int32_t dim);
	Tensor<FLOAT>* mul(Tensor<FLOAT>* right, Tensor<FLOAT>* out = nullptr);
	Tensor<FLOAT>* add(Tensor<FLOAT>* right, Tensor<FLOAT>* out = nullptr, bool keep_dim = false);
	Tensor<FLOAT>* sub(Tensor<FLOAT>* right, Tensor<FLOAT>* out = nullptr, bool keep_dim = false);
	Tensor<FLOAT>* dotmul(Tensor<FLOAT>* right, Tensor<FLOAT>* out = nullptr, bool keep_dim = false);
	Tensor<FLOAT>* divide(Tensor<FLOAT>* right, Tensor<FLOAT>* out = nullptr, bool keep_dim = false);
	Tensor<FLOAT> operator*(Tensor<FLOAT> right);
	Tensor<FLOAT> operator/(Tensor<FLOAT> right);
	Tensor<FLOAT> operator+(Tensor<FLOAT> right);
	Tensor<FLOAT> operator-(Tensor<FLOAT> right);
	int  operator==(Tensor<FLOAT>* tensor);
	void operator=(Tensor<FLOAT>* tensor);
	void operator*=(FLOAT value);
	void operator/=(FLOAT value);
	void operator+=(FLOAT value);
	void operator-=(FLOAT value);
};

bool CheckShapeEqual(vector<int64_t>& shape1, vector<int64_t>& shape2) {

	if (shape1.size() != shape2.size())
	{
		return false;
	}

	for (unsigned int i = 0; i < shape1.size(); i++)
	{
		if (shape1[i] != shape2[i])
		{
			return false;
		}
	}
	return true;
}

dim3 AutoAllocateGrid(vector<int64_t>& shape) {
	dim3 grid(1);
	if (shape.size() == 1) {
		grid.y = (unsigned int)shape[0];
	}
	if (shape.size() == 2){
		grid.x = (unsigned int)shape[0]; grid.y = (unsigned int)shape[1];
	}
	if (shape.size() >= 3) {
		unsigned int i = 0; grid.z = 1;
		for (; i < shape.size() - 2; i++)
		{
			grid.z *= (unsigned int)shape[i];
		}
		grid.x = (unsigned int)shape[i]; i++;
		grid.y = (unsigned int)shape[i]; i++;
	}
	return grid;
}
//warining: this function will cause memory leak !!!
//you must use this function by reference !!!
vector<int64_t> shape_stride(vector<int64_t>& shape) {
	vector<int64_t> stride = shape;
	for (unsigned int i = 1; i <= shape.size(); i++)
	{
		stride[i - 1] = 1;
		for (unsigned int j = 0; j < (shape.size() - i); j++)
		{
			stride[i - 1] *= shape[i + j];
		}
	}
	for (unsigned int i = 0; i < shape.size(); i++)
	{
		if (shape[i] == 1)
		{
			stride[i] = 0;
		}
	}
	return stride;
}

template <typename T>
T* data2device(T* host_data,int64_t size, T* device_data = nullptr) {
	if (!device_data)
	{
		cudaMalloc((void**)&device_data, sizeof(T) * size);
	}
	cudaMemcpy(device_data, host_data, sizeof(T) * size, cudaMemcpyHostToDevice);
	return device_data;
}
template <typename T>
T* data2host(T* device_data, int64_t size) {
	T* host_data = (T*)malloc(sizeof(T) * size);
	cudaMemcpy(host_data, device_data, sizeof(T) * size, cudaMemcpyDeviceToHost);
	return host_data;
}

void _SHOW_CPU_MEMORY_COST_() {
	double value = _CPU_MEMORY_COST_ / (1024 * 1024);
	if (value > 1)
	{
		printf("CPU MEMORY COST = %d mb\n", (int32_t)value);
	}
	else
	{
		printf("CPU MEMORY COST = %d byte\n", (int32_t)_CPU_MEMORY_COST_);
	}
	
}
void _SHOW_GPU_MEMORY_COST_() {
	double value = _GPU_MEMORY_COST_ / (1024 * 1024);
	if (value > 1)
	{
		printf("GPU MEMORY COST = %d mb\n", (int32_t)value);
	}
	else
	{
		printf("GPU MEMORY COST = %d byte\n", (int32_t)_GPU_MEMORY_COST_);
	}
}
#endif // !_TENSOR_H_



