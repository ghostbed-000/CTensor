#include "Tensor.h"
#ifndef _BROADCAST_RULE_H_
#define _BROADCAST_RULE_H_
//warining: this function will cause memory leak !!!
//you must use this function by reference !!!
template <typename INT>
vector<INT> BroadcastRule(vector<INT>& a,vector<INT>& b){
	//check
	if (a.size() >= b.size()) {
		vector<INT> c = a;
		for (unsigned int i = 1; i <= b.size(); i++) {
			if (a[a.size() - i] != b[b.size() - i]) {
				//it can be broadcasted!
				if (a[a.size() - i] == 1) {
					c[a.size() - i] = b[b.size() - i];
				}
				else if (b[b.size() - i] == 1) {
					c[a.size() - i] = a[a.size() - i];
				}
				else {
					printf("it can't be broadcasted!\n");
					break;
				}
			}
		}
		return c;
	}
	else {
		vector<INT> c = b;
		for (unsigned int i = 1; i <= a.size(); i++) {
			if (a[a.size() - i] != b[b.size() - i]) {
				//it can be broadcasted!
				if (a[a.size() - i] == 1) {
					c[b.size() - i] = b[b.size() - i];
				}
				else if (b[b.size() - i] == 1) {
					c[b.size() - i] = a[a.size() - i];
				}
				else {
					printf("it can't be broadcasted!\n");
					break;
				}
			}
		}
		return c;
	}
}
//A shape vector with dimension less than 4 is stuffed with 1
vector<int64_t> shape_broadcast(vector<int64_t>& vec) {
	if (vec.size() == 4)
	{
		return vec;
	}
	vector<int64_t> tmp = vec;
	for (int i = 0; i < 4 - vec.size(); i++)
	{
		tmp.insert(tmp.begin(), 1);
	}

	return tmp;
}
//warining: this function will cause memory leak !!!
//you must use this function by reference !!!
vector<int64_t> stride_broadcast(vector<int64_t>& vec) {
	const int max_dim = 4;
	if (vec.size() == max_dim)
	{
		return vec;
	}
	vector<int64_t> tmp = vec;
	for (int i = 0; i < max_dim - vec.size(); i++)
	{
		tmp.insert(tmp.begin(), 0);
	}

	return tmp;
}
#endif // !_BROADCAST_RULE_H_


