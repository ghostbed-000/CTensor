#include "Template.h"
#ifndef _TENSOR_SPLIT_H_
#define _TENSOR_SPLIT_H_

//warining: don't used this function before activate function
template <typename FLOAT>
vector<Tensor<FLOAT>*> Tensor<FLOAT>::split(int32_t dim) {
	FLOAT*  device = array;
	vector<Tensor<FLOAT>*> output;
	vector<int64_t> tmp = shape;
	tmp[dim] = 1;
	for (int32_t i = 0; i < shape[dim]; i++)
	{
		output.push_back(new Tensor(tmp,_requires_grad_,_retain_grad_,false));
		output[i]->array  = device;
		output[i]->stride = stride;
		device += stride[dim];
	}
	vector<int64_t>().swap(tmp);
	return output;
}


#endif