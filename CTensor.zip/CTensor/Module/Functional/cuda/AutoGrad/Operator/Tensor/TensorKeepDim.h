#include "Template.h"

#ifndef _TENSOR_KEEP_LEN_H_
#define _TENSOR_KEEP_LEN_H_
template <typename FLOAT>
__global__ void KeepLenKernel(FLOAT* left, FLOAT* right, int64_t* Lstride, int64_t* Rstride)
{
	int64_t left_id = CudaId(Lstride);
	int64_t right_id = CudaId(Rstride);

	left[left_id] = right[right_id]; 
}

//using this function when the _len_ is bigger than multiply-accumulate of the shape's element
//the reason for _len_ is bigger than multiply-accumulate of the shape's element is Tensor function - sum()
template <typename FLOAT>
Tensor<FLOAT>* Tensor<FLOAT>::keep_len(FLOAT* _array) {
	Tensor<FLOAT>* out;
	if (_array)
	{
		out = new Tensor<FLOAT>(_array,shape, _requires_grad_);
	}
	else {
		out = new Tensor<FLOAT>(shape, _requires_grad_, _retain_grad_);
	}
	vector<int64_t>& BroadcastShape = shape_broadcast(shape);

	dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
	dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)

	int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(out->stride));
	int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(stride));

	KeepLenKernel << <grid, block >> > (out->array, array, d_s1, d_s2);

	cudaDeviceSynchronize();
	vector<int64_t>().swap(BroadcastShape);
	cudaFree(d_s1);
	cudaFree(d_s2);
	return out;
}


#endif