#include "Template.h"
#ifndef _TENSOR_CAT_H_
#define _TENSOR_CAT_H_
template <typename FLOAT>
__global__ void CatKernel(FLOAT* left, FLOAT* right, int64_t* d_Lstride, int64_t* d_Rstride, int64_t offset) {
	left[CudaId(d_Lstride) + offset] = right[CudaId(d_Rstride)];
}

template <typename FLOAT>
Tensor<FLOAT>* cat(vector<Tensor<FLOAT>*>& tensors, int32_t dim) {
	int64_t new_dim_len = tensors[0]->shape[dim];
	for (unsigned int i = 0; i < tensors.size(); i++)
	{
		if (i + 1 == tensors.size())
		{
			break;
		}
		if (tensors[i]->operator==(tensors[i + 1]) > 1) {
			printf("two tensor should have only one different shape of dimension!\n");
			exit(1);
		}
		new_dim_len += tensors[i + 1]->shape[dim];
	}
	vector<int64_t> new_shape = tensors[0]->shape; 
	new_shape[dim] = new_dim_len;
	Tensor<FLOAT>* output = new Tensor<FLOAT>(new_shape);

	int64_t offset = 0;
	FLOAT* d_tmp = output->array;
	int64_t* d_output_stride = VectorToCuda<int64_t>(stride_broadcast(output->stride));
	int64_t* d_input_stride = nullptr;

	for (unsigned int i = 0; i < tensors.size(); i++)
	{
		vector<int64_t>& BroadcastShape = shape_broadcast(tensors[i]->shape);
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)
		d_input_stride = VectorToCuda<int64_t>(stride_broadcast(tensors[i]->stride));
		CatKernel << <grid, block >> > (d_tmp, tensors[i]->array, d_output_stride, d_input_stride,offset);
		cudaDeviceSynchronize();
		cudaFree(d_input_stride);

		offset += tensors[i]->shape[dim] * tensors[i]->stride[dim];
		vector<int64_t>().swap(BroadcastShape);
	}

	vector<Tensor<FLOAT>*>().swap(tensors);
	vector<int64_t>       ().swap(new_shape);
	return output;
}


#endif