#include "Template.h"
#ifndef _TENSOR_EXP_H_
#define _TENSOR_EXP_H_
template <typename FLOAT>
__global__ void ExpKernel(FLOAT* d_left) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_left[id] = expf(d_left[id]);
}

template <typename FLOAT>
void Tensor<FLOAT>::exp() { 

	dim3 block(1);
	ExpKernel << <AutoAllocateGrid(shape), block >> > (array);
	cudaDeviceSynchronize();

}




#endif