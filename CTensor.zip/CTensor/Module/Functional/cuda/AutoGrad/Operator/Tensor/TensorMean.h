#include "Template.h"
#ifndef _TENSOR_MEAN_H_
#define _TENSOR_MEAN_H_
//warning
template <typename FLOAT>
Tensor<FLOAT>* Tensor<FLOAT>::mean(int32_t dim) {
	*this /= ((FLOAT)(shape[dim]));
	Tensor<FLOAT>* out = sum(dim);
	out->shape[dim] = 1;
	*this *= ((FLOAT)(shape[dim]));
	return out;
}

template <typename FLOAT>
Tensor<FLOAT>* Tensor<FLOAT>::mean(vector<int32_t>& dim, Tensor<FLOAT>* output) {
	if (dim.size() < 2 || shape.size() < 2) {
		printf("Tensor's dimension should be more than 1 !\n");
		return nullptr;
	}
	int64_t N = shape[dim[0]];
	Tensor<FLOAT>* tmp = nullptr;
	Tensor<FLOAT>* out = nullptr;
	out = sum(dim[0]);
	tmp = out->keep_len();
	delete(out);

	for (unsigned int i = 1; i < dim.size(); i++)
	{
		out = tmp->sum(dim[i]);
		tmp = out->keep_len();
		delete(out);
		N *= shape[dim[i]];
	}
	*tmp /= (FLOAT)(N);
	return tmp;
}
#endif