#include "im2col.h"
#ifndef _TENSOR_CONVD2D_H_
#define _TENSOR_CONVD2D_H_
template <typename FLOAT>
__global__ void ConvMatMulKernel(FLOAT* trans, FLOAT* filter, FLOAT* out,
	int64_t C_S_filter, int64_t S_output)
{
	//threadIdx.x  blockIdx.x  blockIdx.y ;
	//batch_size   filter_num  S_output   ;
	int64_t id_filter= blockIdx.x  * C_S_filter;
	int64_t id_trans = threadIdx.x * C_S_filter * S_output + blockIdx.y;
	int64_t id_out   = threadIdx.x * gridDim.x  * S_output + blockIdx.x * S_output + blockIdx.y;
	for (int64_t i = 0; i < C_S_filter; i++)
	{
		out[id_out] += filter[i + id_filter] * trans[i * S_output + id_trans];
	}
}
template <typename FLOAT>
Tensor<FLOAT>* Conv2d(Tensor<FLOAT>* input, Tensor<FLOAT>* filter,int32_t stride, Tensor<FLOAT>* output = nullptr) 
{
	if (filter->shape.size() != 4)
	{
		std::cout << "filter's dimension must be 4!" << std::endl;
		exit(1);
	}
	vector<int64_t> new_f_shape = { filter->shape[0],filter->shape[1] * filter->shape[2] * filter->shape[3] };
	Tensor<FLOAT>* tmp_f = new Tensor<FLOAT>(filter->array, new_f_shape,false);
	Tensor<FLOAT>* trans = im2col(input, filter->shape[2], filter->shape[3], stride);
	vector<int64_t>& BroadcastShape = shape_broadcast(input->shape);
	
	dim3 block(BroadcastShape[0]);//block(B)
	dim3 grid(new_f_shape[0], output->stride[output->stride.size() - 3]);//grid(N,S_output)
	ConvMatMulKernel << <grid, block >> > (trans->array, tmp_f->array, output->array,
		new_f_shape[1], output->stride[output->stride.size() - 3]);

	vector<int64_t>().swap(new_f_shape);
	vector<int64_t>().swap(BroadcastShape);
	delete(trans);
	delete(tmp_f);

	return output;
}
#endif