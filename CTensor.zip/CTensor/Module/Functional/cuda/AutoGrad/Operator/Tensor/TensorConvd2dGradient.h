#include "im2col.h"
#ifndef _TENSOR_UNCONVD2D_H_
#define _TENSOR_UNCONVD2D_H_

template <typename FLOAT>
__global__ void Convd2dGradientKernel_1(FLOAT* trans, FLOAT* doutput, FLOAT* dfilter,
	int64_t batch_size,int64_t S_output, int64_t V_trans, int64_t V_output, int64_t filter_num)
{
	//dfilter = doutput * transform
	//blockIdx.x  blockIdx.y ;
	//filter_num  C_S_filter
	int64_t id_filter    = blockIdx.x * gridDim.y + blockIdx.y;
	int64_t id_output    = blockIdx.x * S_output;
	int64_t id_transform = blockIdx.y * S_output;
	
	for (int64_t i = 0; i < batch_size; i++)//blockDim.x : batch_size
	{
		for (int64_t j = 0; j < S_output; j++)
		{
			dfilter[id_filter] += doutput[j + i * V_output + id_output] * trans[j + i * V_trans + id_transform];
		}
	}
	
}

template <typename FLOAT>
__global__ void Convd2dGradientKernel_2(FLOAT* dtrans, FLOAT* doutput, FLOAT* filter,
	int64_t filter_num, int64_t S_output,int64_t V_trans,int64_t V_output)
{
	//dtransform = filter * doutput
	//threadIdx.x  blockIdx.x  blockIdx.y ;
	//batch_size   C_S_filter  S_output
	int64_t id_transform = threadIdx.x * V_trans + blockIdx.x * S_output + blockIdx.y;
	int64_t id_filter    = blockIdx.x;
	int64_t id_output    = threadIdx.x * V_output + blockIdx.y;
	for (int64_t i = 0; i < filter_num; i++)
	{
		dtrans[id_transform] += filter[i * gridDim.x + id_filter];// *doutput[i * S_output + id_output];
	}

}

template <typename FLOAT>
void Conv2dGradient(Tensor<FLOAT>* input, Tensor<FLOAT>* filter, Tensor<FLOAT>* output, int32_t stride) {
	vector<int64_t>& BroadcastShape = shape_broadcast(input->shape);
	vector<int64_t> new_shape = { BroadcastShape[0],1,1};
	int64_t kernel_H = filter->shape[2];
	int64_t kernel_W = filter->shape[3];
	int64_t out_row = output->shape[output->shape.size() - 2];
	int64_t out_col = output->shape[output->shape.size() - 1];
	new_shape[2] = out_row * out_col;
	new_shape[1] = kernel_H * kernel_W * BroadcastShape[1];
	int64_t in_col = input->shape[input->shape.size() - 1];
	int64_t S_transform = new_shape[2] * new_shape[1];
	int64_t S_input = input->stride[input->stride.size() - 2];
	int64_t V_transform = S_transform;
	int64_t V_input = BroadcastShape[1] * BroadcastShape[2] * BroadcastShape[3];

	Tensor<FLOAT>* trans  = im2col(input,filter->shape[2], filter->shape[3],stride);
	Tensor<FLOAT>* dtrans = new Tensor<FLOAT>(new_shape,false);

	vector<int64_t> new_f_shape = { filter->shape[0],filter->shape[1] * filter->shape[2] * filter->shape[3] };

	dim3 block1(1);//block(B)
	dim3 grid1(new_f_shape[0], new_f_shape[1]);//grid()
	
	Convd2dGradientKernel_1 << <grid1, block1 >> > (trans->array,output->gradient->array,filter->gradient->array,
		BroadcastShape[0], new_shape[2], V_transform, new_shape[2] * new_f_shape[0], new_f_shape[0]);
	cudaDeviceSynchronize();

	dim3 block2(BroadcastShape[0]);//block(B)
	dim3 grid2(new_f_shape[1], new_shape[2]);//grid()
	Convd2dGradientKernel_2 << <grid2, block2 >> > (dtrans->array, output->gradient->array, filter->array,
		new_f_shape[0], new_shape[2], V_transform, new_shape[2] * new_f_shape[0]);
	cudaDeviceSynchronize();

	im2col(input->gradient, kernel_H, kernel_W, stride, dtrans);
	
	vector<int64_t>().swap(BroadcastShape);
	vector<int64_t>().swap(new_f_shape);
	vector<int64_t>().swap(new_shape);
	
	delete(trans);
	delete(dtrans);
}
#endif