#include "Template.h"
#ifndef _TENSOR_MUL_H_
#define _TENSOR_MUL_H_
template <typename FLOAT> 
__global__ void MulKernel(FLOAT* d_left, FLOAT* d_right, FLOAT* d_out,
	int64_t* d_Lstride, int64_t* d_Rstride, int64_t* d_out_stride,int64_t input_W)
{
	//threadIdx.x  threadIdx.y  blockIdx.x  blockIdx.y ;
	//batch_size   channel      H           W;
	int64_t left_id  = threadIdx.x * d_Lstride[0] + threadIdx.y * d_Lstride[1] + blockIdx.x * d_Lstride[2];
	int64_t right_id = threadIdx.x * d_Rstride[0] + threadIdx.y * d_Rstride[1] + blockIdx.y * d_Rstride[3];
	int64_t out_id   = CudaId(d_out_stride);

	for (int64_t i = 0; i < input_W; i++)
	{

		d_out[out_id] += d_left[i * d_Lstride[3] + left_id] * d_right[i * d_Rstride[2] + right_id];

	}
}


template <typename FLOAT> 
Tensor<FLOAT>* Tensor<FLOAT>::mul (Tensor<FLOAT>* right, Tensor<FLOAT>* out) {
	if (out == nullptr) {
		vector<int64_t> out_shape = shape;
		out_shape[out_shape.size() - 1] = right->shape[right->shape.size() - 1];
		out = new Tensor<FLOAT>(out_shape, false);
		vector<int64_t>().swap(out_shape);
	}
	int dim = (int)shape.size();
	vector<int64_t>& BroadcastShape = shape_broadcast(out->shape);

	dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
	dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)

	int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(stride));
	int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(right->stride));
	int64_t* d_s3 = VectorToCuda<int64_t>(stride_broadcast(out->stride));
	
	MulKernel << <grid, block >> > (array, right->array, out->array, d_s1, d_s2, d_s3,shape[shape.size() - 1]);
	cudaDeviceSynchronize();
	vector<int64_t>().swap(BroadcastShape);

	cudaFree(d_s1);
	cudaFree(d_s2);
	cudaFree(d_s3);
	return out;
}



#endif