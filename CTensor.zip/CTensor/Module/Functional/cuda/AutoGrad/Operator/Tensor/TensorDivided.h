#include "Template.h"
#ifndef _TENSOR_DIVIDED_H_
#define _TENSOR_DIVIDED_H_
template <typename FLOAT>
__global__ void DividedKernel(FLOAT* d_in, FLOAT value) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_in[id] = d_in[id] / value;
}
template <typename FLOAT>
void Tensor<FLOAT>::operator/=(FLOAT value) {

	dim3 block(1);
	DividedKernel << <AutoAllocateGrid(shape), block >> > (array, value);
	cudaDeviceSynchronize();

}
template <typename FLOAT>
__global__ void DividedKernel(FLOAT* d_left, FLOAT* d_right, FLOAT* d_out,
	int64_t* d_left_stride, int64_t* d_right_stride, int64_t* d_out_stride)
{
	int64_t left_id = CudaId(d_left_stride);
	int64_t right_id= CudaId(d_right_stride);
	int64_t out_id  = CudaId(d_out_stride);

	d_out[out_id] = d_left[left_id] / d_right[right_id];
}
template <typename FLOAT>
Tensor<FLOAT>* Tensor<FLOAT>::divide(Tensor<FLOAT>* right, Tensor<FLOAT>* out, bool keep_shape) {
	int dim = (int)shape.size();
	vector<int64_t>& BroadcastShapeA = shape_broadcast(shape);
	vector<int64_t>& BroadcastShapeB = shape_broadcast(right->shape);
	vector<int64_t>& BroadcastShape  = BroadcastRule<int64_t>(BroadcastShapeA, BroadcastShapeB);
	if (BroadcastShape.size() == 0) { return nullptr; }
	if (out == nullptr) {
		out = new Tensor<FLOAT>(BroadcastShape, false);
	}
	//ĳ�ֽ���ͬ��״shapeת����4ά����
	dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
	dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)

	int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(stride));
	int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(right->stride));
	int64_t* d_s3 = VectorToCuda<int64_t>(stride_broadcast(out->stride));

	DividedKernel << <grid, block >> > (array, right->array, out->array, d_s1, d_s2, d_s3);

	cudaDeviceSynchronize();
	cudaFree(d_s1);
	cudaFree(d_s2);
	cudaFree(d_s3);

	if (keep_shape)
	{
		for (int i = 0; i < (int)(BroadcastShapeA.size()); i++) {
			if (BroadcastShapeA[i] == 1 && BroadcastShape[i] != 1)
			{
				out = out->sum(i, out);
			}
		}
	}
	vector<int64_t>().swap(BroadcastShapeA);
	vector<int64_t>().swap(BroadcastShape);
	vector<int64_t>().swap(BroadcastShapeB);
	return out;
}
//warining: this function will cause memory leak !!!
//you must use this function by reference !!!
template <typename FLOAT>
Tensor<FLOAT> Tensor<FLOAT>::operator/(Tensor<FLOAT> right) {

	return *divide(right);

}
#endif
