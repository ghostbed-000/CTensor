#include "Template.h"

#ifndef _TENSOR_MAX_H_
#define _TENSOR_MAX_H_
template <typename FLOAT>
__global__ void MaxKernel(FLOAT* array, FLOAT* max,int64_t* index, int64_t* stride, int64_t dim_len, int64_t dim_stride)
{
	int64_t id = CudaId(stride);
	int64_t maxId = blockIdx.y + blockIdx.x * gridDim.y + threadIdx.y * gridDim.y * gridDim.x + threadIdx.x * gridDim.y * gridDim.x * blockDim.y;
	max[maxId] = array[id];
	index[maxId] = id;
	for (int64_t i = 1; i < dim_len; i++)
	{
		if (max[maxId] < array[id])
		{
			max[maxId]   = array[id];
			index[maxId] = id;
		}
		id += dim_stride;
	}
}
//only use for contiguous tensor
template <typename FLOAT>
tuple<FLOAT*,int64_t*> Tensor<FLOAT>::max(int32_t dim) {
	int64_t dim_len = shape[dim];
	shape[dim] = 1;
	vector<int64_t>& BroadcastShape = shape_broadcast(shape);
	shape[dim] = dim_len;
	int64_t dim_stride = shape[dim];
	int64_t* d_stride = VectorToCuda<int64_t>(stride_broadcast(stride));

	int64_t* d_index = nullptr;
	cudaMalloc((void**)&d_index, BroadcastShape[0] * BroadcastShape[1] * BroadcastShape[2] * BroadcastShape[3] * sizeof(int64_t));
	FLOAT* d_max = nullptr;
	cudaMalloc((void**)&d_max, BroadcastShape[0] * BroadcastShape[1] * BroadcastShape[2] * BroadcastShape[3] * sizeof(FLOAT));

	dim3 block(BroadcastShape[dim - 4], BroadcastShape[dim - 3]);//block(B,C)
	dim3 grid(BroadcastShape[dim - 2], BroadcastShape[dim - 1]);//grid(H,W)


	MaxKernel << < grid, block >> > (array, d_max,d_index, d_stride, dim_len, stride[dim]);

	cudaDeviceSynchronize();
	vector<int64_t>().swap(BroadcastShape);
	tuple<FLOAT*, int64_t*> t(d_max, d_index);

	return t;
}


#endif
