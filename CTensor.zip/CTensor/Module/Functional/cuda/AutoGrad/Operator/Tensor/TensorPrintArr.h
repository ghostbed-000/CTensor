#include "Template.h"
#ifndef _TENSOR_PRINT_ARR_H_
#define _TENSOR_PRINT_ARR_H_
template <typename FLOAT>
void print_matrix1d(FLOAT* host_array,vector<int64_t>& shape, vector<int64_t>& stride) {
	printf("Tensor:\n[");
	for (int64_t i = 0; i < shape[0]; i++) {
		printf("%lf,", (float)host_array[i]);
	}
	printf("]\n");
}
template <typename FLOAT>
void print_matrix2d(FLOAT* host_array, vector<int64_t>& shape, vector<int64_t>& stride) {
	printf("Tensor:\n[");
	for (int64_t i = 0; i < shape[0]; i++) {
		printf("[");
		for (int64_t j = 0; j < shape[1]; j++) {
			printf("%lf,", (float)host_array[i * stride[0] + j * stride[1]]);
		}
		printf("]\n");
	}
	printf("]\n");
}
template <typename FLOAT>
void print_matrix3d(FLOAT* host_array, vector<int64_t>& shape, vector<int64_t>& stride) {
	printf("Tensor:\n[");
	for (int64_t i = 0; i < shape[0]; i++) {
		printf("[");
		for (int64_t j = 0; j < shape[1]; j++) {
			printf("[");
			for (size_t k = 0; k < shape[2]; k++){
				printf("%lf,", (float)host_array[i * stride[0] + j * stride[1] + k * stride[2]]);
			}
			printf("]\n");
		}
		printf("]");
	}
	printf("]\n");
}
template <typename FLOAT>
void print_matrix4d(FLOAT* host_array, vector<int64_t>& shape, vector<int64_t>& stride) {
	printf("Tensor:\n[");
	for (int64_t i = 0; i < shape[0]; i++) {
		printf("[");
		for (int64_t j = 0; j < shape[1]; j++) {
			printf("[");
			for (int64_t k = 0; k < shape[2]; k++) {
				printf("[");
				for (int64_t q = 0; q < shape[3]; q++)
				{
					printf("%lf,", (float)host_array[i * stride[0] + j * stride[1] + k * stride[2] + q * stride[3]]);
				}
				printf("]\r\n");
			}
			printf("]\n");
		}
		printf("]");
	}
	printf("]\n");
}

template <typename FLOAT>
void Tensor<FLOAT>::print_arr() {
	FLOAT* host_array = to_cpu();
	FLOAT* host_grad  = nullptr;
	if (shape.size() == 4)
	{
		print_matrix4d(host_array, shape, stride);
	}
	if (shape.size() == 3)
	{
		print_matrix3d(host_array, shape, stride);
	}
	if (shape.size() == 2)
	{
		print_matrix2d(host_array, shape, stride);
	}
	if (shape.size() == 1)
	{
		print_matrix1d(host_array, shape, stride);
	}
	if (gradient != nullptr)
	{
		gradient->print_arr();
	}
	free(host_array);
	free(host_grad);
}

#endif // !_TENSOR_PRINT_ARR_H_

