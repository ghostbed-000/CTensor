#include "Template.h"
#ifndef _TENSOR_POW_H_
#define _TENSOR_POW_H_
template <typename FLOAT>
__global__ void PowKernel(FLOAT* d_left, FLOAT value) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_left[id] = powf(d_left[id],value);
}

template <typename FLOAT>
void Tensor<FLOAT>::pow(FLOAT value) { 

	dim3 block(1);
	PowKernel << <AutoAllocateGrid(shape), block >> > (array, value);
	cudaDeviceSynchronize();

}
template <typename FLOAT>
__global__ void SqrtKernel(FLOAT* d_left) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_left[id] = sqrtf(d_left[id]);
}

template <typename FLOAT>
void Tensor<FLOAT>::sqrt() {

	dim3 block(1);
	SqrtKernel << <AutoAllocateGrid(shape), block >> > (array);
	cudaDeviceSynchronize();

}



#endif