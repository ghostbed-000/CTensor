#include "Template.h"
#ifndef _TENSOR_RESHAPE_H_
#define _TENSOR_RESHAPE_H_
template <typename FLOAT>
Tensor<FLOAT>* Tensor<FLOAT>::reshape(int64_t* _shape,int32_t dim_size) {
	int64_t len = 1;
	for (int i = 0; i < dim_size; i++)
	{
		len *= _shape[i];
	}
	if (len != _len_) {
		std::cout << "the new size doesn't adapt to the before one!\n";
		exit(1);
	}
	vector<int64_t> new_shape;
	for (int i = 0; i < dim_size; i++)
	{
		new_shape.push_back(_shape[i]);
	}
	Tensor<FLOAT>* out = new Tensor<FLOAT>(array, new_shape,_requires_grad_);

	vector<int64_t>().swap(new_shape);
	return out;
}

template <typename FLOAT>
void Tensor<FLOAT>::reshape(vector<int64_t>& _shape) {
	int64_t len = 1;
	for (unsigned int i = 0; i < _shape.size(); i++)
	{
		len *= _shape[i];
	}
	if (len != _len_) {
		std::cout << "the new size doesn't adapt to the before one!\n";
		exit(1);
	}

	shape = _shape;
	vector<int64_t>().swap(_shape);
	size();

}

template <typename FLOAT>
void Tensor<FLOAT>::unsqueeze(int32_t dim) {
	if (dim < 0)
	{
		std::cout << "Tensor-method-unsqueeze-param-dim can't be less than 0!\n";
	}
	if (dim > shape.size())
	{
		std::cout << "Tensor-method-unsqueeze-param-dim out of range!\n";
	}
	shape.insert(shape.begin() + dim, 1);
	stride.insert(stride.begin() + dim, 0);
}


#endif