#include "Op.h"
#ifndef _SUB_OP_H_
#define _SUB_OP_H_

template <typename FLOAT>
class SubOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		input[0]->sub(input[1], output);
		vector<Tensor<FLOAT>*>().swap(input);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		Tensor<FLOAT> d_left = input[0]->gradient->add(doutput, nullptr, true);
		input[0]->gradient->add(d_left, input[0]->gradient);
		Tensor<FLOAT> d_right = input[1]->gradient->sub(doutput, nullptr, true);
		input[1]->gradient->add(d_right, input[1]->gradient);

		vector<Tensor<FLOAT>*>().swap(input);
		delete(d_left);
		delete(d_right);
	}
};

template <typename FLOAT>
Node<FLOAT>* SubNodeGenerator(Node<FLOAT>* left, Node<FLOAT>* right, Op<FLOAT>* op) {
	CheckShapeEqual(left->shape, right->shape);
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(left); input_nodes->push_back(right);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(left->shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Sub");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* sub(Node<FLOAT>* left, Node<FLOAT>* right) {
		SubOp<FLOAT>* op = new SubOp<FLOAT>();
		Node<FLOAT>* x = SubNodeGenerator(left, right, op);
		op->compute(x);
		return x;
	}

}

#endif // !_ADD_OP_H_
