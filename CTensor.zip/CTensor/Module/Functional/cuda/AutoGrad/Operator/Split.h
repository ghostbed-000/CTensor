#include "Op.h"
#ifndef _SPLIT_H_
#define _SPLIT_H_
template <typename FLOAT>
__global__ void SplitGradientKernel(FLOAT* in_grad, FLOAT* out_grad, int64_t* out_stride,int64_t offset) 
{
	int64_t id = CudaId(out_stride);
	in_grad[id + offset] += out_grad[id];
}

template <typename FLOAT>
class SplitOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		return;
		UNUSED(node);
	}
	void gradient(Node<FLOAT>* node) {
		Tensor<FLOAT*>* input = node->input[0][0]->value;
		Tensor<FLOAT*>* output = node->value;
		vector<int64_t> BroadcastShape = shape_broadcast(output->gradient->shape);
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)

		int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(output->gradient->stride));
		SplitGradientKernel << <grid, block >> > (input->gradient->array, output->gradient->array, d_s1, node->param[1]);
		cudaDeviceSynchronize();
		cudaFree(d_s1);
	}
};

template <typename FLOAT>
vector<Node<FLOAT>*> SplitNodeGenerator(Node<FLOAT>* input,int32_t dim, Op<FLOAT>* op) {
	vector<Node<FLOAT>*> output;
	vector<Tensor<FLOAT>*> out_tensor = input->value->split(dim);
	int offset = input->value->stride[dim];
	for (int i = 0; i < out_tensor.size(); i++)
	{
		Node<FLOAT>* output_node = new Node<FLOAT>(op, output, out_tensor[i], _NODE_SUM_ - 1);
		NodeGeneratorDecorator(output_node, "Split");
		output.push_back(output_node);
		output_node->param->push_back(dim);
		output_node->param->push_back(offset * i);
	}

	return output;
}
namespace Functional {
	template <typename FLOAT>
	//all the output Nodes should be used or it will cause memory leaking
	vector<Node<FLOAT>*> split(Node<FLOAT>* input, int32_t dim) {
		SplitOp<FLOAT>* op = new SplitOp<FLOAT>();
		//op->compute(x);
		return SplitNodeGenerator(input, dim, op);
	}

}

#endif // !_CONCAT_H_



