#include "Op.h"
#ifndef _TANH_OP_H_
#define _TANH_OP_H_
template <typename FLOAT>
__global__ void TanhKernel(FLOAT* d_in, FLOAT* d_out) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	FLOAT a = expf(d_in[id]);
	FLOAT b = 1 / a;
	d_out[id] = (a - b) / (a + b);
}

template <typename FLOAT>
__global__ void TanhGradientKernel(FLOAT* d_in, FLOAT* d_out, FLOAT* d_in_grad, FLOAT* d_out_grad) {
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_in_grad[id] += (1 / powf(cosf(d_in[id]), 2)) * d_out_grad[id];
}

template <typename FLOAT>
class TanhOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, TanhKernel);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, TanhGradientKernel);
	}
};

template <typename FLOAT>
Node<FLOAT>* TanhNodeGenerator(Node<FLOAT>* input, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(input->value), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Tanh");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* tanh(Node<FLOAT>* input) {
		TanhOp<FLOAT>* op = new TanhOp<FLOAT>();
		Node<FLOAT>* x = TanhNodeGenerator(input, op);
		op->compute(x);
		return x;
	}

}
#endif