#include "Op.h"
#ifndef _MAT_MUL_H_
#define _MAT_MUL_H_


template <typename FLOAT>
class MatMulOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		Tensor<FLOAT>* left  = node->input[0][0]->value;
		Tensor<FLOAT>* right = node->input[0][1]->value;
		Tensor<FLOAT>* output= node->value;
		output->zero_();
		left->mul(right, output);
	}
	void gradient(Node<FLOAT>* node) {
		Tensor<FLOAT>* left = node->input[0][0]->value;
		Tensor<FLOAT>* right = node->input[0][1]->value;
		Tensor<FLOAT>* tmp = nullptr;
		Tensor<FLOAT>* doutput = node->value->gradient;
		
		left->TransposeItself(); tmp = left->mul(doutput); left->TransposeItself();
		for (unsigned int i = 0; i < left->shape.size() - 2;i++) {
			tmp->sum(i, tmp);
		}
		*(right->gradient) = tmp;
		right->TransposeItself(); doutput->mul(right, left->gradient); right->TransposeItself();
		delete(tmp);
	}
};

template <typename FLOAT>
Node<FLOAT>* MatMulNodeGenerator(Node<FLOAT>* left, Node<FLOAT>* right, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(left); input_nodes->push_back(right);
	vector<int64_t> shape = input_nodes[0][0]->value->shape;
	shape[shape.size() - 1] = right->value->shape[right->value->shape.size() - 1];
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "MatMul");
	vector<int64_t>().swap(shape);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* mm(Node<FLOAT>* left, Node<FLOAT>* right) {
		MatMulOp<FLOAT>* op = new MatMulOp<FLOAT>();
		Node<FLOAT>* x = MatMulNodeGenerator(left, right, op);
		op->compute(x);
		return x;
	}

}
#endif