#include "Op.h"
#ifndef _CONVD_2D_OP_H
#define _CONVD_2D_OP_H

template <typename FLOAT>
class Convd2dOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		output->zero_();
		Conv2d(input[0], input[1],node->param[0], output);
		vector<Tensor<FLOAT>*>().swap(input);
	}

	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;

		Conv2dGradient(input[0], input[1], output, node->param[0]);
		vector<Tensor<FLOAT>*>().swap(input);
	}
};

template <typename FLOAT>
Node<FLOAT>* Convd2dNodeGenerator(Node<FLOAT>* input, Node<FLOAT>* filter, int32_t stride, Op<FLOAT>* op) {
	if (input->value->shape.size() > 4 || input->value->shape.size() < 2)
	{
		std::cout << "Convd2dNodeGenerator : input has a wrong size!\n"; exit(1);
	}
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	int64_t out_row = (input->value->shape[input->value->shape.size() - 2] - filter->value->shape[2]) / stride + 1;
	int64_t out_col = (input->value->shape[input->value->shape.size() - 1] - filter->value->shape[3]) / stride + 1;
	vector<int64_t> out_shape = { 1,filter->value->shape[0],out_row,out_col };
	if (input->value->shape.size() == 4)
	{
		out_shape[0] = input->value->shape[0];
	}
	input_nodes->push_back(input);
	input_nodes->push_back(filter);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(out_shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Convd2d");
	output_node->param.push_back(stride);

	vector<int64_t>().swap(out_shape);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* conv2d(Node<FLOAT>* input, Node<FLOAT>* filter, int32_t stride) {
		Convd2dOp<FLOAT>* op = new Convd2dOp<FLOAT>();
		Node<FLOAT>* x = Convd2dNodeGenerator(input, filter, stride, op);
		op->compute(x);
		return x;
	}

}
#endif // !_CONVD_2D_OP_H
