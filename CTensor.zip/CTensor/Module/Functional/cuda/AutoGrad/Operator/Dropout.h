#include "Op.h"
#ifndef _DROPOUT_H_
#define _DROPOUT_H_
template <typename FLOAT>
__global__ void DropoutKernel(FLOAT* d_in, FLOAT* d_out, curandState* states) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	if (curand(&states[id]) % 2 == 0)
	{
		d_out[id] = 0;
	}
	else {
		d_out[id] = d_in[id];
	}
}

template <typename FLOAT>
__global__ void DropoutGradientKernel(FLOAT* d_in, FLOAT* d_in_grad, FLOAT* d_out, FLOAT* d_out_grad) {
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	if (d_in[id] != 0) {
		d_in_grad[id] += d_out_grad[id];
	}
	return;
	UNUSED(d_out);
}

template <typename FLOAT>
class DropoutOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*>& input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		curandState* states;
		cudaMalloc(&states, output->_len_ * sizeof(curandState));
		srand((unsigned int)time(0));
		dim3 block(1);
		SetupCurandStates << <AutoAllocateGrid(output->shape), block >> > (states, time(0));
		cudaDeviceSynchronize();
		DropoutKernel << <AutoAllocateGrid(output->shape), block >> > (input[0]->array,output->array, states);
		cudaDeviceSynchronize();
		vector<Tensor<FLOAT>*>().swap(input);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, DropoutGradientKernel);
		vector<Tensor<FLOAT>*>().swap(input);
	}
	~DropoutOp(){}
};

template <typename FLOAT>
Node<FLOAT>* DropoutNodeGenerator(Node<FLOAT>* input, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(input->value), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Dropout");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* dropout(Node<FLOAT>* input) {
		DropoutOp<FLOAT>* op = new DropoutOp<FLOAT>();
		Node<FLOAT>* x = DropoutNodeGenerator(input, op);
		op->compute(x);
		return x;
	}

}

#endif // !_DROPOUT_H_

