#include "Op.h"

#ifndef _SIN_OP_
#define _SIN_OP_
template <typename FLOAT>
__global__ void SinKernel(FLOAT* d_in, FLOAT* d_out) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_out[id] = sinf(d_in[id]);
}
template <typename FLOAT>
__global__ void SinGradientKernel(FLOAT* d_in, FLOAT* d_out, FLOAT* d_in_grad,  FLOAT* d_out_grad) {
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_in_grad[id] += cosf(d_in[id]) * d_out_grad[id];
}

template <typename FLOAT>
class SinOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, SinKernel);
		vector<Tensor<FLOAT>*>().swap(input);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, SinGradientKernel);
		vector<Tensor<FLOAT>*>().swap(input);
	}
};

template <typename FLOAT>
Node<FLOAT>* SinNodeGenerator(Node<FLOAT>* input, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(input->value), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Sin");
	return output_node;
}
namespace Functional {
template <typename FLOAT>
Node<FLOAT>* sin(Node<FLOAT>* input) {
	SinOp<FLOAT>* op = new SinOp<FLOAT>();
	Node<FLOAT>* x = SinNodeGenerator(input, op);
	op->compute(x);
	return x;
}

}

#endif // !_SIN_OP_

