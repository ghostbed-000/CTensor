#include "Op.h"
#ifndef _LAYER_NORM_AFFINE_OP_H_
#define _LAYER_NORM_AFFINE_OP_H_
template <typename FLOAT>
class NormAffine2dOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		Tensor<FLOAT>* input  = node->input[0][0]->value;
		Tensor<FLOAT>* gammar = node->input[0][1]->value;
		Tensor<FLOAT>* beta   = node->input[0][2]->value;

		Tensor<FLOAT>* output = node->value;
		input->dotmul(gammar, output);
		output->add(beta, output);
	}
	void gradient(Node<FLOAT>* node) {
		Tensor<FLOAT>* input   = node->input[0][0]->value;
		Tensor<FLOAT>* gammar  = node->input[0][1]->value;
		Tensor<FLOAT>* beta    = node->input[0][2]->value;
		Tensor<FLOAT>* doutput = node->value->gradient;
		vector<int64_t> dim;
		for (int i = 0; i < input->shape.size(); i++) {
			if (i != node->param[0])
			{
				dim.push_back(i);
			}
		}
		// dL / dbeta   = sum(dL / dy)
		Tensor<FLOAT>* sum_1 = doutput->sum(dim);
		beta->gradient->add(sum_1, beta->gradient);
		// dL / dx		= (dL / dy) * gammar
		doutput->dotmul(gammar, input->gradient);
		// dL / dgammar = sum(dL / dy * x)
		doutput->dotmul(input, doutput);
		Tensor<FLOAT>* sum_2 = doutput->sum(dim);
		gammar->gradient->add(sum_2, gammar->gradient);

		vector<Tensor<FLOAT>*>().swap(dim);
		delete(sum_1);
		delete(sum_2);
	}
};
template <typename FLOAT>
Node<FLOAT>* Norm2dAffineNodeGenerator(Node<FLOAT>* input, Node<FLOAT>* gammar, Node<FLOAT>* beta,int32_t dim, Op<FLOAT>* op = nullptr) {
	vector<FLOAT>& shape = input->shape;
	if (input->shape.size() > 1)
	{
		printf("the input which is LayerNorm2dAffine should have at least two dimension!\n"); return;
	}
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	input_nodes->push_back(gammar);
	input_nodes->push_back(beta);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "LayerNorm2dAffine");
	output_node->param.push_back[dim];
	return output_node;
}
namespace Functional {
	//this function's gammar and beta must be adapt to input's shape
	//param-dim : the tensor'dim can't be sumed
	template <typename FLOAT>
	Node<FLOAT>* norm2d_affine(Node<FLOAT>* input, Node<FLOAT>* gammar, int32_t dim, Node<FLOAT>* beta) {
		NormAffine2dOp<FLOAT>* op = new NormAffine2dOp<FLOAT>();
		Node<FLOAT>* x = Norm2dAffineNodeGenerator(input, gammar, beta, dim, op);
		op->compute(x);
		return x;
	}

}



#endif