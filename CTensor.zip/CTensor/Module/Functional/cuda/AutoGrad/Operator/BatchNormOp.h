#include "Op.h"
#ifndef _BATCH_NORM_OP_H_
#define _BATCH_NORM_OP_H_
template <typename FLOAT>
__global__ void BatchNormGradientKernel(FLOAT* left, FLOAT* right, int64_t* Lstride, FLOAT eps)
{
	int64_t left_id = CudaId(Lstride);

	left[left_id] /= sqrtf(right[threadIdx.y] + eps);
}
template <typename FLOAT>
class BatchNorm2dOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) override {
		vector<Tensor<FLOAT>*> x = node->input2values();
		Tensor<FLOAT>* x_hat = node->value;
		Tensor<FLOAT>* input = x[0];
		Tensor<FLOAT>* mean    = nullptr;
		Tensor<FLOAT>* var     = nullptr;
		Tensor<FLOAT>* tmp_var = nullptr;
		vector<int32_t> dim = { 0,2,3 };
		int64_t N = input->shape[0] * input->shape[2] * input->shape[3];
		mean = input->mean(dim);
		var  = input->sub(mean, var);
		*var += 0.00001;// +eps
		var->pow((FLOAT)2);
		tmp_var = var->sum(dim);
		*tmp_var /= (FLOAT)(N);
		*x[2] = tmp_var;
		tmp_var->sqrt();
		input->sub(mean, x_hat);
		x_hat->divide(tmp_var, x_hat);
		
		delete(mean->keep_len(x[1]->array));
		vector<Tensor<FLOAT>*>().swap(x);
		vector<int32_t>().swap(dim);
		delete(var);
		delete(mean);
		delete(tmp_var);
		
	}
	void gradient(Node<FLOAT>* node) override {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		*(input[0]->gradient) = doutput;

		vector<int64_t>& BroadcastShape = input[0]->shape;
		//ĳ�ֽ���ͬ��״shapeת����4ά����
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)
		int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(input[0]->stride));

		BatchNormGradientKernel << <grid, block >> > (input[0]->gradient->array, input[2]->array, d_s1,(FLOAT)node->param[0]);

		vector<Tensor<FLOAT>*>().swap(input);
		cudaDeviceSynchronize();
		cudaFree(d_s1);
	}
};

template <typename FLOAT>
Node<FLOAT>* BatchNorm2dNodeGenerator(Node<FLOAT>* input, Node<FLOAT>* mean, Node<FLOAT>* var, int32_t eps = 0.00001, Op<FLOAT>* op = nullptr) 
{
	if (input->value->shape.size() < 3 && mean->value->shape.size() > 1 && var->value->shape.size() > 1)
	{
		std::cout << "input's tensor must be 4D but not less than 4D!\n";
		std::cout << "mean's  tensor must be 1D but not more than 1D!\n";
		std::cout << "var's   tensor must be 1D but not more than 1D!\n";
		exit(1);
	}
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	input_nodes->push_back(mean);
	input_nodes->push_back(var);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(input->value->shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "BatchNorm");
	output_node->param.push_back(eps);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* batch_norm(Node<FLOAT>* input, Node<FLOAT>* running_mean, Node<FLOAT>* running_var, int32_t eps = 0.00001) {
		BatchNorm2dOp<FLOAT>* op = new BatchNorm2dOp<FLOAT>();
		Node<FLOAT>* x = BatchNorm2dNodeGenerator(input, running_mean, running_var, eps, op);
		op->compute(x);
		return x;
	}

}
#endif