#include "Op.h"
#ifndef _EXP_OP_H_
#define _EXP_OP_H_
template <typename FLOAT>
__global__ void ExpKernel(FLOAT* d_in, FLOAT* d_out) {

	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_out[id] = expf(d_in[id]);
}

template <typename FLOAT>
__global__ void ExpGradientKernel(FLOAT* d_in, FLOAT* d_out, FLOAT* d_in_grad, FLOAT* d_out_grad) {
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_in_grad[id] += expf(d_in[id]) * d_out_grad[id];
}

template <typename FLOAT>
class ExpOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, ExpKernel);
		vector<Tensor<FLOAT>*>().swap(input);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		_ASSIGNED_FUNCTION_(input[0], node->value, ExpGradientKernel);
		vector<Tensor<FLOAT>*>().swap(input);
	}
	~ExpOp(){}
};

template <typename FLOAT>
Node<FLOAT>* ExpNodeGenerator(Node<FLOAT>* input, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(input->value), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Exp");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* exp(Node<FLOAT>* input) {
		ExpOp<FLOAT>* op = new ExpOp<FLOAT>();
		Node<FLOAT>* x = ExpNodeGenerator(input, op);
		op->compute(x);
		return x;
	}

}

#endif // !_EXP_OP_H_

