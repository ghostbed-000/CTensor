#include "Op.h"
#ifndef _RESHAPE_OP_H_
#define _RESHAPE_OP_H_

template <typename FLOAT>
//warning: it haven't been tested!//be careful ,it has many traps!!!
//permute <=> Transpose
class ReshapeOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		return;
		UNUSED(node);
	}
	void gradient(Node<FLOAT>* node) {
		Tensor<FLOAT>* input  = node->input[0][0]->value;
		Tensor<FLOAT>* output = node->value;
		cudaMemcpy(input->gradient->array, output->gradient->array,
			output->_len_ * sizeof(FLOAT), cudaMemcpyDeviceToDevice);
	}
};

template <typename FLOAT>
Node<FLOAT>* ReshapeOpNodeGenerator(Node<FLOAT>* input, vector<int64_t>& shape, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Tensor<FLOAT>* value = new Tensor<FLOAT>(input->value->array,shape, input->value->_requires_grad_);
	value->_is_reference_ = true;
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, value, _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Reshape");
	return output_node;
}
template <typename FLOAT>
Node<FLOAT>* UnsqueezeOpNodeGenerator(Node<FLOAT>* input, int32_t dim, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Tensor<FLOAT>* value = new Tensor<FLOAT>(input->value->array, input->value->shape, input->value->_requires_grad_);
	value->unsqueeze(dim);
	value->_is_reference_ = true;
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, value, _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "Unsqueeze");
	return output_node;
}
/*
template <typename FLOAT>
Node<FLOAT>* ViewOpNodeGenerator(Node<FLOAT>* input, int32_t dim, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Tensor<FLOAT>* value = new Tensor<FLOAT>(input->value->array, input->value->shape, input->value->_requires_grad_);

	value->_is_reference_ = true;
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, value, _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "View");
	return output_node;
}
*/

namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* reshape(Node<FLOAT>* input, vector<int64_t>& shape) {
		ReshapeOp<FLOAT>* op = new ReshapeOp<FLOAT>();
		Node<FLOAT>* x = ReshapeOpNodeGenerator(input, shape, op);
		op->compute(x);
		return x;
	}
	template <typename FLOAT>
	Node<FLOAT>* unsqueeze(Node<FLOAT>* input, int32_t dim) {
		ReshapeOp<FLOAT>* op = new ReshapeOp<FLOAT>();
		Node<FLOAT>* x = UnsqueezeOpNodeGenerator(input, dim, op);
		op->compute(x);
		return x;
	}
	/*
	template <typename FLOAT>
	Node<FLOAT>* view(Node<FLOAT>* input, int32_t dim) {
		ReshapeOp<FLOAT>* op = new ReshapeOp<FLOAT>();
		Node<FLOAT>* x = ViewOpNodeGenerator(input, dim, op);
		op->compute(x);
		return x;
	}	
	*/

}


#endif // !_TRANSPOSE_OP_H_