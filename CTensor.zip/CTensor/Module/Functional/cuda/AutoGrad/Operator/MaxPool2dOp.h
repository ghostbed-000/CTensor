#include "Op.h"
#ifndef _MAX_POOL_2D_OP_H_
#define _MAX_POOL_2D_OP_H_ 

template <typename FLOAT> 
__global__ void MaxPoolKernel(FLOAT* d_input,FLOAT* d_out,int64_t* d_input_stride, int64_t* d_out_stride,
	int64_t kernel_H, int64_t kernel_W, int64_t stride) {
	int64_t in_id  = threadIdx.x * d_input_stride[0]
		+ threadIdx.y * d_input_stride[1]
		+ blockIdx.x * d_input_stride[2] * stride
		+ blockIdx.y * d_input_stride[3] * stride;
	int64_t out_id = CudaId(d_out_stride);
	FLOAT max = d_input[in_id];
	int64_t max_id = in_id;
	int64_t tmp_id;
	for (int64_t i = 0; i < kernel_H; i++) {
		for (int64_t j = 0; j < kernel_W; j++) {
			tmp_id = in_id + j + i * d_input_stride[2];
			if (max <= d_input[tmp_id]) {
				max_id = tmp_id;
				max = d_input[max_id];
			}
			else {
				d_input[tmp_id] = 0;
			}
		}
	}
	d_out[out_id] = max;
}
template <typename FLOAT>
__global__ void MaxPoolGradientKernel(FLOAT* d_input, FLOAT* d_input_grad, FLOAT* d_out_grad,
	int64_t* d_input_stride, int64_t* d_out_stride, int64_t kernel_H, int64_t kernel_W, int64_t stride) {
	int64_t in_id = threadIdx.x * d_input_stride[0]
		+ threadIdx.y * d_input_stride[1]
		+ blockIdx.x * d_input_stride[2] * stride
		+ blockIdx.y * d_input_stride[3] * stride;
	int64_t out_id = CudaId(d_out_stride);
	int64_t tmp_id;
	for (int64_t i = 0; i < kernel_H; i++) {
		for (int64_t j = 0; j < kernel_W; j++) {
			tmp_id = in_id + j + i * d_input_stride[2];
			if (d_input[tmp_id] != 0) {
				d_input_grad[tmp_id] += d_out_grad[out_id];
				break;
			}
		}
	}
}

template <typename FLOAT>
class MaxPool2dOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* output = node->value;
		int dim = (int)output->shape.size();
		vector<int64_t> BroadcastShape = shape_broadcast(output->shape);
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)
		int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(input[0]->stride));
		int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(output->stride));
		MaxPoolKernel << <grid, block >> > (input[0]->array, output->array, d_s1, d_s2,node->param[0], node->param[1], node->param[2]);
		cudaDeviceSynchronize();
		vector<Tensor<FLOAT>*>().swap(input);
		cudaFree(d_s1);
		cudaFree(d_s2);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		int dim = (int)doutput->shape.size();
		vector<int64_t> BroadcastShape = shape_broadcast(doutput->shape);
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)
		int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(input[0]->stride));
		int64_t* d_s2 = VectorToCuda<int64_t>(stride_broadcast(doutput->stride));
		MaxPoolGradientKernel << <grid, block >> > (input[0]->array, input[0]->gradient->array, doutput->array, 
			d_s1, d_s2, node->param[0], node->param[1], node->param[2]);
		cudaDeviceSynchronize();
		cudaFree(d_s1);
		cudaFree(d_s2);
	}
};

template <typename FLOAT>
Node<FLOAT>* MaxPool2dNodeGenerator(Node<FLOAT>* input, vector<int32_t>& kernel_size,int32_t stride, Op<FLOAT>* op) {
	vector<int64_t> shape = input->value->shape;
	if (shape.size() < 2)
	{
		printf("the tensor which is maxpool should have at least two dimension!\n"); exit(true);
	}
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	shape[shape.size() - 1] = (shape[shape.size() - 1] - kernel_size[1]) / stride + 1;
	shape[shape.size() - 2] = (shape[shape.size() - 2] - kernel_size[0]) / stride + 1;
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "MaxPool2d");
	output_node->param.push_back(kernel_size[0]);
	output_node->param.push_back(kernel_size[1]);
	output_node->param.push_back(stride);
	vector<int64_t>().swap(shape);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* max_pool2d(Node<FLOAT>* input, int32_t kernel_size = 2, int32_t stride = 2) {
		MaxPool2dOp<FLOAT>* op = new MaxPool2dOp<FLOAT>();
		vector<int32_t> kernel = { kernel_size ,kernel_size };
		Node<FLOAT>* x = MaxPool2dNodeGenerator(input, kernel, stride, op);
		op->compute(x);
		return x;
	}
	template <typename FLOAT>
	Node<FLOAT>* max_pool2d(Node<FLOAT>* input, vector<int32_t>& kernel_size, int32_t stride = 2) {
		MaxPool2dOp<FLOAT>* op = new MaxPool2dOp<FLOAT>();
		Node<FLOAT>* x = MaxPool2dNodeGenerator(input, kernel_size, stride, op);
		op->compute(x);
		return x;
	}

}

#endif // !_MAX_POOL_2D_OP_H_
