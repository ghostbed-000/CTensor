#include "Op.h"
#ifndef _LAYER_NORM_OP_H_
#define _LAYER_NORM_OP_H_
template <typename FLOAT>
__global__ void LayerNormGradientKernel(FLOAT* left, FLOAT* right, int64_t* Lstride, FLOAT eps)
{
	int64_t left_id = CudaId(Lstride);

	left[left_id] /= sqrtf(right[threadIdx.x] + eps);
}
template <typename FLOAT>
class LayerNorm2dOp : public Op<FLOAT> {
public:
	void compute(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> x = node->input2values();
		Tensor<FLOAT>* x_hat = node->value;
		Tensor<FLOAT>* input = x[0];
		Tensor<FLOAT>* mean = nullptr;
		Tensor<FLOAT>* var = nullptr;
		Tensor<FLOAT>* tmp_var = nullptr;
		vector<int32_t> dim;
		int64_t N = 1;
		for (unsigned int i = 1;i < input->shape.size();i++) {
			dim.push_back(i);
			N *= input->shape[i];
		}
		mean = input->mean(dim);
		var = input->sub(mean, var);
		*var += 0.00001;
		var->pow((FLOAT)2);
		tmp_var = var->sum(dim);
		*tmp_var /= (FLOAT)(N);
		*x[2] = tmp_var;
		tmp_var->sqrt();
		input->sub(mean, x_hat);
		x_hat->divide(tmp_var, x_hat);

		delete(mean->keep_len(x[1]->array));
		vector<Tensor<FLOAT>*>().swap(x);
		vector<int32_t>().swap(dim);
		delete(var);
		delete(mean);
		delete(tmp_var);
	}
	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		Tensor<FLOAT>* doutput = node->value->gradient;
		*(input[0]->gradient) = doutput;

		vector<int64_t>& BroadcastShape = input[0]->shape;
		//ĳ�ֽ���ͬ��״shapeת����4ά����
		dim3 block(BroadcastShape[0], BroadcastShape[1]);//block(B,C)
		dim3 grid(BroadcastShape[2], BroadcastShape[3]);//grid(H,W)
		int64_t* d_s1 = VectorToCuda<int64_t>(stride_broadcast(input[0]->stride));

		LayerNormGradientKernel << <grid, block >> > (input[0]->gradient->array, input[2]->array, d_s1, 0.00001);

		cudaDeviceSynchronize();

		vector<Tensor<FLOAT>*>().swap(input);
		cudaFree(d_s1);
	}
};

template <typename FLOAT>
Node<FLOAT>* LayerNorm2dNodeGenerator(Node<FLOAT>* input, Node<FLOAT>* mean, Node<FLOAT>* var, FLOAT eps = 0.00001, Op<FLOAT>* op = nullptr) {
	vector<FLOAT>& shape = input->shape;
	if (input->shape.size() < 2)
	{
		printf("the tensor which is LayerNorm2d should have at least two dimension!\n"); exit(1);
	}
	vector<int64_t> shape2 = { input->shape[0] };
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	input_nodes->push_back(Functional::Variable<FLOAT>(mean));
	input_nodes->push_back(Functional::Variable<FLOAT>(var));
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(shape), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "LayerNorm2d");
	output_node->param.push_back(eps);
	vector<int64_t>().swap(shape);
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* layer_norm2d(Node<FLOAT>* input,Node<FLOAT>* mean, Node<FLOAT>* var, FLOAT eps = 0.00001) {
		LayerNorm2dOp<FLOAT>* op = new LayerNorm2dOp<FLOAT>();
		Node<FLOAT>* x = LayerNorm2dNodeGenerator(input,mean,var, eps, op);
		op->compute(x);
		return x;
	}

}
#endif