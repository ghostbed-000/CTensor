#include "Op.h"

#ifndef _CROSS_ENTROPY_OP_H_
#define _CROSS_ENTROPY_OP_H_
template <typename FLOAT>
__global__ void CrossEntropyGradientKernel(FLOAT* d_in, FLOAT* d_target, FLOAT* d_in_grad) 
{
	//gridDim.x : num of classes
	int64_t id = blockIdx.y + blockIdx.x * gridDim.y + blockIdx.z * gridDim.x * gridDim.y;
	d_in_grad[id] -= d_target[id] / (gridDim.x * d_in[id]);

}

template <typename FLOAT>
class CrossEntropyLossOp : public Op<FLOAT> {
	Tensor<FLOAT>* target = nullptr;
public:
	void compute(Node<FLOAT>* input) { UNUSED(input); }
	void compute(Node<FLOAT>* input_node, Tensor<FLOAT>* one_hot_target) {
		vector<Tensor<FLOAT>*> input = input_node->input2values();
		vector<int32_t> dim;
		target = one_hot_target;
		Tensor<FLOAT> tmp(input[0],false,false,true);
		tmp += 0.00001;
		tmp.log();
		tmp.dotmul(one_hot_target,&tmp);
		tmp *= (FLOAT)(-1.0) ;
		tmp /= (FLOAT)(input[0]->shape[input[0]->shape.size() - 2]);
		for (unsigned int i = 0; i < input[0]->shape.size(); i++)
		{
			dim.push_back(i);
		}
		delete(input_node->value);
		input_node->value = tmp.mean(dim);
		*(input_node->value) *= input[0]->_len_;
		vector<Tensor<FLOAT>*>().swap(input);
	}

	void gradient(Node<FLOAT>* node) {
		vector<Tensor<FLOAT>*> input = node->input2values();
		dim3 block(1);
		CrossEntropyGradientKernel << <AutoAllocateGrid(input[0]->shape), block >> > (input[0]->array, target->array,input[0]->gradient->array);
		cudaDeviceSynchronize();
		vector<Tensor<FLOAT>*>().swap(input);

	}
	~CrossEntropyLossOp(){
		if (target)
		{
			delete(target);
		}
		target = nullptr;
	}
};

template <typename FLOAT>
Node<FLOAT>* CrossEntropyNodeGenerator(Node<FLOAT>* input, Op<FLOAT>* op) {
	vector<Node<FLOAT>*>* input_nodes = new vector<Node<FLOAT>*>();
	input_nodes->push_back(input);
	Node<FLOAT>* output_node = new Node<FLOAT>(op, input_nodes, new Tensor<FLOAT>(0.0), _NODE_SUM_ - 1);
	NodeGeneratorDecorator(output_node, "CrossEntropy");
	return output_node;
}
namespace Functional {
	template <typename FLOAT>
	Node<FLOAT>* cross_entropy(Node<FLOAT>* input,Tensor<FLOAT>* one_hot_target) {

		if (CheckShapeEqual(input->value->shape, one_hot_target->shape))
		{
			CrossEntropyLossOp<FLOAT>* op = new CrossEntropyLossOp<FLOAT>();
			Node<FLOAT>* x = CrossEntropyNodeGenerator(input, op);
			op->compute(x, one_hot_target);
			return x;
		}
		else {
			std::cout << "F::cross_entropy : one_hot_target's shape is different to input's one!\n";
			exit(1);
		}
	}
}

#endif