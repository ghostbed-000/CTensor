
//single in , single out
#include "Operator/Dropout.h"
#include "Operator/OneHot.h"
#include "Operator/SinOp.h"
#include "Operator/CosOp.h"
#include "Operator/ExpOp.h"
#include "Operator/LnOp.h"
#include "Operator/LeakyReLUOp.h"
#include "Operator/ReLUOp.h"
#include "Operator/TanhOp.h"
#include "Operator/SigmoidOp.h"
#include "Operator/SiLUOp.h"
#include "Operator/TransposeOp.h"  
#include "Operator/PadOp.h"
#include "Operator/MaxPool2dOp.h"
#include "Operator/UpsampleNearest2d.h"
#include "Operator/SoftmaxOp.h"
#include "Operator/ReshapeOp.h"

//multiple in, single out
#include "Operator/MatMulOp.h"
#include "Operator/Embedding.h"
#include "Operator/Convd2dOp.h"
#include "Operator/AddOp.h"
#include "Operator/SubOp.h"
#include "Operator/BatchNormOp.h"
#include "Operator/LayerNormOp.h" 
#include "Operator/NormAffineOp.h" 

//multiple in with param, single out
#include "Operator/Concat.h"
//single in, multiple out
#include "Operator/Split.h"
//others
#include "Operator/CrossEntropyOp.h"

