#include "OperatorUtils.h" 
#include <queue>

#ifndef _GRAPH_H_
#define _GRAPH_H_

using std::queue;
/*
	Graph is used to execute the neural network forward-propagating and backward-propagating
*/
template <typename FLOAT>
class Graph{
private:
	queue<Node<FLOAT>*> topo_list;

public:
	Graph(Node<FLOAT>* output,bool retain_grad);
	~Graph();
	void _BFS_(Node<FLOAT>* node,bool retain_grad);
	void Gradient(Node<FLOAT>* node);
	//static mode
	Node<FLOAT>* data;
	void static_forward();
	void static_backward(vector<Node<FLOAT>*>& output, bool retain_grad = false);

};
//Graph
template <typename FLOAT>
void Graph<FLOAT>::Gradient(Node<FLOAT>* node){
	//value initial
	if(node->value != nullptr){
		if(node->value->gradient == nullptr && node->value->_requires_grad_){
			node->value->gradient = new Tensor<FLOAT>(node->value->shape,false);
		}
	}
	if(node->input != nullptr){
		vector<Node<FLOAT>*>* input = node->input;
		for(unsigned int i = 0 ; i < (*input).size() ; i++){
			Node<FLOAT>* tmp_node = (*input)[i];
			if(tmp_node->value != nullptr){
				if(tmp_node->value->gradient == nullptr && tmp_node->value->_requires_grad_){
					tmp_node->value->gradient = new Tensor<FLOAT>(tmp_node->value->shape,false);
				}
			}		
		}
	}
	//calculate
	node->gradient();
}

template <typename FLOAT>
void Graph<FLOAT>::_BFS_(Node<FLOAT>* node,bool retain_grad){
	
	if(topo_list.empty() == 0){
		topo_list.pop();
	}	
	
	node->leave();
	Gradient(node);
	vector<Node<FLOAT>*>* input = node->input;
	if (input == nullptr){return;}
	for(unsigned int i = 0;i < input->size();i++)
	{
		if(!(*input)[i]->is_visited){
			topo_list.push((*input)[i]);
			(*input)[i]->visit();
		}
	}
	
	while (topo_list.size() != 0)
	{
		_BFS_(topo_list.front(), retain_grad);
	}
	
}
template <typename FLOAT>
Graph<FLOAT>::Graph(Node<FLOAT>* output, bool retain_grad)
{
	_BFS_(output, retain_grad);
}
template <typename FLOAT>
Graph<FLOAT>::~Graph()
{
	queue<Node<FLOAT>*>().swap(topo_list);
}

template <typename FLOAT>
void Graph<FLOAT>::static_forward() {
	int size_of_deque = _NODE_DEQUE_.size();
	for (int i = 0; i < size_of_deque; i++)
	{
		((Node<FLOAT>*)(_NODE_DEQUE_.front()))->op->compute();
		_NODE_DEQUE_.push_back(_NODE_DEQUE_.front());
		_NODE_DEQUE_.pop_front();
	}
}
template <typename FLOAT>
void Graph<FLOAT>::static_backward(vector<Node<FLOAT>*>& output, bool retain_grad) {
	for (int i = 0; i < output.size(); i++)
	{
		_BFS_(output[i]);
	}
}
//you can use Node<FLOAT>::backward() when it is dynamic calculate graph!
template <typename FLOAT>
void Node<FLOAT>::backward(Tensor<FLOAT>* output_grad, bool retain_grad) {
	if (output_grad != nullptr) {
		if (output_grad->_len_ == value->_len_) {
			value->gradient = output_grad;
		}
		else {
			std::cout << "these tensors don't match!" << std::endl;
			exit(1);
		}
	}
	else {
		if (value->_requires_grad_ == true)
		{
			value->gradient = new Tensor<FLOAT>(value->shape, false);
			value->gradient->constant_(1.0);
		}
	}

	Graph<FLOAT> gp(this, retain_grad);

	if (!retain_grad) {
		int size_of_deque = _NODE_DEQUE_.size();
		for (unsigned int i = 0; i < size_of_deque; i++)
		{
			Node<FLOAT>* node = (Node<FLOAT>*)(_NODE_DEQUE_.front());
			if (node->value->_retain_grad_ == false)
			{
				delete(node);
				_NODE_DEQUE_.pop_front();
			}
			else {
				_NODE_DEQUE_.push_back(node);
				_NODE_DEQUE_.pop_front();
			}
		}
	}

}
#endif
