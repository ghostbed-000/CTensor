#include "cpu/DeviceCheck.h"
#include "cuda/DeviceCheck.h"

#ifdef IS_CUDA_ON
#ifdef IS_CPU_ON
#error Only use one device! maybe you need to comment out the define in DeviceCheck.h!
#endif
#endif

#ifdef IS_CPU_ON
#ifdef IS_CUDA_ON
#error Only use one device! maybe you need to comment out the define in DeviceCheck.h!
#endif
#endif