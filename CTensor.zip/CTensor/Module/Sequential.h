#include "Module.h"

#ifndef _SEQURNTIAL_H_
#define _SEQURNTIAL_H_
namespace nn {
template <typename FLOAT>
class Sequential : public module{
public:
//status
	vector<module<FLOAT>*> list;
//method
	Node<FLOAT>* forward(Node<FLOAT>* input){
		Node<FLOAT>* x = input;
		for(unsigned int i=0;i<list.size();i++){
			x = list[i]->forward(x);
		}
		return x;
	}
	Node<FLOAT>* operator()(Node<FLOAT>* input) {
		return forward(input);
	}
	Sequential(module<FLOAT>* _list,int list_size){
		for(unsigned int i = 0;i < list_size;i++){
			list.push_back(_list[i]);
		}
	}
	~Sequential(){
		vector<module<FLOAT>*>().swap(list);
	}
	
	
	
};

}
#endif // !_SEQURNTIAL_H_
