#include "Functional/Functional.h"
#include <fstream>
//using std::ofstream;
//using std::ifstream;
#define UNUSED(x) (void)x
/*
	the base class for all container
	your model should also inherit from this "PUBLIC" class
*/
#ifndef _MODULE_H_
#define _MODULE_H_
namespace nn {
//void* : Tensor<FLOAT>*
vector<void*> Parameter;
template <typename FLOAT>
class module{
public:
	//virtual Node<FLOAT>* forward(Node<FLOAT>* input) { return nullptr; }
	virtual ~module(){}
	//initial the param
	virtual void reset_parameters() {}
	void save_weights(const std::string& path);
	void load_weights(const std::string& path);
};
template <typename FLOAT>
void module<FLOAT>::save_weights(const std::string& path) {
	Tensor<FLOAT>* this_tensor = nullptr;
	std::ofstream model_weights;
	model_weights.open(path, std::ios::app | std::ios::binary);
	if (!model_weights.is_open())
	{
		std::cout << "failed to open file" << path << std::endl; exit(1);
	}
	int32_t sizeof_FLOAT = sizeof(FLOAT);
	model_weights.write((const char*)&sizeof_FLOAT, sizeof(int32_t));
	for (unsigned int i = 0; i < Parameter.size(); i++)
	{
		this_tensor = (Tensor<FLOAT>*)(Parameter[i]);
		FLOAT* data = data2host(this_tensor->array, this_tensor->_len_);
		model_weights.write((const char*)data, this_tensor->_len_ * sizeof(FLOAT));
		free(data);
	}
	model_weights.close();
	std::cout << "the weights have been saved to " << path << std::endl;
}
template <typename FLOAT>
void module<FLOAT>::load_weights(const std::string& path) {
	Tensor<FLOAT>* this_tensor = nullptr;
	FLOAT* host_data;
	std::ifstream model_weights;
	model_weights.open(path, std::ios::in | std::ios::binary);
	if (!model_weights.is_open())
	{
		std::cout << "failed to open file" << path << std::endl; exit(1);
	}
	int32_t sizeof_FLOAT;
	model_weights.read((char*)&sizeof_FLOAT, sizeof(int32_t));
	if (sizeof_FLOAT != sizeof(FLOAT))
	{
		std::cout << "error : model weights'type isn't the same as the type you use now!\n"; exit(1);
	}
	for (unsigned int i = 0; i < Parameter.size(); i++)
	{
		this_tensor = (Tensor<FLOAT>*)(Parameter[i]);
		host_data = (FLOAT*)malloc(sizeof(FLOAT)* this_tensor->_len_);
		model_weights.read((char*)host_data, this_tensor->_len_ * sizeof(FLOAT));
		data2device(host_data, this_tensor->_len_, this_tensor->array);
		free(host_data);
	}
	model_weights.close();
}

template <typename FLOAT>
void register_parameter(Node<FLOAT>* input) {
	if (input != nullptr)
	{
		input->value->_retain_grad_ == true;
	}
	else {
		std::cout << "you can't register a null parameter!\n";
		exit(1);
	}
	Parameter.push_back((void*)(input->value));
}

template <typename T>
inline void CheckAndDelete(T* ptr) {
	if (!ptr)
	{
		delete(ptr); 
		ptr = nullptr;
	}
}
template <typename FLOAT>
void CheckInvalidValue(FLOAT& value) {
	if (value < 0)
	{
		std::cout << "ValueError : Value can't be less than ZERO!:" << value << std::endl;
		exit(1);
	}
}

}
#endif // !_MODULE_H_



