#include "Linear.h"
#ifndef _LSTM_H_
#define _LSTM_H_
namespace nn {
	template <typename FLOAT>
	class LSTMCell_ : public nn::module<FLOAT>
	{
	public:
		nn::Linear<FLOAT>* ix_linear;
		nn::Linear<FLOAT>* ih_linear;
		nn::Linear<FLOAT>* fx_linear;
		nn::Linear<FLOAT>* fh_linear;
		nn::Linear<FLOAT>* ox_linear;
		nn::Linear<FLOAT>* oh_linear;
		nn::Linear<FLOAT>* cx_linear;
		nn::Linear<FLOAT>* ch_linear;
		//method
		LSTMCell_(int64_t in_dim, int64_t hidden_dim) {
			ix_linear = new nn::Linear<FLOAT>(in_dim, hidden_dim);
			ih_linear = new nn::Linear<FLOAT>(hidden_dim, hidden_dim);
			fx_linear = new nn::Linear<FLOAT>(in_dim, hidden_dim);
			fh_linear = new nn::Linear<FLOAT>(hidden_dim, hidden_dim);
			ox_linear = new nn::Linear<FLOAT>(in_dim, hidden_dim);
			oh_linear = new nn::Linear<FLOAT>(hidden_dim, hidden_dim);
			cx_linear = new nn::Linear<FLOAT>(in_dim, hidden_dim);
			ch_linear = new nn::Linear<FLOAT>(hidden_dim, hidden_dim);
		}

		~LSTMCell_() {
			nn::CheckAndDelete(ix_linear);
			nn::CheckAndDelete(ih_linear);
			nn::CheckAndDelete(fx_linear);
			nn::CheckAndDelete(fh_linear);
			nn::CheckAndDelete(ox_linear);
			nn::CheckAndDelete(oh_linear);
			nn::CheckAndDelete(cx_linear);
			nn::CheckAndDelete(ch_linear);
		}
		void reset_parameters() override {}
		void forward(Node<FLOAT>* x, Node<FLOAT>* h_1, Node<FLOAT>* c_1, Node<FLOAT>*& h,Node<FLOAT>*& c) {
			i = Functional::sigmoid(Functional::add((*ix_linear)(x), (*ih_linear)(h_1)));
			f = Functional::sigmoid(Functional::add((*fx_linear)(x), (*fh_linear)(h_1)));
			o = Functional::sigmoid(Functional::add((*ox_linear)(x), (*oh_linear)(h_1)));
			c_ = Functional::tanh(Functional::add((*cx_linear)(x), (*ch_linear)(h_1)));
			c = Functional::add(Functional::mm(f , c_1), Functional::mm(i * c_));
			h = Functional::mm(o, Functional::tanh(c));
		}
		Node<FLOAT>* operator() (Node<FLOAT>* x, Node<FLOAT>* h_1, Node<FLOAT>* c_1, Node<FLOAT>*& out_h, Node<FLOAT>*& out_c) {
			return forward( x, h_1, c_1, out_h, out_c);
		}
	};
	template <typename FLOAT>
	class LSTM : public nn::module<FLOAT>
	{
	public:
		int64_t hidden_dim;
		LSTMCell_<FLOAT>* lstmCell;
		//method
		LSTM(int64_t _in_dim, int64_t _hidden_dim) {
			hidden_dim = _hidden_dim;
			lstmCell   = new LSTMCell_<FLOAT>(_in_dim, _hidden_dim);
		}
		~LSTM() {nn::CheckAndDelete(lstmCell);}
		void reset_parameters() override {}
		Node<FLOAT>* forward(Node<FLOAT>* x) {
			/*
			x : [seq_len,batch_siza,in_dim]
			*/
			vector<Node<FLOAT>*> out;
			vector<Node<FLOAT>*> shape = { x->value->shape[0] ,hidden_dim};
			vector<Node<FLOAT>*> seq_x = Functional::split(x,0);
			Node<FLOAT>* h = nullptr;
			Node<FLOAT>* c = nullptr;
			for (int i = 0; i < x->value->shape[0]; i++) {
				if (!h) { h = Functional::Variable(new Tensor<FLOAT>(shape)); h->value->gaussinit(); }
				if (!c) { c = Functional::Variable(new Tensor<FLOAT>(shape)); c->value->gaussinit(); }
				(*lstmCell)(seq_x[i],h,c);
				out.push_back(Functional::unsqueeze(h, 0));
			}
			output = Functional::cat(out,0);
			return output;
		}
		Node<FLOAT>* operator() (Node<FLOAT>* x) 
		{
			return forward(x);
		}
	};





}
#endif