#include "Module.h"
#ifndef _NORM_BASE_H_
#define _NORM_BASE_H_
namespace nn {
template <typename FLOAT>
class _NormBase : public nn::module<FLOAT>
{
	int64_t      num_features;
	FLOAT        eps = 0.00001;
	bool         affine = true;
	Node<FLOAT>* gammar = nullptr;
	Node<FLOAT>* beta = nullptr;
	Node<FLOAT>* running_mean = nullptr;
	Node<FLOAT>* running_var = nullptr;
	virtual ~_NormBase() {}
};
}

#endif // !_NORM_BASE_H_
