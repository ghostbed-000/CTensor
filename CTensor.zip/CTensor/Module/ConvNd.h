#include "Module.h"
#ifndef _CONVND_H_
#define _CONVND_H_
namespace nn {
template <typename FLOAT>
class Conv2d : public nn::module<FLOAT>
{
public:
	int64_t in_channels;
	int64_t out_channels;
	int64_t kernel_H;
	int64_t kernel_W;
	int32_t stride;
	int32_t padding;
	Node<FLOAT>* weight;
	Node<FLOAT>* bias;
	//method
	Conv2d(
		int64_t _in_channels, 
		int64_t _out_channels,
		int64_t _kernel_size, 
		int32_t _stride = 1, 
		int32_t _padding = 0, 
		bool    _bias = true) 
	{
		vector<int64_t> weight_shape = { _out_channels,_in_channels,_kernel_size ,_kernel_size };
		in_channels = _in_channels;
		out_channels = _out_channels;
		kernel_H = _kernel_size;
		kernel_W = _kernel_size;
		stride = _stride;
		padding = _padding;
		bias   = nullptr;
		weight = Functional::Variable<FLOAT>(new Tensor<FLOAT>(weight_shape,true,true));
		register_parameter(weight);
		if (_bias)
		{
			vector<int64_t> bias_shape = { _out_channels,1,1 };
			bias = Functional::Variable(new Tensor<FLOAT>(bias_shape,true,true));
			register_parameter(bias);

		}
		reset_parameters();
	}
	Conv2d(
		int64_t _in_channels,
		int64_t _out_channels,
		vector<int64_t>& _kernel_size,
		int32_t _stride = 1,
		int32_t _padding = 0,
		bool    _bias = true)
	{
		vector<int64_t> weight_shape = { _out_channels,_in_channels,_kernel_size[0] ,_kernel_size[1]};
		in_channels  = _in_channels;
		out_channels = _out_channels;
		kernel_H = _kernel_size[0];
		kernel_W = _kernel_size[1];
		stride   = _stride;
		padding  = _padding;
		bias   = nullptr;
		weight = Functional::Variable<FLOAT>(new Tensor<FLOAT>(weight_shape, true, true));
		register_parameter(weight);
		if (_bias)
		{
			vector<int64_t> bias_shape = { _out_channels,1,1 };
			bias = Functional::Variable(new Tensor<FLOAT>(bias_shape, true, true));
			register_parameter(bias);
		}
		reset_parameters();
	}
	~Conv2d() {
		nn::CheckAndDelete(weight);
		nn::CheckAndDelete(bias);
	}
	void reset_parameters() override {
		float k = 1.0 / (kernel_H * kernel_W * in_channels);
		weight->value->uniform(-std::powf(k, 0.5), std::powf(k, 0.5));
		if (!bias) {
			bias->value->uniform(-std::powf(k, 0.5), std::powf(k, 0.5));
		}
	}
	Node<FLOAT>* forward(Node<FLOAT>* x) {

		if (padding != 0)
		{
			x = Functional::pad(x, padding);
		}
		x = Functional::conv2d(x, weight, stride);
		if (bias) {
			x = Functional::add(x,bias);
		}
		return x;
	}
	Node<FLOAT>* operator() (Node<FLOAT>* input) {
		return forward(input);
	}

};



}








#endif
