#include "Module.h"

#ifndef _EMBEDDING_LAYER_H_
#define _EMBEDDING_LAYER_H_

namespace nn {
template <typename FLOAT>
class Embedding : public module<FLOAT>
{
public:
	//status
	int64_t vocab_num;
	int64_t vocab_dim;
	Node<FLOAT>* dictionary;
	
	//method
	Embedding(int64_t _vocab_num, int64_t _vocab_dim)
	{
		vocab_num = _vocab_num;
		vocab_dim = _vocab_dim;
		vector<int64_t> vocab_shape = { _vocab_num,_vocab_dim };
		dictionary = Functional::Variable<FLOAT>(new Tensor<FLOAT>(vocab_shape, true, true));
		register_parameter(dictionary);
		reset_parameters();
		
	}
	~Embedding(){
		if (!dictionary) {
			delete(dictionary);
			dictionary = nullptr;
		}
	}
	void reset_parameters() override {
		dictionary->value->gaussinit();
	}
	Node<FLOAT>* forward(Node<int64_t>* x)
	{
		return Functional::embedding(x, dictionary);
	}
	Node<FLOAT>* operator() (Node<int64_t>* input)
	{
		return forward(input);
	}
};


}

#endif