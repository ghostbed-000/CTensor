#include "Module.h"
#ifndef _LINEAR_H_
#define _LINEAR_H_
namespace nn {
template <typename FLOAT>
class Linear : public nn::module<FLOAT>
{
public:
	int64_t in_features;
	int64_t out_features;
	Node<FLOAT>* weight;
	Node<FLOAT>* bias;
	//method
	Linear(int64_t _in_features, int64_t _out_features,bool _bias = true) {
		vector<int64_t> weight_shape = { _in_features ,_out_features };
		in_features  = _in_features;
		out_features = _out_features;
		bias = nullptr;
		
		weight = Functional::Variable<FLOAT>(new Tensor<FLOAT>(weight_shape, true, true));
		register_parameter(weight);
		if (_bias)
		{
			vector<int64_t> bias_shape = { _out_features };
			bias = Functional::Variable<FLOAT>(new Tensor<FLOAT>(bias_shape,true,true));
			register_parameter(bias);
		}		
		reset_parameters();
	}
	
	~Linear() {
		nn::CheckAndDelete(weight);
		nn::CheckAndDelete(bias);
	}
	void reset_parameters() override {
		weight->value->uniform(-std::powf(in_features,-0.5), std::powf(in_features, -0.5));
		if (bias) {
			bias->value->uniform(-std::powf(in_features, -0.5), std::powf(in_features, -0.5));
		}
	}
	Node<FLOAT>* forward(Node<FLOAT>* input) {
		Node<FLOAT>* x = Functional::mm<FLOAT>(input,weight);
		if (bias != nullptr)
		{
			return Functional::add<FLOAT>(x, bias);
		}
		return x;
	}
	Node<FLOAT>* operator() (Node<FLOAT>* input) {
		return forward(input);
	}	


};

}

#endif
