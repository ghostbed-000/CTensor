#include "Linear.h"
#ifndef _MULTIHEAD_ATTENTION_H_
#define _MULTIHEAD_ATTENTION_H_
namespace nn {
template <typename FLOAT>
class MultiHeadSelfAttention : public nn::module<FLOAT>
{
public:
	int64_t dim_in;//dim_in = 2
	int64_t d_model;//d_model = 6
	int64_t num_head;//num_head = 3
	int64_t scale;//scale = 1 / sqrt(d_model / num_head)
	nn::Linear linear_q;
	nn::Linear linear_k;
	nn::Linear linear_v;
	nn::Linear fc;

	MultiHeadSelfAttention(int64_t _dim_in, int64_t _d_model, int64_t _num_head = 3) {
		if (d_model % num_head != 0)
		{
			printf("d_model must be divisible by num_head\n");
			return;
		}
		dim_in   = _dim_in;
		d_model  = _d_model;
		num_head = _num_head;
		linear_q = new nn::Linear<FLOAT>(dim_in, d_model);
		linear_k = new nn::Linear<FLOAT>(dim_in, d_model);
		linear_v = new nn::Linear<FLOAT>(dim_in, d_model);
		scale = 1 / sqrt(d_model / num_head);

	}
	Node<FLOAT>* forward(Node<FLOAT>* x) {
		//x: shape of input tensor {batch, n, dim_in}
		int64_t batch = x->value->shape[0];
		int64_t n = x->value->shape[1];
		int64_t dim_in = x->value->shape[2];
		int64_t dim_k = d_model / num_head;
		//Node<FLOAT>* q = linear_q();
		//Node<FLOAT>* k = linear_q();
		//Node<FLOAT>* v = linear_q();

	}
	Node<FLOAT>* operator()(Node<FLOAT>* input) {
		return forward(input);
	}
	~MultiHeadSelfAttention() {
		delete(linear_q);
		delete(linear_k);
		delete(linear_v);
		delete(fc);
	}
};


}

#endif
