#include "_NormBase.h"
#ifndef _BATCH_NORM_2D_H_
#define _BATCH_NORM_2D_H_
namespace nn {
template <typename FLOAT>
class BatchNorm2d : public nn::_NormBase<FLOAT>
{
	/*
	if shape of tensor : [B, C, H, W]
	_num_features = C
	*/

	BatchNorm2d(int64_t _num_features, bool _affine = true, FLOAT _eps = 0.00001) {
		num_features = _num_features;
		affine = _affine;
		eps = _eps;
		gammar = nullptr;
		beta = nullptr;
		if (affine)
		{
			vector<int64_t> shape = { num_features };
			gammar = Functional::Variable(new Tensor<FLOAT>(shape));
			beta = Functional::Variable(new Tensor<FLOAT>(shape));
			gammar->value->constant_(1.0);
			beta->value->constant_(0.0);
		}
	}
	Node<FLOAT>* forward(Node<FLOAT>* x) {
		x = Functional::batch_norm(x, running_mean, running_var, eps);
		if (affine)
		{
			x = Functional::norm2d_affine(x, gammar, beta);
		}
	}
	Node<FLOAT>* operator()(Node<FLOAT>* input) {
		return forward(input);
	}
	void reset_parameter() {}

	~BatchNorm2d() {
		delete(running_mean);
		delete(running_var);
		delete(gammar);
		delete(beta);
	}

};
}

#endif
