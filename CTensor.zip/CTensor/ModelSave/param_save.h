#include "..\Module\Module.h"
#include <fstream>
using std::ofstream;
using std::ifstream;
template <typename FLOAT> 
void save_param(ofstream& data,vector<Tensor<FLOAT>*> parameters){
	//write size of FLOAT
	int32_t SIZE = (int)sizeof(FLOAT);
	data.write((const char*)SIZE,sizeof(int32_t));
	
	for(unsigned int i=0;i<parameters.size();i++){
		data.write((const char*)parameters[i].array,parameters[i]._len_ * sizeof(FLOAT));
	}
	
}

template <typename FLOAT>
void load_param(ifstream& data, vector<Tensor<FLOAT>*> parameters) {
	//write size of FLOAT 
	int32_t SIZE;
	data.read((char*)SIZE, sizeof(int32_t));
	printf("model param size: float%d \n", SIZE * 8);

	for (unsigned int i = 0; i < parameters.size(); i++) {
		free(parameters[i].array);
		data.read((char*)parameters[i].array, parameters[i]._len_ * SIZE);
	}

}
