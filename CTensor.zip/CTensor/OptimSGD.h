#include "Optimizer.h"
#ifndef _OPTIM_SGD_H_
#define _OPTIM_SGD_H_
namespace optim {
template <typename FLOAT>
class SGD : public optim::Optimizer<FLOAT>
{
	FLOAT momentum;
	FLOAT dampening;
	FLOAT weight_decay;
	bool nesterov;
	vector<Tensor<FLOAT>*> first_moment;
public:
	SGD(
		float _lr           = 0.01,
		float _momentum     = 0.9,
		float _dampening    = 0.5,
		float _weight_decay = 0.01,
		bool  _nesterov     = false) 
	{
		parameter    = nn::Parameter;
		momentum     = _momentum;
		dampening    = _dampening;
		weight_decay = _weight_decay;
		nesterov     = _nesterov;
		lr           = _lr;
		CheckInvalidValue(lr);
		CheckInvalidValue(momentum);
		CheckInvalidValue(weight_decay);
		for (unsigned int i = 0; i < parameter.size(); i++)
		{
			Tensor<FLOAT>* a = (Tensor<FLOAT>*)nn::Parameter[i];
			first_moment.push_back(new Tensor<FLOAT>(a->shape,false));
		}
	}
	void update(Tensor<FLOAT>* x_t, Tensor<FLOAT>* vt_0) {
		Tensor<FLOAT>& p = *x_t;
		Tensor<FLOAT>& g = *(x_t->gradient);
		Tensor<FLOAT>& v = *vt_0;
		/*
			g1 = g0 + (p0 * weight_decay)
			if epoch = 1
			v1 = v0 * momentum + g1
			else
			v1 = v0 * momentum + g1 * (1 - dampening)
			if nesterov == true
			v2 = g1 + v1 * momentum
			else
			pass
			p1 = p0 - lr * v1
		*/
		p *= weight_decay;
		g.add(&p, &g);
		p /= weight_decay;
		if (epoch == 1)
		{
			v *= momentum;
			v.add(&g, &v);
		}
		else {
			v *= momentum;
			g *= (1 - dampening);
			v.add(&g, &v);
		}
		if (nesterov)
		{
			v *= momentum;
			v.add(&g, &v);
		}
		v *= lr;
		p.sub(&v, &p);

	}
	void step() override {
		for (unsigned int i = 0; i < parameter.size(); i++)
		{
			update((Tensor<FLOAT>*)parameter[i], first_moment[i]);
		}
		epoch++;
	}
	~SGD() { 
		
		for (unsigned int i = 0; i < first_moment.size(); i++)
		{
			delete(first_moment[i]);
		}
		vector<Tensor<FLOAT>*>().swap(first_moment);
	}
};


}


#endif // !_OPTIMIZER_H_